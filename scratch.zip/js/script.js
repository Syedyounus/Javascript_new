// JavaScript Document

/*---image functionality---*/
var clickHandler = "click";
$(document).ready(function(e) {
		"use strict";
	
		var images= [
        '../images/bg.jpg',
		'../images/ref.jpg'
    ];

    var $list = $('#imagesList');

    $.each(images, function(i, src) {
        var $li = $('<li class="loading">').appendTo($list);
        $('<img>').appendTo($li).one('load', function() {
            $li.removeClass('loading');
       }).attr('src', src);
    });	

	setTimeout(function () {
		$("#wrapperImg").css("visibility", "hidden");
		$(".bg-img-upper").addClass("hide-img");
	}, 300);
	
	
	
	$('.clickattr').bind('tap', function(){
		window.location.href=$(this).attr('goto');
	});

	$('img, a').on('dragstart', function(event){event.preventDefault();});	
	
	
	$("#menu").bind('tap', function(){
		$("#menu_slide").slideDown("slow");
	});
	
	$("#menu_close").bind('tap', function(){
		$("#menu_slide").slideUp("slow");
	});
	
	
});
