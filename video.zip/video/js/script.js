$(document).ready(function () {
	
	"use strict";
	
	var images= [
        '../images/bg.jpg',
     
        
    ];

    var $list = $('#imagesList');

    $.each(images, function(i, src) {
        var $li = $('<li class="loading">').appendTo($list);
        $('<img>').appendTo($li).one('load', function() {
            $li.removeClass('loading');
       }).attr('src', src);
    });		
	  


	setTimeout(function () {
		$("#wrapper").css("visibility", "visible");
	}, 150);
	
	
	$('.clickAttr').bind('tap', function () { 
		window.location.href = $(this).attr('goto');
	});
	
	$('img, a').on('dragstart', function(event){event.preventDefault();});
	
	
	var video = document.getElementById('video1');
	$('#vdo').bind('tap', function () { 
		$('#video_open').show();
		$('#vdo').hide();		
		video.play();
		video.currentTime = 0;
		video.muted = false;
	});
	$('.vdo_cls').bind('tap', function () { 
		$('#video_open').hide();
		mypause();
		$('#vdo').show();	
	});
	
	function mypause(){
			var myVideopause = document.getElementsByTagName('video')[0];
			myVideopause.currentTime = 0;
			myVideopause.pause();
		}
	
});