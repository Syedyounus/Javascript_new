  $(document).bind('touchmove',function(e) {e.preventDefault();});

	$(document).ready(function(){
	document.addEventListener('touchmove', function(e){ e.preventDefault(); });
		$('body').swipe({
				swipe:function(event, direction, distance, duration, fingerCount) {             
					if(direction == 'left') { //SWIPE RIGHT    

						window.open('veeva:nextSlide()');

					}
					 else if(direction == 'right') { //SWIPE LEFT
						window.open('veeva:prevSlide()');

					}

				}
		});
	});

