$(function() {
  new Dragdealer('simple-slider');
})
	$('#test').on('touchstart', function(event){
		console.log('test');
		var a = $('#test').position();
				  console.log(a);
		
		if(a.left >= 500){
			alert('reached');
		}
				  });