$(function() {
  new Dragdealer('image-carousel', {
    steps: 4,
    speed: 0.3,
    loose: true
  });
})
