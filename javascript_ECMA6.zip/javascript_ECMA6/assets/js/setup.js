/// paginatedPageSwiping bootstrapping
var previousPageIndex, previousPageDirection, defaultPagination;
var animateSwiperEntry = typeof sessionStorage.getItem('previousPageIndex') === 'string';
var hasDefaultPagination = typeof sessionStorage.getItem('PAGINATION') === 'string';

if(hasDefaultPagination)
{
	defaultPagination = +sessionStorage.getItem('PAGINATION');
	sessionStorage.removeItem('PAGINATION');
	document.documentElement.style.setProperty('--swiper-absolute', defaultPagination * 1024);
}

else if(animateSwiperEntry)
{
	previousPageIndex = +sessionStorage.getItem('previousPageIndex');
	previousPageDirection = +sessionStorage.getItem('previousPageDirection');
	sessionStorage.removeItem('previousPageIndex');
	sessionStorage.removeItem('previousPageDirection');
	document.documentElement.style.setProperty('--swiper-absolute', previousPageDirection * 1024);
}

/// accordion bootstrapping
var defaultAccordion;
var hasDefaultAccordion = typeof sessionStorage.getItem('ACCORDION') === 'string';

if(hasDefaultAccordion)
{
	defaultAccordion = sessionStorage.getItem('ACCORDION').split(','); // If there are multiple accordions, first is index/name of which one
	sessionStorage.removeItem('ACCORDION');
}





var iOS = (function iOSVersion() {
	if(window.MSStream) return false;
	var match = (navigator.appVersion).match(/OS (\d+)_(\d+)_?(\d+)?/), version;
	if(match !== undefined && match !== null) {
		version = [
			parseInt(match[1], 10),
			parseInt(match[2], 10),
			parseInt(match[3] || 0, 10)
		];
		return version.join('.');
	}
	return false;
})();

function cmpVersions (a, b) {
	var i, diff;
	var regExStrip0 = /(\.0+)+$/;
	var segmentsA = a.replace(regExStrip0, '').split('.');
	var segmentsB = b.replace(regExStrip0, '').split('.');
	var l = Math.min(segmentsA.length, segmentsB.length);

	for (i = 0; i < l; i++) {
		diff = parseInt(segmentsA[i], 10) - parseInt(segmentsB[i], 10);
		if (diff) {
			return diff;
		}
	}

	return segmentsA.length - segmentsB.length;
}


// DEPRECATED: Move to dual-listeners
// var TAP_EVENT = 'ontouchend' in window ? 'touchend' : 'mouseup';
var TAP_EVENT = iOS? 'touchend' : 'mouseup';






// Wrapper polyfill around Veeva CRM navigation
function go(scene, presentation) {
	// if(scene == 'ChangeEvidence'){
	// 	scene = 'MicroMacroVascularRisk';
	// }
	sessionStorage.setItem('previousSection', document.documentElement.dataset.section);
	sessionStorage.setItem('previousPage', document.documentElement.dataset.page);
	sessionStorage.setItem('previous', [scene, presentation].filter(truthy).join(','));

	function truthy(d) { return d }

	if(scene.match(/,/))
	{
		var temp = scene.split(',');
		scene = temp[0].trim();
		presentation = temp[1].trim();
	}

	var isVeeva = 'BUILD_FOR_IREP' in window;

	var extension = scene.match(/\.\w+$/);
	if(!extension) {
		extension = '.html';
		scene += extension;
	}
	else
	{
		extension = extension[0];
	}

	if(isVeeva)
	{
		var name = scene.replace(extension, '');
		var prefix = window.BUILD_FOR_IREP_PREFIX || '';
		var suffix = window.BUILD_FOR_IREP_SUFFIX || '';
		var separator = window.BUILD_FOR_IREP_SEPARATOR || '_';
		if(prefix && prefix[prefix.length-1] === separator) prefix = prefix.slice(0, -1);
		if(suffix && suffix[0] === separator) suffix = suffix.slice(1);

		if(extension == '.pdf')
		{
			suffix = ['PDF', suffix].filter(truthy).join(separator);
		}

		else if(extension == '.mp4')
		{
			suffix = ['VIDEO', suffix].filter(truthy).join(separator);
		}

		var keymessage = [prefix, name, suffix].filter(truthy).join(separator) + '.zip';

		setTimeout(function() {
			window.location = 'veeva:gotoSlide(' + [keymessage, presentation].filter(truthy).join(',') + ')';
		}, 30);
	}

	else
	{
		if(extension == '.pdf')
		{
			setTimeout(function() { window.open('assets/pdf/' + scene, '_blank') }, 30);
		}

		else if(extension == '.mp4')
		{
			setTimeout(function() { openVideo('assets/videos/' + scene) }, 30);
		}

		else
		{
			setTimeout(function() { window.location = scene }, 30);
		}
	}
}





/// Self-Contained JavaScript to prevent window scroll overflow bounce on iOS devices
/// Checks for whitelisted native scrolling via .scrollable class or if -webkit-overflow-scrolling is an inline-style
window.PreventWindowBounce = {
	handleEvent: function EventListenerInterface (ev) { if(ev.type in this) this[ev.type](ev); },
	bindEvents: function () {
		document.addEventListener('touchstart', PreventWindowBounce);
		document.addEventListener('touchmove', PreventWindowBounce);
	},

	/// The code works by checking whether the scroll area is against
	/// the container edges and if true prevent touch gesture defaults
	/// when the gesture attempts to go off edge.
	/// (which would otherwise cause the scroll gesture to scroll parent
	/// elements such as the document <body> causing the screen overflow)

	allowUp: false,
	allowDown: false,
	slideBeginY: 0,

	touchstart: function(ev) {
		var node = this.checkClosest(ev.target);
		if(node)
		{
			this.allowUp = (node.scrollTop > 0);
			this.allowDown = (node.scrollTop < node.scrollHeight - node.clientHeight);
			this.slideBeginY = ev.pageY;

			if(!this.allowUp && !this.allowDown) ev.preventDefault();
		}

		else ev.preventDefault();
	},

	touchmove: function(ev) {
		if(!this.allowUp && !this.allowDown) return ev.preventDefault();

		var node = this.checkClosest(ev.target);
		if(node)
		{
			var up = (ev.pageY > this.slideBeginY);
			var down = (ev.pageY < this.slideBeginY);
			this.slideBeginY = ev.pageY;

			if((up && this.allowUp) || (down && this.allowDown)) return ev.stopPropagation();
		}

		ev.preventDefault();
	},

	/// Checks all node parents for elements and whether they are whitelisted
	checkClosest: function(node) {
		while (node)
		{
			if(node.nodeType == document.ELEMENT_NODE && (node.style.webkitOverflowScrolling == 'touch' || node.classList.contains('scrollable'))) return node;
			node = node.parentNode;
		}

		return null;
	}
};

PreventWindowBounce.bindEvents();







/// Interpolation
function rescale(from_min, from_max, to_min, to_max, from) {
	return to_min + ((to_max-to_min) * ((from_min-from) / (from_min-from_max)));
}

rescale.clamped = function(from_min, from_max, to_min, to_max, from) {
	from = this(from_min, from_max, to_min, to_max, from);
	if(to_min < to_max) {
		if(from < to_min) return to_min;
		else if(from > to_max) return to_max;
	} else {
		if(from < to_max) return to_max;
		else if(from > to_min) return to_min;
	}
	return from;
}


/// An alternative API, works via two-element arrays, from and to
// E.g. retarget([0, 1], [0, 100], 0.5) => 50
function retarget(from, to, via) {
	if(!Array.isArray(from)) throw new Error('retarget: `from` is not an array');
	if(!Array.isArray(to)) throw new Error('retarget: `to` is not an array');
	if(from.length < 2) throw new Error('retarget: `from` needs at least 2 entries');
	if(to.length < 2) throw new Error('retarget: `to` needs at least 2 entries');

	if(via < from[0]) return rescale(from[0], from[1], to[0], to[1], via);
	if(via > from[from.length - 1]) return t = rescale(from[from.length - 2], from[from.length - 1], to[to.length - 2], to[to.length - 1], via);

	for(var iter = 0, total = from.length; iter < total; ++iter)
		if(via <= from[iter]) break;

	var a = from[iter - 1], b = from[iter];
	var t = (via - a) / (b-a);
	t = ((iter - 1 + t) / from.length) * to.length;
	var c = to[Math.floor(t)], d = to[Math.ceil(t)];
	return rescale(a, b, c, d, via);
}








/// Hyperscript | https://github.com/hyperhype/hyperscript
(function() {
	function context () {
		var cleanupFuncs = []

		function h() {
			var args = [].slice.call(arguments), e = null
			function item (l) {
				var r
				function parseClass (string) {
					// Our minimal parser doesn’t understand escaping CSS special
					// characters like `#`. Don’t use them. More reading:
					// https://mathiasbynens.be/notes/css-escapes .

					var m = string.split(/([\.#]?[^\s#.]+)/)
					if(/^\.|#/.test(m[1]))
						e = document.createElement('div')
					forEach(m, function (v) {
						var s = v.substring(1,v.length)
						if(!v) return
						if(!e)
							e = document.createElement(v)
						else if (v[0] === '.')
							e.classList.add(s)
						else if (v[0] === '#')
							e.setAttribute('id', s)
						})
					}

					if(l == null)
						;
					else if('string' === typeof l) {
						if(!e)
							parseClass(l)
						else
							e.appendChild(r = document.createTextNode(l))
					}
					else if('number' === typeof l
						|| 'boolean' === typeof l
						|| l instanceof Date
						|| l instanceof RegExp ) {
						e.appendChild(r = document.createTextNode(l.toString()))
					}
					//there might be a better way to handle this...
					else if (isArray(l))
						forEach(l, item)
					else if(isNode(l))
						e.appendChild(r = l)
					else if(l instanceof Text)
						e.appendChild(r = l)
					else if ('object' === typeof l) {
						for (var k in l) {
							if('function' === typeof l[k]) {
								if(/^on\w+/.test(k)) {
									(function (k, l) { // capture k, l in the closure
										if (e.addEventListener){
											e.addEventListener(k.substring(2), l[k], false)
											cleanupFuncs.push(function(){
												e.removeEventListener(k.substring(2), l[k], false)
											})
										}else{
											e.attachEvent(k, l[k])
											cleanupFuncs.push(function(){
												e.detachEvent(k, l[k])
											})
										}
									})(k, l)
								} else {
									// observable
									e[k] = l[k]()
									cleanupFuncs.push(l[k](function (v) {
										e[k] = v
									}))
								}
							}
							else if(k === 'style') {
								if('string' === typeof l[k]) {
									e.style.cssText = l[k]
								} else {
									for (var s in l[k]) (function(s, v) {
										if('function' === typeof v) {
											// observable
											e.style.setProperty(s, v())
											cleanupFuncs.push(v(function (val) {
												e.style.setProperty(s, val)
											}))
										} else
										var match = l[k][s].match(/(.*)\W+!important\W*$/);
										if (match) {
											e.style.setProperty(s, match[1], 'important')
										} else {
											e.style.setProperty(s, l[k][s])
										}
									})(s, l[k][s])
								}
							} else if(k === 'attrs') {
								for (var v in l[k]) e.setAttribute(v, l[k][v])
							}
							else if (k.substr(0, 5) === "data-") e.setAttribute(k, l[k])
							else e[k] = l[k]
						}
					} else if ('function' === typeof l) {
						//assume it's an observable!
						var v = l()
						e.appendChild(r = isNode(v) ? v : document.createTextNode(v))

						cleanupFuncs.push(l(function (v) {
							if(isNode(v) && r.parentElement) r.parentElement.replaceChild(v, r), r = v
							else r.textContent = v
						}))
					}

					return r
				}

				while(args.length) item(args.shift())

				return e
			}

			h.cleanup = function () {
				for (var i = 0; i < cleanupFuncs.length; i++){
				cleanupFuncs[i]()
			}
			cleanupFuncs.length = 0
		}

		return h
	}

	var h = context()
	h.context = context

	function isNode (el) {
		return el && el.nodeName && el.nodeType
	}

	function forEach (arr, fn) {
		if (arr.forEach) return arr.forEach(fn)
		for (var i = 0; i < arr.length; i++) fn(arr[i], i)
	}

	function isArray (arr) {
		return Object.prototype.toString.call(arr) == '[object Array]'
	}


	window.h = h;
})();




// Production steps of ECMA-262, Edition 6, 22.1.2.1
if (!Array.from)
{
	Array.from = (function () {
		var toStr = Object.prototype.toString;
		var isCallable = function (fn) {
			return typeof fn === 'function' || toStr.call(fn) === '[object Function]';
		};
		var toInteger = function (value) {
			var number = Number(value);
			if (isNaN(number)) { return 0; }
			if (number === 0 || !isFinite(number)) { return number; }
			return (number > 0 ? 1 : -1) * Math.floor(Math.abs(number));
		};
		var maxSafeInteger = Math.pow(2, 53) - 1;
		var toLength = function (value) {
			var len = toInteger(value);
			return Math.min(Math.max(len, 0), maxSafeInteger);
		};

		// The length property of the from method is 1.
		return function from(arrayLike/*, mapFn, thisArg */) {
			// 1. Let C be the this value.
			var C = this;

			// 2. Let items be ToObject(arrayLike).
			var items = Object(arrayLike);

			// 3. ReturnIfAbrupt(items).
			if (arrayLike == null) {
				throw new TypeError('Array.from requires an array-like object - not null or undefined');
			}

			// 4. If mapfn is undefined, then let mapping be false.
			var mapFn = arguments.length > 1 ? arguments[1] : void undefined;
			var T;
			if (typeof mapFn !== 'undefined') {
				// 5. else
				// 5. a If IsCallable(mapfn) is false, throw a TypeError exception.
				if (!isCallable(mapFn)) {
					throw new TypeError('Array.from: when provided, the second argument must be a function');
				}

				// 5. b. If thisArg was supplied, let T be thisArg; else let T be undefined.
				if (arguments.length > 2) {
					T = arguments[2];
				}
			}

			// 10. Let lenValue be Get(items, "length").
			// 11. Let len be ToLength(lenValue).
			var len = toLength(items.length);

			// 13. If IsConstructor(C) is true, then
			// 13. a. Let A be the result of calling the [[Construct]] internal method
			// of C with an argument list containing the single item len.
			// 14. a. Else, Let A be ArrayCreate(len).
			var A = isCallable(C) ? Object(new C(len)) : new Array(len);

			// 16. Let k be 0.
			var k = 0;
			// 17. Repeat, while k < len… (also steps a - h)
			var kValue;
			while (k < len) {
				kValue = items[k];
				if (mapFn) {
					A[k] = typeof T === 'undefined' ? mapFn(kValue, k) : mapFn.call(T, kValue, k);
				} else {
					A[k] = kValue;
				}
				k += 1;
			}
			// 18. Let putStatus be Put(A, "length", len, true).
			A.length = len;
			// 20. Return A.
			return A;
		};
	}());
}



if(!Element.prototype.matches)
{
	Element.prototype.matches =
		Element.prototype.matchesSelector ||
		Element.prototype.mozMatchesSelector ||
		Element.prototype.msMatchesSelector ||
		Element.prototype.oMatchesSelector ||
		Element.prototype.webkitMatchesSelector ||
		function(s) {
			var matches = (this.document || this.ownerDocument).querySelectorAll(s);
			var i = matches.length;
			while (--i >= 0 && matches.item(i) !== this) {}
			return i > -1;
		};
}


if(!Element.prototype.closest)
{
	Element.prototype.closest =
	function(s) {
		var matches = (this.document || this.ownerDocument).querySelectorAll(s);
		var i, el = this;
		do {
			i = matches.length;
			while (--i >= 0 && matches.item(i) !== el) {};
		} while ((i < 0) && (el = el.parentElement));
		return el;
	};
}
