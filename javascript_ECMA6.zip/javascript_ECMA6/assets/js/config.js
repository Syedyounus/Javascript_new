var PrimaryPages = {
	'Splash': {
		label: `
			<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20.7" viewBox="0 0 20 20.7">
				<path d="M19.2 8.2L10.7.7C10.2.2 9.5.2 9 .7L.8 8.2c-.2.3-.4.6-.4 1v9.4c0 1 .8 1.7 1.7 1.7h3.6c1 0 1.7-.7 1.7-1.7v-4.4c0-1.4 1.2-2.6 2.7-2.6 1.5 0 2.7 1.2 2.7 2.6v4.4c0 1 .8 1.7 1.7 1.7H18c.8 0 1.6-.7 1.6-1.7V9.2c0-.4-.2-.7-.4-1z"/>
			</svg>
		`,
		paginated: [
			{ references: ['forxiga', 'ims-midas'] },
			{ references: ['forxiga'] }
		]
	},
		

	'Understanding': {
		label: 'YOUR PATIENTS',		
		secondary: {
			'UnderstandingBurden': {
			 	label: 'BURDEN OF DISEASE',
			 	paginated: [
					{
						references: ['Diabetes', 'Diabetes_Related']
					},
				],
			 	
			 },
			'UnderstandingChallenges': {
				label: 'KEY CHALLENGES',
				references: ['phe-adult', 'hill', 'jansink']
			},
			'UnderstandingOutcomes': {
				label: 'KEY OUTCOMES',
				references: ['daly', 'pi-sunyer', 'grandy-2012']
			}			
		},
		sitemap: [
			 { page: 'UnderstandingBurden', label: 'BURDEN OF<br>DISEASE' },
			{ page: 'UnderstandingChallenges', label: 'KEY<br>CHALLENGES',  },
			{ page: 'UnderstandingOutcomes', label: 'KEY<br>OUTCOMES' }
			
		]
	},
	
	
'MOA': {
			label: 'MOA',
		secondary: {
			'TolerabilityPatient': {
				accordion: {
					utis: {
						footnotes: ['6'],
// 						references: ['linetzky', 'forxiga', 'whaley', 'geerlings'],
						references: ['linetzky', 'forxiga', 'whaley', 'idris', 'geerlings', 'Xigduo'],
						data: [{ type: 'other', name: 'hypo' }]
					},
					vd: {
						footnotes: ['7'],
						references: ['linetzky', 'forxiga', 'Xigduo'],
						data: [{ type: 'other', name: 'hypo' }]
					}
				},
				popups: {
					rates: {
						references: ['forxiga', 'whaley', 'geerlings', 'emdac'],
						data: [{ type: 'other', name: 'hypo' }]
					},
					moa_1: {
						references: ['idris'],
						data: [{ type: 'other', name: 'hypo' }]
					}
				}
			}
		},
		sitemap: [
			{ page: 'TolerabilityPatient', label: 'MOA',  },
			
			//{ page: 'UnderstandingEngagement', label: 'PATIENT<br>ENGAGEMENT' }
			]
			},	

	'Introducing': {
		label: 'FORXIGA<sup>®</sup>',
		secondary: {
			'IntroducingForxiga': {
				label: 'FORXIGA<sup>®</sup>',
				data: [{ type: 'hba1c', name: 'dpp-rct' }],
				references: ['ims-midas', 'ims-quint', 'rosenstock', 'shatskov', 'forxiga', 'wilding-2017', 'wilding-2017-appendix']
			},
			'IntroducingCPRD': {
				label: 'CPRD',
				studies: ['cprd'],
				references: ['dof-017', 'herrett']
			}
		},
		sitemap: [
			{ page: 'IntroducingForxiga', label: 'FORXIGA<sup>®</sup>' },
			//{ page: 'IntroducingCPRD', label: 'CPRD' }
		]
	},
//	'MicroMacro': {
//		secondary: {
//		'MicroMacroVascularRisk': {
//			paginated: [
//					{
//						references: ['Tuttle','de_Simone','Rawshani','Shah_AD'],
//					},
//					{
//						references: ['Stratton'],
//					},
//				],
//		}
//	}
//	},

	'Change': {
		label: 'START<br>CHANGE',
		secondary: {
			'ChangeEvidence': {
				// label: 'OUR EVIDENCE',
				
				accordion: {
					rwe: {
						hba1c: {
							studies: ['cprd'],
							references: ['wilding-2017-appendix', 'wilding-2015', 'dof-017', 'Xigduo'],
							data: [
								{ type: 'hba1c', name: 'rwe-all' },
								{ type: 'hba1c', name: 'rwe-triple' }
							]
						},
						weight: {
							studies: ['cprd'],
							references: ['wilding-2017-appendix', 'forxiga', 'wilding-2015', 'dof-017'],
							data: [
								{ type: 'weight', name: 'rwe-all' },
								{ type: 'weight', name: 'rwe-triple' }
							]
						},
						blood: {
							studies: ['cprd'],
							references: ['wilding-2017-appendix', 'forxiga', 'wilding-2015', 'dof-017']
						}
					},
					rct: {
						hba1c: {
							studies: ['nauck', 'bailey', 'yang', 'mueller', 'rosenstock', 'frias'],
							references: ['nauck', 'bailey-2010', 'yang', 'mueller', 'rosenstock', 'frias', 'shatskov', 'weber', 'Xigduo'],
						},
						weight: {
							studies: ['shatskov'],
							footnotes: ['2'],
							references: ['nauck', 'bailey-2010', 'yang', 'mueller', 'rosenstock', 'frias', 'shatskov', 'weber', 'forxiga', 'Xigduo'],
							data: [
								{ type: 'weight', name: 'type' },
								{ type: 'weight', name: 'triple-rct' },
								{ type: 'weight', name: 'triple-post' }
							]
						},
						blood: {
							studies: ['weber'],
							footnotes: ['3'],
							references: ['nauck', 'bailey-2010', 'yang', 'mueller', 'rosenstock', 'frias', 'shatskov', 'weber', 'forxiga', 'Xigduo']
						}
					}
				},
				popups: {
					'rwe-hba1c-graph': {
						studies: ['cprd'],
						references: ['wilding-2017-appendix', 'wilding-2015', 'dof-017']
					},
					'rwe-weight-graph': {
						studies: ['cprd'],
						footnotes: ['1'],
						references: ['wilding-2017-appendix', 'grandy-2014', 'forxiga', 'wilding-2015', 'dof-017']
					},
					'rwe-blood-graph': {
						studies: ['cprd'],
						references: ['wilding-2017-appendix', 'forxiga', 'wilding-2015', 'dof-017']
					},
					'rct-hba1c-graph': {
						studies: ['nauck', 'bailey', 'yang', 'mueller', 'rosenstock', 'frias'],
						references: ['nauck', 'bailey-2010', 'yang', 'mueller', 'rosenstock', 'frias']
					},
					'rct-weight-0-graph': {
						studies: ['shatskov'],
						footnotes: ['2'],
						references: ['shatskov', 'forxiga']
					},
					'rct-weight-1-graph': {
						studies: ['shatskov'],
						footnotes: ['2'],
						references: ['shatskov', 'forxiga']
					},
					'rct-weight-2-graph': {
						studies: ['shatskov'],
						footnotes: ['2'],
						references: ['shatskov', 'forxiga']
					},
					'rct-weight-3-graph': {
						studies: ['shatskov'],
						footnotes: ['2'],
						references: ['shatskov', 'forxiga']
					},
					'rct-weight-4-graph': {
						studies: ['shatskov'],
						footnotes: ['2'],
						references: ['shatskov', 'forxiga']
					},
					'rct-blood-graph': {
						studies: ['weber'],
						footnotes: ['3'],
						references: ['weber', 'forxiga']
					}
				}
			},
			'ChangeData': {
				// label: 'OUR POOLED DATA',
				accordion: {
					rwe: [
						{
							studies: ['cprd'],
							references: ['wilding-2017', 'wilding-2017-appendix', 'forxiga', 'wilding-2015', 'dof-017']
						}
					],
					rct: [
						{
							studies: ['hardy'],
							references: ['hardy', 'forxiga']
						}
					]
				},
				popups: {
					'rwe-graph': {
						studies: ['cprd'],
						references: ['wilding-2017', 'wilding-2017-appendix', 'forxiga', 'wilding-2015', 'dof-017']
					},
					'rct-graph': {
						studies: ['hardy'],
						references: ['hardy', 'forxiga']
					}
				}
			}
		},
		sitemap: [
//			{ page: 'MicroMacroVascularRisk', label: 'UKPDS DATA' },
			{ page: 'ChangeEvidence', label: 'OUR EVIDENCE' },
			//{ page: 'ChangeData', label: 'OUR POOLED<br>DATA' }
		]
	},

	'Tolerability': {
		label: 'TOLERABILITY',
		secondary: {
			'TolerabilityOverview': {
				label: 'OVERVIEW',
				references: ['forxiga', 'linetzky'],
				popups: {
					'adverse-events': {
						footnotes: ['5'],
						tableFootnotes: ['4'],
						references: ['forxiga']
					}
				}
			},
//			'TolerabilityPatient': {
//				label: 'YOU AND YOUR PATIENT',
//				accordion: {
//					utis: {
//						footnotes: ['6'],
//// 						references: ['linetzky', 'forxiga', 'whaley', 'geerlings'],
//						references: ['linetzky', 'forxiga', 'whaley', 'idris', 'geerlings'],
//						data: [{ type: 'other', name: 'hypo' }]
//					},
//					vd: {
//						footnotes: ['7'],
//						references: ['linetzky', 'forxiga'],
//						data: [{ type: 'other', name: 'hypo' }]
//					}
//				},
//				popups: {
//					rates: {
//						references: ['forxiga', 'whaley', 'geerlings', 'emdac'],
//						data: [{ type: 'other', name: 'hypo' }]
//					},
//					moa: {
//						references: ['idris'],
//						data: [{ type: 'other', name: 'hypo' }]
//					}
//				}
//			},
			'TolerabilityPractice': {
				label: 'YOU AND YOUR PRACTICE',
				accordion: {
					renal: {
						references: ['forxiga', 'canagliflozin', 'empagliflozin', 'ptaszynska']
					},
					cv: {
						footnotes: ['8'],
						references: ['list', 'sonesson', 'emdac', 'forxiga', 'declare'],
						data: [{ type: 'other', name: 'mace' }]
					}
				},
				popups: {
					'renal-graph': {
						references: ['ptaszynska', 'forxiga']
					},
					'cv-graph': {
						references: ['emdac', 'forxiga'],
						data: [{ type: 'other', name: 'mace' }]
					}
				}
			},
			'TolerabilityClinical': {
				label: 'CLINICAL CONSIDERATIONS',
				references: ['forxiga', 'ljunggren'],
				popups: {
					'dka': {
						references: ['forxiga', 'mills', 'andersson']
					}
				}
			}
		},
		sitemap: [
			{ page: 'TolerabilityOverview', label: 'OVERVIEW' },
//			{ page: 'TolerabilityPatient', label: 'MOA' },
			{ page: 'TolerabilityPractice', label: 'RENAL FUNCTION' },
			{ page: 'TolerabilityProfile', label: 'CV SAFETY PROFILE' },
			{ page: 'TolerabilityClinical', label: 'FORXIGA<sup>®</sup>/XIGDUO<sup>TM</sup><br> SAFETY & TOLERABILITY' }
		]
	},

	'Prescribe': {
		label: 'PRESCRIBE<br>EARLY',
		secondary: {
			'PrescribePositioning': {
				label: 'POSITIONING',
				accordion: {
					hba1c: {
						studies: ['rosenstock'],
						references: ['rosenstock', 'dof-020']
					},
					weight: {
						studies: ['rosenstock'],
						references: ['rosenstock', 'dof-020', 'forxiga', 'saxagliptin']
					}
				},
				popups: {
					hba1c: {
						studies: ['rosenstock'],
						references: ['rosenstock', 'dof-020']
					},
					weight: {
						studies: ['rosenstock'],
						references: ['rosenstock', 'dof-020', 'forxiga', 'saxagliptin']
					}
				}
			},
			'PrescribeDosing': {
				label: 'DOSING',
				references: ['forxiga'],
				data: [{ type: 'other', name: 'table' }]
			}
		},
		sitemap: [
			{ page: 'PrescribePositioning', label: 'POSITIONING' },
			{ page: 'PrescribeDosing', label: 'DOSING' }
		]
	},
	'Duration8': {
		label: 'DURATION-8',
		secondary: {
		'Duration-8': {
				label: 'OUR EVIDENCE',
				accordion: {
					rct: {
						hba1c: {
							studies: ['frias',   'wilding-2014', 'wilding-2012'],
							footnotes: ['b:*'],
							references: ['frias',   'wilding-2014', 'wilding-2012'],
							data: [{ type: 'hba1c', name: 'ahead' }, { type: 'hba1c', name: 'glp1' }],
						},
						weight: {
							studies: ['frias',   'wilding-2014'],
							footnotes: ['b:†'],
							references: ['frias', 'forxiga',   'wilding-2014'],
							data: [{ type: 'weight', name: 'ahead' }, { type: 'weight', name: 'glp1' }],
						}
					}
				},
				popups: {
					'rct-hba1c-ahead-graph': {
						studies: ['frias'],
						references: ['frias']
					},
					'rct-hba1c-glp-graph': {
						studies: ['frias'],
						references: ['frias']
					},
					'rct-hba1c-insulin-graph': {
						studies: ['wilding-2014', 'wilding-2012'],
						footnotes: ['b:*'],
						references: ['wilding-2014', 'wilding-2012']
					},
					'rct-weight-ahead-graph': {
						studies: ['frias'],
						references: ['frias', 'forxiga']
					},
					'rct-weight-glp-graph': {
						studies: ['frias'],
						references: ['frias', 'forxiga']
					},
					'rct-weight-insulin-graph': {
						studies: ['wilding-2014'],
						footnotes: ['b:†'],
						references: ['wilding-2014', 'forxiga']
					}
				}
			}
		},
		sitemap: [
			{ page: 'Duration-8', label: 'DURATION-8' }
		]
	},
	'Summary': {
		label: 'SUMMARY',
		paginated: [
			{ references: ['ims-midas', 'ims-quint', 'rosenstock', 'shatskov', 'forxiga'] },
			{ references: ['forxiga'] }
		],
		sitemap: [
			{ page: 'Summary', label: 'SUMMARY' }
		]
	},

	'Qtern': {
		label: 'QTERN',
		secondary: {
			'QternPreSummary': {
				label: 'QTERN™',
				paginated: [
					{
						references: ['qtern', 'bailey-2010', 'bailey-2013', 'prato', 'matthaei-2016', 'forxiga', 'lokhandwala', 'mims-forxiga', 'mims-onglyza', 'mims-qtern']
					},
					{
						references: ['qtern']
					}
				],
				popups: {
					'adverse-events': {
						tableFootnotes: ['9'],
						references: ['qtern', 'forxiga', 'onglyza']
					}
				}
			},
			'QternPositioning': {
				label: 'POSITIONING',
				paginated: [
					{
						references: ['qtern', 'bailey-2010', 'bailey-2013', 'prato', 'matthaei-2015', 'forxiga']
					},
					{
						references: ['qtern', 'bailey-2010', 'bailey-2013', 'prato', 'matthaei-2015', 'forxiga']
					}
				]
			},
			'QternEfficacy': {
				label: 'EFFICACY',
				accordion: {
					hba1c: {
						studies: ['qtern-studies'],
						references: ['qtern', 'bailey-2010', 'bailey-2013', 'prato', 'matthaei-2016', 'forxiga']
					},
					saxa: {
						studies: ['matthaei'],
						references: ['matthaei-2015', 'matthaei-2016']
					},
					dapa: {
						studies: ['mathieu'],
						references: ['mathieu-2015', 'qtern']
					}
				}
			},
			'QternClinical': {
				label: 'CLINICAL CONSIDERATIONS',
				paginated: [
					{
						references: ['qtern']
					},
					{
						references: ['qtern']
					}
				]
			},
			'QternDosing': {
				label: 'DOSING',
				paginated: [
					{
						references: ['qtern', 'forxiga']
					},
					{
						references: ['mims-forxiga', 'mims-onglyza', 'mims-qtern', 'qtern', 'forxiga', 'prato', 'matthaei-2015', 'lokhandwala', 'onglyza']
					}
				]
			},
			'QternPostSummary': {
				label: 'SUMMARY',
				references: ['qtern', 'bailey-2010', 'bailey-2013', 'prato', 'matthaei-2015', 'mims-forxiga', 'mims-onglyza', 'mims-qtern', 'forxiga']
			}
		},
		overrideSitemap: true,
		sitemap: [
			{ page: 'QternPreSummary', label: 'AE Table', pagination: 1 }
		]
	}
};




/// Footnote content
var Footnotes = {
	'1': {
		content: `
			<ul class="footnotes">
				<li>
					<span class="pre"><sup>†</sup></span>
					From a pooled post-hoc analysis of patients who reported weight loss compared with patients
					who reported weight gain. Significantly (P<0.05) more weight-loss patients
					reported improvements in physical health, self-esteem and overall quality of life than
					weight-gain patients, independent of the time point data was collected within the 102-week
					observation period.<sup class="ref">1</sup>
				</li>
			</ul>`,
		references: ['grandy-2014']
	},

	'2': {
		content: `
			<ul class="footnotes">
				<li>
					<span class="pre"><sup>‡</sup></span>
					There was a significant treatment-by-BMI subgroup interaction (P<0.0001) with body weight,
					suggesting a difference in treatment effect based on BMI. Absolute weight loss increased
					with baseline BMI and was greatest in patients with BMI ≥40 kg/m<sup>2</sup> who received
					dapagliflozin 10 mg; across all baseline BMI categories patients generally lost 1%–2% of
					their baseline weight with dapagliflozin 5 mg and 2%–3% with dapagliflozin 10 mg. Similar
					proportions of patients across BMI subgroups achieved weight reductions of ≥5% with
					dapagliflozin 5 mg (9.7%–20.9%) and 10 mg (16.7%–24.4%); placebo (4.2%–6.7%). After 24 weeks
					of treatment with dapagliflozin 5 or 10 mg, 18%–29% of obese patients shifted 1 BMI category
					lower compared with 9%–13% of patients who received placebo.<sup class="ref">1</sup>
				</li>
			</ul>`,
		references: ['shatskov']
	},

	'3': {
		content: `
			<ul class="footnotes">
				<li>
					<span class="pre"><sup>†</sup></span>
					In a prespecified pooled analysis of 12 placebo-controlled studies, treatment with FORXIGA<sup>®</sup> 10 mg
					resulted in a systolic blood pressure change from baseline of -4.4 mmHg and diastolic blood
					pressure of -2.1 mmHg versus -0.9 mmHg and -0.5 mmHg diastolic blood pressure for the placebo
					group at Week 24.<sup class="ref">1</sup>
				</li>
				<li>
					<span class="pre"><sup>‡</sup></span>
					Data are longitudinal repeated measures analysis excluding data after rescue, at 12 weeks,
					n corresponds to the number of randomised subjects with non-missing baseline and Week 12 values.
					Significant p-value: Co-primary endpoints tested at alpha = 0.05.<sup class="ref">2</sup>
				</li>
			</ul>`,
		references: ['ptaszynska', 'weber']
	},

	'4': {
		content: `
			<ul class="footnotes">
				<li>
					<span class="pre"><sup>a</sup></span>
					The table shows up to 24-week (short-term) data regardless of glycaemic rescue.
				</li>
				<li>
					<span class="pre"><sup>b</sup></span>
					Vulvovaginitis, balanitis and related genital infections includes, e.g. the predefined preferred terms: vulvovaginal mycotic infection, vaginal infection, balanitis, genital infection fungal, vulvovaginal candidiasis, vulvovaginitis, balanitis candida, genital candidiasis, genital infection, genital infection male, penile infection, vulvitis, vaginitis bacterial, vulval abscess.
				</li>
				<li>
					<span class="pre"><sup>c</sup></span>
					Urinary tract infection includes the following preferred terms, listed in order of frequency reported: urinary tract infection, cystitis, Escherichia urinary tract infection, genitourinary tract infection, pyelonephritis, trigonitis, urethritis, kidney infection and prostatitis.
				</li>
				<li>
					<span class="pre"><sup>d</sup></span>
					Adverse reaction was identified through postmarketing surveillance. Rash includes the following preferred terms, listed in order of frequency in clinical trials: rash, rash generalised, rash pruritic, rash macular, rash maculo-papular, rash pustular, rash vesicular, and rash erythematous. In active- and placebo-controlled clinical trials (dapagliflozin, N=5936, All control, N=3403), the frequency of rash was similar for dapagliflozin (1.4%) and all control (1.4%), respectively.
				</li>
				<li>
					<span class="pre"><sup>e</sup></span>
					Polyuria includes the preferred terms: pollakiuria, polyuria, urine output increased.
				</li>
				<li>
					<span class="pre"><sup>f</sup></span>
					Mean changes from baseline in haematocrit were 2.30% for dapagliflozin 10 mg versus-0.33% for placebo. Haematocrit values >55% were reported in 1.3% of the subjects treated with dapagliflozin 10 mg versus 0.4% of placebo subjects.
				</li>
				<li>
					<span class="pre"><sup>g</sup></span>
					Mean percent change from baseline for dapagliflozin 10 mg versus placebo, respectively, was: total cholesterol 2.5% versus 0.0%; HDL cholesterol 6.0% versus 2.7%; LDL cholesterol 2.9% versus -1.0%; triglycerides –2.7% versus -0.7%.
				</li>
				<li>
					<span class="pre"><sup>h</sup></span>
					Volume depletion includes, e.g. the predefined preferred terms: dehydration, hypovolaemia, hypotension.
				</li>
				<li>
					<span class="pre">*</span>
					Reported in ≥ 2% of subjects and ≥ 1% more and at least 3 more subjects treated with dapagliflozin 10 mg compared to placebo.
				</li>
				<li>
					<span class="pre">**</span>
					Reported by the investigator as possibly related, probably related or related to study treatment and reported in ≥ 0.2% of subjects and ≥ 0.1% more and at least 3 more subjects treated with dapagliflozin 10 mg compared to placebo.
				</li>
			</ul>`,
	},

	'5': {
		content: `
			<ul class="footnotes">
				<li>
					<span class="pre"><sup>†</sup></span>
					The frequency of hypoglycaemia depended on the type of background therapy used in each study.<sup class="ref">1</sup>
					<ul class="formatted">
						<li>For studies of FORXIGA<sup>®</sup> in monotherapy, as add-on to metformin or as add-on to sitagliptin (with or without metformin), the frequency of minor episodes of hypoglycaemia was similar (< 5%) between treatment groups, including placebo up to 102 weeks of treatment. Across all studies, major events of hypoglycaemia were uncommon and comparable between the groups treated with FORXIGA<sup>®</sup> or placebo. Studies with add-on sulphonylurea and add-on insulin therapies had higher rates of hypoglycaemia.</li>
						<li>In an add-on to glimepiride study, at Weeks 24 and 48, minor episodes of hypoglycaemia were reported more frequently in the group treated with FORXIGA<sup>®</sup> 10 mg plus glimepiride (6.0% and 7.9%, respectively) than in the placebo plus glimepiride group (2.1% and 2.1%, respectively).</li>
						<li>In an add-on to insulin study, episodes of major hypoglycaemia were reported in 0.5% and 1.0% of subjects treated with FORXIGA<sup>®</sup> 10 mg plus insulin at Weeks 24 and 104, respectively, and in 0.5% of subjects treated with placebo plus insulin groups at Weeks 24 and 104. At Weeks 24 and 104, minor episodes of hypoglycaemia were reported, respectively, in 40.3% and 53.1% of subjects who received FORXIGA<sup>®</sup> 10 mg plus insulin and in 34.0% and 41.6% of the subjects who received placebo plus insulin.</li>
						<li>In an add-on to metformin and a sulphonylurea study, up to 24 weeks, no episodes of major hypoglycaemia were reported. Minor episodes of hypoglycaemia were reported in 12.8% of subjects who received FORXIGA<sup>®</sup> 10 mg plus metformin and a sulphonylurea and in 3.7% of subjects who received placebo plus metformin and a sulphonylurea.</li>
					</ul>
				</li>
				<li>
					<span class="pre"><sup>‡</sup></span>
					Reactions related to volume depletion (including, reports of dehydration, hypovolaemia or hypotension) were reported in 1.1% and 0.7% of subjects who received FORXIGA<sup>®</sup> 10 mg and placebo, respectively; serious reactions occurred in < 0.2% of subjects balanced between FORXIGA<sup>®</sup> 10 mg and placebo.<sup class="ref">1</sup>
				</li>
			</ul>`,
		references: ['forxiga']
	},

	'6': {
		content: `
			<ul class="footnotes">
				<li>
					<span class="pre">*</span>
					Genital infection include the preferred terms, listed in order of frequency reported: vulvovaginal mycotic infection, vaginal infection, balanitis, genital infection fungal, vulvovaginal candidiasis, vulvovaginitis, balanitis candida, genital candidiasis, genital infection male, penile infection, vaginitis bacterial, and vulval abscess.<sup class="ref">1</sup>
				</li>
			</ul>`,
		references: ['forxiga']
	},

	'7': {
		content: `
			<ul class="footnotes">
				<li>
					<span class="pre">*</span>
					The incidence of volume depletion was analysed in a pre-specified pooled analysis of 13 placebo-controlled studies. 2360 subjects were treated with dapagliflozin 10 mg and 2295 were treated with placebo. Reactions related to volume depletion (including, reports of dehydration, hypovolaemia or hypotension) were reported in 1.1% and 0.7% of subjects who received FORXIGA<sup>®</sup> 10 mg and placebo, respectively; serious reactions occurred in <0.2% of subjects balanced between FORXIGA<sup>®</sup> 10 mg and placebo.<sup class="ref">1</sup>
				</li>
			</ul>`,
		references: ['forxiga']
	},

	'8': {
		content: `
			<ul class="footnotes">
				<li>
					<span class="pre">**</span>
					A meta-analysis of 21 Phase IIb/III studies in which 34.4% of subjects had a history of CVD
					(excluding hypertension) at baseline and 67.9% had hypertension.<sup class="ref">1</sup> Studies that did
					not have at least one positively adjudicated event were excluded from analysis.<sup class="ref">2</sup>
				</li>
			</ul>`,
		references: ['forxiga', 'emdac']
	},

	'9': {
		content: `
			<ul class="footnotes">
				<li>
					<span class="pre"><sup>A</sup></span>
					Adverse reactions reported in ≥ 2% of subjects treated with the combined use of saxagliptin + dapagliflozin in the pooled safety analysis, or if reported in < 2% in the pooled safety analysis, they were based on the individual mono-components data.
				</li>
				<li>
					<span class="pre"><sup>B</sup></span>
					Adverse reactions were reported in ≥ 2% of subjects with either mono-component and ≥ 1% more than placebo, but not in the pooled analysis.
				</li>
				<li>
					<span class="pre"><sup>C</sup></span>
					Adverse reaction originates from saxagliptin or dapagliflozin post-marketing surveillance data.
				</li>
				<li>
					<span class="pre"><sup>D</sup></span>
					Frequencies of all uncommon adverse reactions were based on the individual mono-components data.
				</li>
				<li>
					<span class="pre"><sup>E</sup></span>
					Haematocrit values > 55% were reported in 1.3% of the subjects treated with dapagliflozin 10 mg versus 0.4% of placebo subjects.
				</li>
				<li>
					<span class="pre"><sup>1</sup></span>
					Upper respiratory tract infection includes the following preferred terms: nasopharyngitis, influenza, upper respiratory tract infection, pharyngitis, rhinitis, sinusitis, pharyngitis bacterial, tonsillitis, acute tonsillitis, laryngitis, viral pharyngitis, and viral upper respiratory tract infection.
				</li>
				<li>
					<span class="pre"><sup>2</sup></span>
					Urinary tract infection includes the following preferred terms: urinary tract infection, <i>Escherichia</i> urinary tract infection, pyelonephritis, and prostatitis.
				</li>
				<li>
					<span class="pre"><sup>3</sup></span>
					Vulvovaginitis, balanitis and related genital infection include the following preferred terms: vulvovaginal mycotic infection, balanoposthitis, genital infection fungal, vaginal infection, and vulvovaginitis.
				</li>
				<li>
					<span class="pre"><sup>4</sup></span>
					Dyslipidaemia includes the following preferred terms: dyslipidaemia, hyperlipidaemia, hypercholesterolaemia, and hypertriglyceridaemia.
				</li>
				<li>
					<span class="pre"><sup>5</sup></span>
					Polyuria includes the following preferred terms: polyuria, and pollakiuria.
				</li>
				<li>
					<span class="pre"><sup>6</sup></span>
					Rash was reported during the postmarketing use of saxagliptin and dapagliflozin. Preferred terms reported in dapagliflozin clinical trials included in order of frequency: rash, rash generalised, rash pruritic, rash macular, rash maculo-papular, rash pustular, rash vesicular, and rash erythematous.
				</li>
			</ul>`
	},

	'10': {
		content: `
			<ul class="footnotes">
				<li>
					<span class="pre">*</span>
					Major hypoglycaemia was defined as a symptomatic episode requiring external assistance due to severely impaired consciousness or behaviour, with capillary or plasma glucose levels of 54 mg/dL (3.0 mmol/L) and recovery after glucose or glucagon administration.<sup class="ref">1</sup>
					<ul class="formatted">
						<li>
							Minor hypoglycaemia was defined as a symptomatic episode with capillary or plasma glucose levels of 63 mg/dL (3.5 mmol/L), irrespective of the need for external assistance, or an asymptomatic episode with capillary or plasma glucose levels of 63 mg/dL (3.5 mmol/L) that did not qualify as a major episode.<sup class="ref">1</sup>
						</li>
						<li>
							Other hypoglycaemia was defined as an episode with symptoms suggestive of hypoglycaemia but without measurement confirmation.<sup class="ref">1</sup>
						</li>
					</ul>
				</li>
			</ul>
		`,
		references: ['nauck']
	},

	'11': {
		content: `
			<ul class="footnotes">
				<li>
					<span class="pre">*</span>
					A 24-week randomised, double-blind, parallel-group phase 3 study, with a 28 week blinded extension period,
					to evaluate the safety and efficacy of FORXIGA<sup>®</sup> in combination with metformin + sulphonylurea
					compared with placebo. Patients enrolled in the study were aged ≥18 years with HbA<sub>1c</sub> ≥7.0 - ≤10.5% with
					type 2 diabetes inadequately controlled on metformin + sulphonylurea. FORXIGA<sup>®</sup> was given as 10 mg alongside
					metformin at ≥1500 mg/day and a maximum tolerated dose of sulphonylurea. Metformin could not be down-titrated and sulphonylurea could only be down-titrated once to reduce hypoglycaemic events.<sup class="ref">1</sup>
					<ul class="formatted">
						<li>The primary endpoint of the study was mean change in HbA<sub>1c</sub> from baseline to week 24. Secondary endpoints included mean change in fasting blood plasma glucose, mean change in body weight and proportion of patients achieving HbA<sub>1c</sub> <7.0% at week 24.</li>
					</ul>
				</li>
			</ul>
		`,
		references: ['matthaei-2015-2']
	},
};



/// Study design content
var Studies = {
	'nauck': {
		content: `
			<h1 class="title">Nauck MA <i>et al.</i> 2011: study details</h1>
			<p class="copy">This was a 52-week randomised, double-blind, parallel-group, active-controlled, phase III, noninferiority trial with a 156-week extension period, conducted at 95 sites in 10 countries. The study aimed to evaluate the safety and efficacy of FORXIGA<sup>®</sup> 10 mg + metformin (>1500 mg/day) vs glipizide + metformin (>1500 mg/day) in patients with inadequate glycaemic control (HbA<sub>1c</sub> 6.5% and ≤10%) receiving oral antidiabetic medication including metformin.</p>
			<p class="copy">After a 2-week, single-blind, placebo lead-in period, patients were randomised in a 1:1 ratio using a computer-generated randomisation scheme to receive double-blind treatment with FORXIGA<sup>®</sup> or glipizide. During the first 18-week period, patients were uptitrated from starting doses of FORXIGA<sup>®</sup> 2.5 mg/day or glipizide 5 mg/day, rising to 10 mg/day or 20 mg/day, respectively, until glycaemic control was achieved or the maximum tolerable dose was reached. Following this, patients entered a 34-week maintenance period during which no further uptitration was allowed.</p>
			<p class="copy">The primary endpoint was absolute change in HbA<sub>1c</sub> from baseline to week 52. Key secondary end points were absolute change in total body weight from baseline to week 52, the proportion of patients reporting at least one episode of hypoglycaemia, and the proportion of patients achieving a bodyweight decrease ≥5% from baseline to week 52.</p>
			<p class="copy">Safety assessments included adverse events (of special interest urinary tract and genital infections), hypoglycaemic events, laboratory abnormalities, and vital signs.</p>
			<p class="copy">Values for the additional 104-week extension (to week 208) were presented by Del Prato S <i>et al.</i> at the 73<sup>rd</sup> Scientific Sessions of the American Diabetes Association, Chicago, Illinois, June 21-25, 2013.<sup class="ref">1</sup></p>
		`,
		references: ['prato']
	},

	'bailey': {
		content: `
			<h1 class="title">Bailey CJ <i>et al.</i> 2010: study details</h1>
			<p class="copy">A phase III, multicentre, randomised, double-blind, placebo-controlled, parallel-group, 24-week clinical study, plus a 78-week extension period, to evaluate the efficacy and safety of FORXIGA<sup>®</sup> 10 mg + metformin (>1500 mg/day) vs placebo + metformin (>1500 mg/day) in adult patients with type 2 diabetes who had inadequate glycaemic control.</p>
			<p class="copy">Patients were enrolled into a 2-week, single-blind, lead-in period in which patients received placebo to assess compliance. Patients who successfully completed the lead-in period were randomly assigned 1:1:1:1 by a central interactive voice response system to double-blinded groups of once-daily FORXIGA<sup>®</sup> 2.5 mg, 5 mg, or 10 mg, or matching placebo before the morning meal for 24 weeks. Randomisation was stratified by investigation site, and randomisation schedules were computer-generated.</p>
			<p class="copy">The primary outcome was change from baseline in HbA<sub>1c</sub> at 24 weeks. Key secondary endpoints included changes in fasting plasma glucose concentration and total body weight at week 24, proportion of patients achieving a therapeutic glycaemic response (defined as HbA<sub>1c</sub> <7% (53 mmol/mol) at week 24, and change in HbA<sub>1c</sub> percentage at week 24 for patients with a baseline HbA<sub>1c</sub> of 9% (75 mmol/mol or more).</p>
			<p class="copy">Safety assessments included adverse events (of special interest urinary tract and genital infections), changes in blood pressure and hypoglycaemic events.</p>
			<p class="copy">Values for the 78-week extension (to week 102) were presented by Bailey CJ <i>et al.</i> at the 71<sup>st</sup> Scientific Sessions of the American Diabetes Association 2011.<sup class="ref">1</sup></p>
		`,
		references: ['bailey-2013']
	},

	'yang': {
		content: `
			<h1 class="title">Yang W <i>et al.</i> 2016: study details</h1>
			<p class="copy">A randomised, double-blind, placebo-controlled, parallel-group, Phase III study with a 6-week lead-in period, 24-week treatment period, and a 4-week follow-up period. The study was conducted between June 2010 and March 2013, at 32 sites, in adults aged ≥18 years. Inclusion criteria included adults inadequately controlled blood glucose (HbA<sub>1c</sub> at screening ≥7.5% and ≤10.5%) and on stable metformin monotherapy (≥8 weeks, ≥1500 mg/day).</p>
			<p class="copy">Eligible patients completed a 6-week, single-blind, placebo lead-in period during which they were maintained on open-label metformin at their pre-enrolment dose (≥1500 mg/day). Patients completing the lead-in period were randomised (stratified by site) 1:1:1 to FORXIGA<sup>®</sup> 5 mg, FORXIGA<sup>®</sup> 10 mg, or placebo, randomised by a computer-generated randomisation scheme using an interactive voice response system.</p>
			<p class="copy">The primary endpoint was mean change from baseline in HbA<sub>1c</sub> at week 24 for each FORXIGA<sup>®</sup> group vs placebo. Secondary endpoints included changes from baseline at week 24 in fasting plasma glucose, 2-hour postprandial glucose, total body weight, and the proportion of patients achieving a therapeutic glycaemic response (HbA<sub>1c</sub> <7.0%).</p>
			<p class="copy">Safety assessments included adverse events, changes in blood pressure and hypoglycaemic events.</p>
		`
	},

	'mueller': {
		content: `
			<h1 class="title">Müller-Wieland D <i>et al</i>: study details</h1>
			<p class="copy">A 52-week, multicentre, randomised, parallel-group, double-blind, active-controlled Phase IV study. The study aimed to evaluate the efficacy and safety of FORXIGA<sup>®</sup> and FORXIGA<sup>®</sup> + saxagliptin compared with glimepiride when added to metformin in patients with type 2 diabetes who required additional glycaemic control.</p>
			<p class="copy">938 patients aged ≥18 years from sites in 5 countries were randomised 1:1:1 to receive either FORXIGA<sup>®</sup> plus metformin, FORXIGA<sup>®</sup> plus saxagliptin plus metformin or glimepiride plus metformin.</p>
			<p class="copy">The primary outcome was change HbA<sub>1c</sub> from baseline to end of treatment at week 52. Key secondary endpoints included: proportion of patients reporting at least one episode of symptomatic hypoglycaemia (<50 mg/dL [<2.8 mmol/L]), change from baseline in body weight and fasting plasma glucose at week 52.</p>
			<p class="copy">Safety assessments included adverse events (of special interest urinary tract and genital infections and ketoacidosis) and hypoglycaemic events.</p>
		`
	},

	'rosenstock': {
		content: `
			<h1 class="title">Rosenstock J <i>et al.</i> 2015: study details</h1>
			<p class="copy">A 24-week, multicentre, randomised, double blind, active-controlled, parallel-group phase 3 study. Eligible patients were aged ≥18 years with type 2 diabetes and inadequate glycaemic control, defined as HbA<sub>1c</sub> ≥8.0% and ≤12.0% (64–108 mmol/mol) at screening. Patients had to be stable on metformin therapy (≥1500 mg/day) for ≥8 weeks before screening and have C-peptide concentrations ≥1.0 ng/mL and a body mass index ≤45.0 kg/m<sup>2</sup> at screening.</p>
			<p class="copy">At the beginning of a 4-week lead-in period, patients who had been on stable metformin therapy for at least 8 weeks before screening were switched to the nearest metformin extended release dose (1500-2000 mg/day) for the lead-in period and for the duration of the 24-week double blind treatment period. Patients were randomised 1:1:1 using a centralised blocked randomisation schedule to receive saxagliptin (5 mg/day) and FORXIGA<sup>®</sup> (10 mg/day) and placebo plus metformin (FORXIGA<sup>®</sup> + metformin) for 24 weeks.</p>
			<p class="copy">The primary endpoint was the adjusted mean change from baseline in HbA<sub>1c</sub> after 24 weeks of double-blind treatment. Secondary endpoints were adjusted mean change from baseline at 24 weeks in 2-h postprandial glucose, adjusted mean change from baseline at 24 weeks in fasting plasma glucose, adjusted mean proportion of patients achieving a therapeutic glycaemic response, defined as HbA<sub>1c</sub> <7.0% (53 mmol/mol), after 24 weeks, and the adjusted mean change from baseline in bodyweight.</p>
			<p class="copy">Safety assessments included adverse events, hypoglycaemic events, laboratory abnormalities, and vital signs.</p>
		`
	},

	'frias': {
		content: `
			<h1 class="title">Frías <i>et al.</i> 2016: study details</h1>
			<p class="copy">DURATION-8 was a 28 week, multicentre, double-blind, randomised, active-controlled phase 3 trial at 109 sites in six countries, and a subsequent 52-week extension. Adults (aged ≥18 years) with type 2 diabetes and inadequate glycaemic control (HbA<sub>1c</sub> 8–12% [64–108 mmol/mol]) despite stable metformin monotherapy (≥1500 mg/day) were randomly assigned 1:1:1.</p>
			<p class="copy">695 patients were randomly assigned to receive once-weekly exenatide 2 mg by subcutaneous injection plus once-daily FORXIGA<sup>®</sup> 10 mg oral tablets (n=231), exenatide with FORXIGA<sup>®</sup>-matched oral placebo (n=231; n=1 untreated), or FORXIGA<sup>®</sup> with exenatide matched placebo injections (n=233). Randomisation was stratified by baseline HbA<sub>1c</sub> (<9.0% vs ≥9.0% [<75 mmol/mol vs ≥75 mmol/mol]). The intention-to-treat population comprised 685 participants (mean HbA<sub>1c</sub> 9.3% [SD 1.1]; 78 mmol/mol), of whom 611 (88%) completed the study.</p>
			<p class="copy">The primary endpoint was change in HbA<sub>1c</sub> from baseline to week 28. Secondary endpoints were the change from baseline in fasting plasma glucose at week 2 and week 28, and 2 h postprandial glucose at week 28; the proportion of patients with an HbA<sub>1c</sub> less than 7.0% (<53 mmol/mol) at week 28; change in weight at week 28; the proportion of patients with weight loss of 5% or more at week 28; and change in systolic blood pressure at week 28. Analyses were by intention-to-treat.</p>
			<p class="copy">Safety assessments included adverse events, laboratory abnormalities, vital signs, and hypoglycaemic events.</p>
			<p class="copy">Values for the 52-week extension were presented by Guja C <i>et al.</i> at the 77<sup>th</sup> American Diabetes Association Scientific Sessions; June 9-13, 2017, San Diego, CA.<sup class="ref">1</sup></p>
		`,
		references: ['guja']
	},

	'shatskov': {
		content: `
			<h1 class="title">Shatskov A <i>et al.</i> 2016: study details</h1>
			<p class="copy">This study was a post-hoc analysis of data pooled from 10 FORXIGA<sup>®</sup> phase III, randomised, double-blind, placebo-controlled, 24-week studies in adults (≥18 years of age) with type 2 diabetes (T2D) and body mass index (BMI) ≤45 kg/m<sup>2</sup>. The study aimed to assess the efficacy and safety of FORXIGA<sup>®</sup> 5 and 10 mg once daily in subgroups of patients with T2D stratified by BMI category.</p>
			<p class="copy">FORXIGA<sup>®</sup> 5 or 10 mg or placebo were administered as:</p>
			<ul class="formatted">
				<li>Monotherapy in treatment-naive patients (NCT00528372)</li>
				<li>Initial combination therapy with metformin (NCT00859898)</li>
				<li>Add-on to the following:
					<ul class="formatted">
						<li>Metformin (NCT00855166, NCT00528879)</li>
						<li>Glimepiride (NCT00680745) </li>
						<li>Pioglitazone* (NCT00683878)</li>
						<li>Sitagliptin ± metformin (NCT00984867)</li>
						<li>Insulin ± up to 2 other anti-diabetic medications (NCT00673231)</li>
						<li>Usual care in patients with CVD (NCT01042977)</li>
						<li>Usual care in patients with CVD and hypertension (NCT01031680)</li>
					</ul>
				</li>
			</ul>
			<p class="copy">Changes from baseline to week 24 in HbA<sub>1c</sub>, body weight, and systolic blood pressure were analysed in patients stratified by BMI (kg/m<sup>2</sup>) categories:</p>
			<ul class="formatted">
				<li>Normal weight: 18.5 ≤ 25 kg/m<sup>2</sup></li>
				<li>Overweight: 25 ≤ 30 kg/m<sup>2</sup></li>
				<li>Obese Class I: 30 ≤ 35 kg/m<sup>2</sup></li>
				<li>Obese Class II: 35 ≤ 40 kg/m<sup>2</sup></li>
				<li>Obese Class III: >40 kg/m<sup>2</sup></li>
			</ul>
			<p class="copy">Longitudinal repeated measures analyses were performed using a model that included baseline, treatment, subgroup, week, and the following interaction terms: week-by-treatment, week-by-baseline, treatment-by-subgroup, study-by-baseline, and week-by-treatment-by-subgroup.</p>
			<p class="copy">Adverse events were recorded during the 24-week study period for each trial in the pooled data set.</p>
			<footer class="notes statically">*The use of FORXIGA<sup>®</sup>/XIGDUO<sup>™</sup> with pioglitazone is not recommended.<sup class="ref">1</sup></footer>
		`,
		references: ['forxiga']
	},

	'weber': {
		content: `
			<h1 class="title">Weber MA <i>et al.</i> 2016: study details</h1>
			<p class="copy">A multi-centre, randomised, double-blind, placebo-controlled Phase III clinical trial within 311 centres in 16 countries. Eligible patients were those with type 2 diabetes, inadequate glycaemic control (HbA<sub>1c</sub> 7.0%–10.5%; 53–91 mmol/mol), and inadequately controlled hypertension (systolic 140–165 mm Hg and diastolic 85–105 mm Hg). The study aimed to analyse the efficacy and safety of FORXIGA<sup>&reg</sup> 10 mg for reduction of systolic blood pressure (BP) and HbA<sub>1c</sub> in 449 adult patients with type 2 diabetes (T2D) and inadequate glycaemic and BP control.</p>
			<p class="copy">Patients were randomly assigned (1:1) to receive FORXIGA<sup>®</sup> 10 mg once daily or matched placebo. Randomisation was stratified by type of additional antihypertensive medication use and insulin use. Randomisation was done by interactive voice response system. Patients with T2D and elevated BP (seated systolic 140 and <165 mm Hg + seated diastolic blood 85 < 105 mm Hg) were randomised to placebo (n=244) or FORXIGA<sup>®</sup> 10 mg (n=225) for 12 weeks in addition to their multidrug regimen. The trial consisted of a qualification period (14 days or less after enrolment), a lead-in period (4 weeks), a double-blind treatment period (12 weeks), and a follow-up period (1 week).</p>
			<p class="copy">The co-primary endpoints were changes from baseline to week 12 in seated systolic blood pressure and HbA<sub>1c</sub>. Secondary endpoints included change from baseline to week 12 in 24-hour ambulatory BP, seated BP, and serum uric acid.</p>
			<p class="copy">Safety evaluations over the study period included adverse events, laboratory variables, and vital signs.</p>
		`
	},

	'cprd': {
		content: `<img width="845" height="1032" src="assets/popups/3.0.0.1.png">`,
		references: ['wilding-2015', 'wilding-2017', 'dof-017', 'forxiga', 'wilding-2016']
	},

	'hardy': {
		content: `
			<h1 class="title">Hardy E <i>et al.</i> 2012: study details</h1>
			<p class="copy">This study aimed to analyse the distribution of change from baseline to week 24 in HbA<sub>1c</sub> and body weight in individual patients with type 2 diabetes (T2D) pooled from 5 of the core FORXIGA<sup>®</sup> phase III, placebo-controlled clinical trials.</p>
			<p class="copy">Patients with T2D received FORXIGA<sup>®</sup> 10 mg/d (N=690) or placebo (N=689) for 24 weeks as:</p>
			<ul class="formatted">
				<li>Monotherapy (NCT00528372)</li>
				<li>Add-on to metformin, ≥1500 mg/d (NCT00528879)</li>
				<li>Add-on to glimepiride, 4 mg/d (NCT00690745)</li>
				<li>Add-on to pioglitazone up to 45 mg/d (NCT00683878)*</li>
				<li>Add-on to insulin, mean dose at baseline 77 IU/d (NCT00673231)</li>
			</ul>
			<p class="copy">The primary efficacy end point was the change from baseline HbA<sub>1c</sub> after 24 weeks of treatment. The secondary endpoint was the change from baseline in body weight.</p>
			<footer class="notes">*The use of FORXIGA<sup>®</sup>/XIGDUO<sup>™</sup> with pioglitazone is not recommended.<sup class="ref">1</sup></footer>
		`,
		references: ['forxiga']
	},

	'qtern-studies': {
		content: `
			<h1 class="title">Study details</h1>
			<ul class="formatted">
				<li>In patients inadequately controlled on dapagliflozin plus metformin who received add-on therapy with saxagliptin (-0.51 vs -0.16 for saxagliptin add-on and placebo add-on, respectively [P<0.0001])<sup class="ref">1</sup></li>
				<li>The addition of saxagliptin to dapagliflozin plus metformin provided glycaemic control, as demonstrated by improvements in HbA<sub>1c</sub> from baseline to 52 weeks compared with placebo add-on (between-group difference: -0.42% [95% CI -0.64, -0.20%)<sup class="ref">2</sup></li>
				<li>No major hypoglycaemic events were reported in clinical trials<sup class="ref">3</sup></li>
				<li>1.4% of patients on metformin plus QTERN<sup>™</sup> experienced hypoglycaemic events<sup class="ref">3</sup></li>
			</ul>
		`,
		references: ['matthaei-2015', 'matthaei-2016', 'qtern']
	},

	'matthaei': {
		content: `
			<h1 class="title">Matthaei S <i>et al.</i> 2015: study details</h1>
			<p class="copy">This was a multicentre, randomised, double-blind, placebo-controlled, parallel-group, phase III study. The study design consisted of a screening period and an open-label treatment period before randomisation, and a short-term (24 weeks), double-blind treatment period. Patients could then enter a long-term, 28 weeks extension, for a total of 52 weeks of triple-therapy treatment.</p>
			<p class="copy">Eligible patients with type 2 diabetes (T2D) had glycated haemoglobin (HbA<sub>1c</sub>) 8.0–11.5% (64–102 mmol/mol) at screening and taking stable metformin immediate release (IR) or extended release (XR) (≥1500 mg/day) for at least 8 weeks before screening. At the end of the screening period, patients were switched to 16 weeks of open-label treatment with the nearest multiple of metformin IR 500 mg and FORXIGA<sup>®</sup> (10 mg/day). For inclusion into the randomised, 24-week, double blind treatment period, patients had to have an HbA<sub>1c</sub> 7.0–10.5% (53–91 mmol/mol) at week 2 of the open-label treatment period. Following the open-label period, eligible patients were randomised 1:1 using a centralised blocked randomised schedule. Patients received placebo or saxagliptin 5 mg/day in addition to open-label FORXIGA<sup>®</sup> 10 mg/day and metformin IR for 24 weeks. Patients completing the double-blind period could enter the 28-week long-term extension.</p>
			<p class="copy">The primary endpoint was the mean change from baseline in HbA<sub>1c</sub> after 24 weeks of double-blind treatment with saxagliptin vs a placebo add-on to FORXIGA<sup>®</sup> plus metformin. Secondary endpoints were mean change from baseline at 24 weeks in 2-hour postprandial glucose following a liquid meal tolerance test, mean change from baseline at 24 weeks in fasting plasma glucose and the proportion of patients achieving a therapeutic glycaemic response, defined as HbA<sub>1c</sub> <7.0% (53 mmol/mol), at 24 weeks.</p>
			<p class="copy">Safety evaluations included adverse events, hypoglycaemia, laboratory abnormalities and vital signs.</p>
			<p class="copy">Results from the full 52-week treatment period were published by Matthaei S <i>et al.</i> 2016.<sup class="ref">1</sup></p>
		`,
		references: ['matthaei-2016']
	},

	'matthaei-triple': {
		content: `
			<h1 class="title">Matthaei S <i>et al.</i> 2015: study details</h1>
			<p class="copy">A 24-week randomised, double-blind, parallel-group, phase III study to evaluate the efficacy and safety of FORXIGA<sup>®</sup> in combination with metformin + sulphonylurea compared with placebo.</p>
			<p class="copy">Patients enrolled in the study were aged ≥18 years with HbA<sub>1c</sub> ≥7.0% (53 mmol/mol) to ≤10.5% (91 mmol/mol) with type 2 diabetes inadequately controlled on metformin + sulphonylurea. FORXIGA<sup>®</sup> was given as 10 mg alongside metformin at >1500 mg/day and a maximum tolerated dose of sulphonylurea. Sulphonylurea could only be down-titrated once to reduce hypoglycaemic events.</p>
			<p class="copy">The primary endpoint of the study was mean change in HbA<sub>1c</sub> from baseline to week 24. FORXIGA<sup>®</sup> resulted in significant HbA<sub>1c</sub> reductions compared with placebo when used in combination with metformin plus sulphonylurea.</p>
			<p class="copy">Secondary endpoints included mean change in fasting blood plasma glucose, mean change in total body weight and proportion of patients achieving HbA<sub>1c</sub> <7.0% at week 24.</p>
			<p class="copy">FORXIGA<sup>®</sup> when used as add-on treatment to metformin + sulphonylurea was well tolerated over 24 weeks in patients with type 2 diabetes mellitus. The majority of AEs observed were mild to moderate, and were not considered related to treatment.</p>
			<p class="copy">There were no major episodes of hypoglycaemia, and no events of hypoglycaemia led to discontinuation in either group.</p>
		`
	},

	'mathieu': {
		content: `
			<h1 class="title">Mathieu C <i>et al.</i> 2015: study details</h1>
			<p class="copy">This was a multicentre, randomised, double-blind, placebo-controlled, parallel-group, phase III study. The study design consisted of a screening and open-label treatment period followed by a randomised, 24-week, short-term, double-blind treatment period. This was followed with a long-term extension of an additional 28 weeks, for a total of 52 weeks of triple therapy.</p>
			<p class="copy">Two groups of patients (≥18 years of age) with type 2 diabetes (T2D) and inadequate glycaemic control were included in the open-label treatment period based on DPP-4 inhibitor (DPP-4i) use. Patients in stratum A had a glycated haemoglobin (HbA<sub>1c</sub>) level of 8.0–11.5% (64–102 mmol/mol) at screening and were receiving stable metformin therapy (immediate release [IR] or extended release [XR] >1500 mg/day) for at least 8 weeks before screening. These patients were switched to the nearest lower dose or higher multiple of metformin IR 500-mg tablets and saxagliptin 5 mg/day for 16 weeks of open-label treatment. Patients in stratum B had an HbA<sub>1c</sub> level of 7.5–10.5% (58–91 mmol/mol) and were receiving stable metformin (IR or XR >1500 mg/day) and a DPP-4i at the maximum approved dose for at least 8 weeks before the screening visit. These patients were switched to the nearest lower or higher multiple of metformin IR 500-mg tablets and any DPP-4i was replaced by saxagliptin 5 mg/day. The patients in this regimen received 8 weeks of open-label treatment.</p>
			<p class="copy">The primary endpoint was the mean change from baseline HbA<sub>1c</sub> level after 24 weeks of double-blind treatment with FORXIGA<sup>®</sup> vs placebo add-on to saxagliptin plus metformin. Secondary endpoints were the mean change from baseline at 24 weeks in fasting plasma glucose, 2-hour postprandial glucose level following a liquid meal tolerance test, body weight and the mean proportion of patients achieving a therapeutic glycaemic response, defined as HbA<sub>1c</sub> level of <7.0% (53 mmol/mol), after 24 weeks.</p>
			<p class="copy">Safety evaluations included adverse events, hypoglycaemia, laboratory abnormalities and vital signs.</p>
			<p class="copy">Results from the full 52-week treatment period were published by Mathieu C <i>et al.</i> 2016.<sup class="ref">1</sup></p>
		`,
		references: ['mathieu-2016']
	},

	'mamza': {
		content: `
			<h1 class="title">Mamza J <i>et al.</i> 2015: study details</h1>
			<p class="copy">Sitagliptin add-on to metformin: HbA<sub>1c</sub> and weight outcomes in a UK real world setting.</p>
			<p class="copy">This retrospective cohort analysis aimed to assess the relative efficacy of co-administering sitagliptin to patients with inadequate glycaemic control following treatment with metformin (MET), sulfonylurea (SU), or MET + SU. A cohort of 25,386 patients with type 2 diabetes with inadequate glycaemic control (HbA<sub>1c</sub> 53 mmol/mol, or 7%), newly treated with sitagliptin between 2007–2013, was sourced from UK general practices via The Health Improvement Network database.</p> Data included real world evidence, cross sectional, observational, burden of illness, registry, survey or large cohort studies.
			<p class="copy">A total of 9,802 patients were included in the study. Patients were segregated into three groups: MET (n=3,364), SU (n=509), or MET + SU therapy (n=5,929). Patients were administered an average of 100 mg/day of sitagliptin. The follow-up period commenced from the index date until a switch to or addition of another antidiabetic drug, or the 90th day post-index date when HbA<sub>1c</sub> level is recorded, or 52 weeks after the index date. </p>
			<p class="copy">The primary efficacy outcome was change from baseline in HbA<sub>1c</sub>  at 52 weeks. The secondary outcome was change in body weight from baseline up to 52 weeks.</p>
		`
	},

	'charbonnel': {
		content: `
			<h1 class="title">Charbonnel B <i>et al.</i> 2016: study details</h1>
			<p class="copy">This was a multinational, randomised, parallel-group study with a placebo-controlled, double-blind treatment period which aimed to assess the efficacy and safety of sitagliptin, added to metformin therapy, in patients with type 2 diabetes and inadequate glycaemic control with metformin alone.</p>
			<p class="copy">Men and women aged 18–78 years with type 2 diabetes and inadequate glycaemic control (HbA1c ≥7% and ≤10%) while taking metformin monotherapy at a stable dose of at least 1500 mg/day, either at entry into the study or after a metformin dose-stable run-in period, were eligible to be randomised. Patients were randomly assigned to receive the addition of placebo or sitagliptin 100 mg once-daily in a 1:2 ratio. The double-blind treatment period was 24 weeks.</p>
			<p class="copy">The primary efficacy end point was change from baseline at week 24 in HbA<sub>1c</sub>. Secondary efficacy end points included change from baseline at week 24 in fasting plasma glucose, as well as in glucose, insulin, and C-peptide concentrations, and a lipid panel. Efficacy analyses were based on the all-patients-treated population.</p>
			<p class="copy">Safety assessments included adverse events (of special interest hypoglycaemia and gastrointestinal disorders), laboratory abnormalities, and vital signs.</p>
		`
	},

	'jabbour': {
		content: `
			<h1 class="title">Jabbour S <i>et al.</i> 2013: study details</h1>
			<p class="copy">The aim of this study was to evaluate the efficacy of FORXIGA<sup>®</sup> as part of triple combination therapy. Pre-specified or post-hoc subgroup analyses were performed on the data from four published 24-week studies in patients with type 2 diabetes. The data from the full populations of these studies have been previously published and/or presented. </p>
			<p class="copy">FORXIGA<sup>®</sup> was administered to patients (triple therapy subgroups) with type 2 diabetes inadequately controlled on 2 existing anti-diabetic medications. </p>
			<ul class="formatted">
				<li>Sitagliptin + metformin </li>
				<li>Sulphonylurea + metformin (study A)</li>
				<li>Sulphonylurea + metformin (study B)</li>
				<li>Insulin + metformin </li>
			</ul>
			<p class="copy">Efficacy endpoints included reductions in HbA<sub>1c</sub> from baseline in each of the four individual studies compared with placebo following administration of FORXIGA<sup>®</sup> for 24 weeks. Secondary endpoints included reductions in body weight from baseline. Data of up to 48-week efficacy were presented.</p>
			<p class="copy">Safety assessments included adverse events: of special interest genital and urinary tract infection.</p>
		`
	},

	'bolinder-2012': {
		content: `
			<h1 class="title">Bolinder J <i>et al.</i> 2012: study details</h1>
			<p class="copy">This was a 24-week, international, multicentre, randomised, parallel-group, double-blind, placebo-controlled Phase III study with a 78-week site- and patient-blinded extension period at 40 sites in five countries. The study aimed to confirm weight loss with FORXIGA<sup>®</sup>, and establish through body composition measurements whether weight loss is accounted for by changes in fat or fluid components.</p>
			<p class="copy">The study comprised of 182 patients with type 2 diabetes inadequately controlled on metformin (HbA<sub>1c</sub> 6.5–8.5%). Patients were randomised in a 1:1 ratio to double-blind treatment with either FORXIGA<sup>®</sup> 10 mg/day or placebo added to open-label metformin for 24 weeks. Randomisation was performed in two strata within balanced block sizes of four. Patients were allocated to study treatments according to a predefined computer-generated randomisation scheme.</p>
			<p class="copy">The primary endpoint was change from baseline at week 24 in total body weight. Key secondary endpoints were changes from baseline at week 24 in waist circumference, total fat mass and the proportion of patients achieving body weight reduction of at least 5% at week 24.</p>
			<p class="copy">Safety assessments included adverse events (of special interest, genital and urinary tract infection), laboratory abnormalities and vital signs. Change from baseline in total bone mineral density at 24 weeks was evaluated post-hoc.</p>
			<p class="copy">Values for the additional extension (to week 102) were presented by Bolinder J et al. 2014.<sup class="ref">1</sup></p>
		`,
		references: ['bolinder-2014']
	},

	'bolinder-2014': {
		content: `
			<h1 class="title">Bolinder J <i>et al.</i> 2014: study details</h1>
			<p class="copy">This was a 24-week, international, multi-centre, randomised, parallel-group, double-blind, placebo-controlled, Phase III study with a 78-week site- and patient-blinded extension period conducted at 40 sites across 5 countries. The study aimed to assess the long-term glycaemic control, body composition and bone safety in patients with type 2 diabetes uncontrolled on metformin alone (HbA<sub>1c</sub> 6.5–8.5%) after 102 weeks of FORXIGA<sup>®</sup> treatment. This study presented the results from over 102 weeks of treatment.</p>
			<p class="copy">Patients were randomised in a 1:1 ratio to double-blind treatment with either FORXIGA<sup>®</sup> 10 mg/day or placebo added to open-label metformin for 24 weeks. Randomisation was performed in two strata within balanced block sizes of four. Patients were allocated to study treatments according to a predefined computer-generated randomisation scheme. This was followed by a 78-week site- and patient-blinded extension period. A total of 140 patients (76.9%) completed the study.</p>
			<p class="copy">At 102 weeks, the primary endpoints included changes from baseline in HbA<sub>1c</sub>. Secondary endpoints included weight, waist circumference, total body fat mass, serum markers of bone turnover and bone mineral density.</p>
			<p class="copy">Safety assessments included changes from baseline over 102 weeks for bone-related parameters, adverse events (of special interest, genital and urinary tract infection), and laboratory abnormalities.</p>
		`
	}
};



/// Reference content
var References = {
	'forxiga': 'FORXIGA<sup>®</sup> Summary of Product Characteristics.',
	'qtern': 'QTERN<sup>™</sup> Summary of Product Characteristics. Available at https://www.medicines.org.uk/emc/<br>(Last accessed September 2017).',
	'onglyza': 'ONGLYZA<sup>®</sup> Summary of Product Characteristics.',
	'canagliflozin': 'Canagliflozin Summary of Product Characteristics. Available at https://www.medicines.org.uk/emc/<br>(Last accessed September 2017).',
	'empagliflozin': 'Empagliflozin Summary of Product Characteristics. Available at https://www.medicines.org.uk/emc/<br>(Last accessed September 2017).',
	'saxagliptin': 'Saxagliptin Summary of Product Characteristics. Available at https://www.medicines.org.uk/emc/<br>(Last accessed September 2017).',
	'sitagliptin': 'Sitagliptin Summary of Product Characteristics.',
	'mims-forxiga': 'FORXIGA<sup>®</sup> MIMS price. Available at http://www.mims.co.uk/drugs/diabetes/oral-and-parenteral-hypoglycaemics/forxiga<br>(Last accessed September 2017).',
	'mims-onglyza': 'ONGLYZA<sup>®</sup> MIMS price. Available at http://www.mims.co.uk/drugs/diabetes/oral-and-parenteral-hypoglycaemics/onglyza<br>(Last accessed September 2017).',
	'mims-qtern': 'QTERN<sup>™</sup> MIMS price. Available at http://www.mims.co.uk/drugs/diabetes/oral-and-parenteral-hypoglycaemics/qtern<br>(Last accessed September 2017).',
	'Xigduo': 'XIGDUO<sup>™</sup> Summary of Product Characteristics. ',
	'Stratton': 'Stratton IM, et al. BMJ 2000; 321:405-12.',
	'hill': 'Hill CJ <i>et al. Diabet Med.</i> 2014; <b>31</b>: 448–454.',
	'jansink': 'Jansink R <i>et al. BMC Fam Pract.</i> 2010; <b>11</b>: 41.',
	'daly': 'Daly JM <i>et al. J Am Board Fam Pract.</i> 2009; <b>22</b>(3): 280–290.',
	'pi-sunyer': 'Pi-Sunyer X. <i>Postgrad Med J.</i> 2009; <b>121</b>(5): 94–107.',
	'grandy-2012': 'Grandy S <i>et al. Cardiol Res Pract.</i> 2012; DOI: 10.1155/2012/892564.',
	'grandy-2014': 'Grandy S <i>et al. Diabetes Obes Metab.</i> 2014; <b>16</b>: 645–650.',
	'rosenstock': 'Rosenstock J <i>et al. Diabetes Care</i> 2015; <b>38</b>: 376–383.',
	'shatskov': 'Shatskov A <i>et al.</i> American Diabetes Association 76<sup>th</sup> Scientific Sessions, June 10–14, 2016. New Orleans, LA. Poster 1141-P.',
	'wilding-2015': 'Wilding J <i>et al.</i> European Association for the Study of Diabetes Annual Meeting, September 14–18 2015; Stockholm. Poster 737-P.',
	'wilding-2016': 'Wilding J <i>et al. Diabetes Ther.</i> 2016; <b>7</b>: 695–711.',
	'wilding-2017': 'Wilding J <i>et al. Prim Care Diabetes</i> 2017. DOI http://dx.doi.org/10.1016/j.pcd.2017.04.004.',
	'wilding-2017-appendix': 'Wilding J <i>et al. Prim Care Diabetes</i> 2017. DOI http://dx.doi.org/10.1016/j.pcd.2017.04.004: Appendix A. Supplementary data.',
	'nauck': 'Nauck MA <i>et al. Diabetes Care</i> 2011; <b>34</b>: 2015–2022.',
	'bailey-2010': 'Bailey CJ <i>et al. Lancet</i> 2010; <b>375</b>: 2223–2233.',
	'bailey-2013': 'Bailey CJ <i>et al. BMC Medicine</i> 2013; <b>11</b>: 43.',
	'yang': 'Yang W <i>et al. J Diabetes</i> 2016; <b>8</b>: 796–808.',
	'mueller': 'Müller-Wieland D <i>et al.</i> Presented at the Annual Scientific Conference of the German Diabetes Association.',
	'frias': 'Frias JP <i>et al. Lancet Diabetes Endocrinol.</i> 2016; <b>4</b>: 1004–1016.',
	'weber': 'Weber MA <i>et al. Lancet Diabetes Endocrinol.</i> 2016; <b>4</b>: 211–220.',
	'hardy':  'Hardy E <i>et al.</i> American Diabetes Association 72<sup>nd</sup> Scientific Sessions, Philadelphia, PA, June 8–12, 2012.',
	'linetzky': 'Linetzky B <i>et al. J Diabetes</i> 2017; <b>9</b>: 596–605.',
	'whaley': 'Whaley JM <i>et al. Diabetes Metab Syndr Obes.</i> 2012; <b>5</b>: 135–148.',
	'geerlings': 'Geerlings SE. <i>Int J of Antimicrob Ag.</i> 2008; <b>31</b>: 554–557.',
	'idris': 'Idris I and Donnelly R. <i>Diabetes Obes Metab.</i> 2009; <b>11</b>: 79–88.',
	'ptaszynska': 'Ptaszynska A <i>et al.</i> American Diabetes Association 72<sup>nd</sup> Scientific Sessions, Philadelphia, PA, June 8–12, 2012. Poster 1098-P.',
	'list': 'List J <i>et al. Circulation</i> 2014; <b>130</b>: A16682.',
	'sonesson': 'Sonesson C <i>et al. Cardiovasc Diabetol.</i> 2016; <b>15</b>: 37.',
	'ljunggren': 'Ljunggren Ö <i>et al. Diabetes Obes Metab.</i> 2012; <b>14</b>: 990–999.',
	'mills': 'Mills L <i>et al. J Diabetes Nurs.</i> 2014; <b>18</b>: 8–12.',
	'andersson': 'Andersson Sundell K <i>et al.</i> Presented at the Consensus in Diabetes, Obesity and Hypertension (CODHy) 5<sup>th</sup> Annual World Congress, November 5–7, 2015.',
	'prato': 'Del Prato S <i>et al. Diabetes Obes Metab.</i> 2015; <b>17</b>: 581–590.',
	'matthaei-2015': 'Matthaei S <i>et al. Diabetes Care</i> 2015; <b>38</b>: 2018–2024.',
	'matthaei-2015-2': 'Matthaei S <i>et al. Diabetes Care</i> 2015; <b>38</b>: 365–372.',
	'matthaei-2016': 'Matthaei S <i>et al. Diabetes Obes Metab.</i> 2016; <b>18</b>: 1128–1133.',
	'lokhandwala': 'Lokhandwala T <i>et al. J Med Econ.</i> 2016; <b>19</b>: 203–212.',
	'mathieu-2015': 'Mathieu C <i>et al. Diabetes Care</i> 2015; <b>38</b>: 2009–2017.',
	'mathieu-2016': 'Mathieu C <i>et al. Diabetes Obes Metab.</i> 2016; <b>18</b>: 1134–1137.',
	'herrett': 'Herrett C <i>et al. Int J Epidemiol.</i> 2015; <b>44</b>: 827–836.',
	'mamza': 'Mamza J <i>et al. Diabetes Ther.</i> 2015; <b>6</b>: 213–226.',
	'charbonnel': 'Charbonnel B <i>et al. Diabetes Care</i> 2006; <b>29</b>: 2638–2643.',
	'jabbour': 'Jabbour S <i>et al.</i> Presented at the 49<sup>th</sup> Annual Meeting of the European Association for the Study of Diabetes (EASD), Barcelona, Spain, 23–27 September, 2013. Poster 938.',
	'bolinder-2012': 'Bolinder J. <i>J Clin Endocrinol Metab.</i> 2012; <b>97</b>: 1020–31.',
	'bolinder-2014': 'Bolinder J <i>et al. Diabetes Obes Metab.</i> 2014; <b>16</b>: 159–169.',
	'empa-reg': 'McGovern A <i>et al. Diabetes Ther.</i> 2017 <b>8</b>: 365–376.',
	'guja': 'Guja C <i>et al.</i> Poster presented at: 77<sup>th</sup> American Diabetes Association Scientific Sessions; June 9–13, 2017, San Diego, CA. Poster 141-LB.',

	'ims-midas': 'IQVIA Database, MIDAS October 2018.',
	'ims-quint': 'Quintiles IMS, BPI HPA data, days on therapy, January 2017 – July 2017 (DOF/031/Sept17).', // 'ims-lpd': 'IMS Health Longitudinal Patient Databases (CSD LPD), August 2016.',
	'phe-adult': 'Public Health England. Adult obesity and type 2 diabetes, 2014. Available at https://www.gov.uk/government/publications/adult-obesity-and-type-2-diabetes (Last accessed September 2017).',
	'phe-longer': 'Public Health England. Diabetes Longer Lives, 2017. Available at https://fingertips.phe.org.uk/diabetes (Last accessed September 2017).',
	'scotland': 'Diabetes in Scotland. Scottish Diabetes Survey 2016. Available at http://www.diabetesinscotland.org.uk/Publications.aspx (Last accessed September 2017).',
	'national': 'National Diabetes Audit – 2015–2016. Available at http://www.content.digital.nhs.uk/catalogue/PUB23241 (Last accessed September 2017).',
	'dof-017': 'Data on File: FOR/017/July 2016.',
	'dof-020': 'Data on File: FOR/020/September 2016.',
	'emdac': 'EMDAC Background Document 2016. BMS-512148, NDA 202293.',
	'declare': 'DECLARE-TIMI58. Available at https://clinicaltrials.gov/ct2/show/NCT01730534 (Last accessed September 2017).'
};




/// Page Swiping Queue
// Allows left/right swiping to go next/previous
// You can create isolated swiping queues by adding new arrays to this, e.g. [['pi-1', 'pi-2'], PrimaryPages.map(d => d.page]
// would allow swiping inside of pi-# OR the primary pages but would not allow pi-# to swipe onto the primary page queue
var SwipingQueues = [
	[
		'Splash',
		['UnderstandingBurden','UnderstandingChallenges', 'UnderstandingOutcomes'],
		'TolerabilityPatient',
		['IntroducingForxiga', 'IntroducingCPRD'],
		//'MicroMacroVascularRisk',
//		'MicroMacroVascularRisk',
		['ChangeEvidence', 'ChangeData'],
		['TolerabilityOverview', 'TolerabilityPractice', 'TolerabilityClinical'],
		['PrescribePositioning', 'PrescribeDosing'],
		'Duration-8',
		'Summary',
	],
	[
		'QternPreSummary',
		'QternPositioning',
		'QternEfficacy',
		'QternClinical',
		'QternDosing',
		'QternPostSummary',
	]



	// Generate a swiping queue from all the primary pages
// 	Object.keys(PrimaryPages).map(function(key) {
// 		var node = PrimaryPages[key];
// 		if(node.secondary) return Object.keys(node.secondary);
// 		return key;
// 	})
];





var LibraryData = [
	{
		type: 'hba1c',
		name: 'rwe-all',
		content: `RWE HbA<sub>1c</sub><br><small>(All)</small>`,
		popup: `<img width="100%" src="assets/popups/data-library/1.png" style="margin: auto;">`,
		studies: ['cprd'],
		references: ['wilding-2017-appendix', 'wilding-2015', 'dof-017']
	},
	{
		type: 'hba1c',
		name: 'rwe-triple',
		content: `RWE HbA<sub>1c</sub><br><small>(Triple)</small>`,
		popup: `<img width="100%" src="assets/popups/data-library/2.png" style="margin: auto;">`,
		studies: ['cprd'],
		references: ['wilding-2017-appendix', 'wilding-2015', 'dof-017']
	},
	// {
	// 	type: 'hba1c',
	// 	name: 'sita-rwe',
	// 	content: `Sitagliptin HbA<sub>1c</sub><br><small>(RWE)</small>`,
	// 	popup: `<img width="100%" src="assets/popups/data-library/3.png" style="margin: auto;">`,
	// 	studies: ['mamza'],
	// 	references: ['mamza']
	// },
	// {
	// 	type: 'hba1c',
	// 	name: 'site-rct',
	// 	content: `Sitagliptin HbA<sub>1c</sub><br><small>(RCT)</small>`,
	// 	popup: `<img width="100%" src="assets/popups/data-library/4.png" style="margin: auto;">`,
	// 	studies: ['charbonnel'],
	// 	references: ['charbonnel']
	// },
	{
		type: 'hba1c',
		name: 'triple-rct',
		content: `Triple Therapy HbA<sub>1c</sub><br><small>(RCT)</small>`,
		popup: `<img width="100%" src="assets/popups/data-library/5.png" style="margin: auto;">`,
		studies: ['matthaei-triple'],
		footnotes: ['11'],
		references: ['matthaei-2015-2', 'forxiga']
	},
	{
		type: 'hba1c',
		name: 'triple-post',
		content: `Triple Therapy HbA<sub>1c</sub><br><small>(Post-Hoc)</small>`,
		popup: `<img width="100%" src="assets/popups/data-library/6.png" style="margin: auto;">`,
		studies: ['jabbour'],
		references: ['jabbour']
	},
	{
		type: 'hba1c',
		name: 'dpp-rct',
		content: `DPP-4i HbA<sub>1c</sub><br><small>(RCT)</small><br>`,
		popup: `<img width="100%" src="assets/popups/data-library/7.png" style="margin: auto;">`,
		studies: ['rosenstock'],
		references: ['rosenstock', 'dof-020']
	},

	{
		type: 'weight',
		name: 'rwe-all',
		content: `RWE Weight<br><small>(All)</small>`,
		popup: `<img width="100%" src="assets/popups/data-library/8.png" style="margin: auto;">`,
		studies: ['cprd'],
		references: ['wilding-2017-appendix', 'forxiga', 'wilding-2015', 'dof-017']
	},
	{
		type: 'weight',
		name: 'rwe-triple',
		content: `RWE Weight<br><small>(Triple)</small>`,
		popup: `<img width="100%" src="assets/popups/data-library/9.png" style="margin: auto;">`,
		studies: ['cprd'],
		references: ['wilding-2017-appendix', 'forxiga', 'wilding-2015', 'dof-017']
	},
	// {
	// 	type: 'weight',
	// 	name: 'sita',
	// 	content: `Sitagliptin Weight<br><small>(RCT and RWE)</small>`,
	// 	popup: `<img width="100%" src="assets/popups/data-library/10.png" style="margin: auto;">`,
	// 	studies: ['mamza'],
	// 	references: ['sitagliptin', 'mamza']
	// },
	// {
	// 	type: 'weight',
	// 	name: 'triple-rct',
	// 	content: `Triple Therapy Weight<br><small>(RCT)</small>`,
	// 	popup: `<img width="100%" src="assets/popups/data-library/11.png" style="margin: auto;">`,
	// 	studies: ['matthaei-triple'],
	// 	footnotes: ['11'],
	// 	references: ['matthaei-2015-2', 'forxiga']
	// },
	// {
	// 	type: 'weight',
	// 	name: 'triple-post',
	// 	content: `Triple Therapy Weight<br><small>(Post-Hoc)</small>`,
	// 	popup: `<img width="100%" src="assets/popups/data-library/12.png" style="margin: auto;">`,
	// 	studies: ['jabbour'],
	// 	references: ['jabbour', 'forxiga']
	// },
	// {
	// 	type: 'weight',
	// 	name: 'type',
	// 	content: `Type of Weight Loss<br><small>(RCT)</small>`,
	// 	popup: `<img width="100%" src="assets/popups/data-library/13.png" style="margin: auto;">`,
	// 	studies: ['bolinder-2012', 'bolinder-2014'],
	// 	references: ['bolinder-2014', 'bolinder-2012', 'forxiga']
	// },
	{
		type: 'weight',
		name: 'dpp',
		content: `DPP-4i Weight<br><small>(RCT)</small>`,
		popup: `<img width="100%" src="assets/popups/data-library/14.png" style="margin: auto;">`,
		studies: ['rosenstock'],
		references: ['rosenstock', 'dof-020', 'forxiga', 'onglyza']
	},

	{
		type: 'other',
		name: 'hypo',
		content: `Hypoglycaemia`,
		popup: `<img width="100%" src="assets/popups/data-library/15.png" style="margin: auto;">`,
		studies: ['nauck'],
		footnotes: ['10'],
		references: ['nauck'],
	},
	{
		type: 'other',
		name: 'mace',
		content: `CV-MACE Table`,
		popup: `<img width="100%" src="assets/popups/data-library/16.png" style="margin: auto;">`,
		references: ['sonesson', 'forxiga']
	},
	{
		type: 'other',
		name: 'table',
		content: `Indications & Dosing Table`,
		popup: `<img width="100%" src="assets/popups/data-library/17.png" style="margin: auto;">`,
		references: ['forxiga']
	}
];

var DataLibraryReferences = LibraryData
	.reduce(function(p, c) {
		p[`${c.type}-${c.name}`] = c;
		return p;
	}, {});



var Objections = {
	'empa-reg': {
		popup: `<img width="100%" src="assets/popups/common-objections/empa-reg.png" style="margin: auto;">`,
		references: ['empa-reg']
	},

	'egfr': {
		popup: `<img width="100%" src="assets/popups/common-objections/egfr.png" style="margin: auto;">`,
		references: ['ptaszynska', 'forxiga']
	}
};
