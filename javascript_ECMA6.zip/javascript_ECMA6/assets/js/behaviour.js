/*(function googleTagManager() {
	var trackingIdentifier = 'UA-69780732-4';

	/// Check if already there, otherwise queue up all function calls
	window.dataLayer = window.dataLayer || [];
	window.gtag = function gtag() { dataLayer.push(arguments) };

	/// Download script
	var a = document.createElement('script');
	a.async = 1;
	a.src = 'https://www.googletagmanager.com/gtag/js?id=' + trackingIdentifier;
	document.head.appendChild(a);

	/// Initialise
	gtag('js', new Date());
	gtag('config', trackingIdentifier);
})();*/



(function commonMarkup() {
	var markup = `
		<nav class="secondary"></nav>
		<nav class="primary"></nav>

		<div class="mask popup"></div>

		<aside class="popup data-library" data-popup="data-library" style="display: flex">
			<div class="recommended">
				<h1 class="section">
					RECOMMENDED DATA
				</h1>
				<ul class="data recommended horizontal">

				</ul>
				<hr class="divider"/>
			</div>
			<h1 class="section">
				ALL DATA
			</h1>
			<div class="columns">
				<div class="column hba1c">
					<h2 class="category">
						<span class="icon-shape hba1c">
							HbA<sub>1c</sub> Data
						</span>
					</h2>
					<ul class="data hba1c vertical"></ul>
				</div>
				<div class="column weight">
					<h2 class="category">
						<span class="icon-shape weight">
							Weight Data
						</span>
					</h2>
					<ul class="data weight vertical"></ul>
				</div>
				<div class="column other">
					<h2 class="category">
						<span class="icon-shape other">
							Other Data
						</span>
					</h2>
					<ul class="data other vertical"></ul>
				</div>
			</div>

			<button class="close"></button>
		</aside>

		<div class="mask studies"></div>

		<aside class="modal details studies is-hidden">
			<div class="content scrollable"></div>
			<button class="open">STUDY DETAILS</button>
			<button class="close"></button>
		</aside>

		<div class="mask footnotes"></div>

		<aside class="modal details footnotes is-hidden">
			<div class="content scrollable"></div>
			<button class="open">FOOTNOTES</button>
			<button class="close"></button>
		</aside>

		<aside class="modal details footnotes table is-hidden">
			<div class="content scrollable"></div>
			<button class="open">TABLE FOOTNOTES</button>
			<button class="close"></button>
		</aside>

		<div class="mask references"></div>

		<aside class="modal details references is-hidden">
			<div class="content scrollable"></div>
			<button class="open">REFERENCES</button>
			<button class="close"></button>
		</aside>

		<div class="mask sitemap"></div>
		<nav class="sitemap"></nav>

		<div class="mask objection"></div>
		<nav class="objection"></nav>

		<nav class="global">
			<button class="global attach"></button>
			<button class="global email"></button>
			<button class="global objection"></button>
			<button class="global data"></button>
			<button class="global pi"></button>
			<button class="global qtern"></button>
			<button class="global onglyza"></button>
			<button class="global sitemap"></button>
		</nav>
	`;

	if(!document.documentElement.matches('.splash, .understanding, .summary, .qtern'))
	{
		markup = `
			<figure class="logo forxiga">
				<img width="148" src="assets/img/logos/forxiga.png" id="foo_logo"/>
			</figure>
		` + markup;
	}

	function create(htmlStr) {
		var frag = document.createDocumentFragment(),
			temp = document.createElement('div');
		temp.innerHTML = htmlStr;
		while (temp.firstChild) {
			frag.appendChild(temp.firstChild);
		}
		return frag;
	}

	document.body.appendChild(create(markup));
})();







(function navigation() {
	var $primaryNav = document.querySelector('nav.primary');
	if(!$primaryNav) return;
	var $sitemap = document.querySelector('nav.sitemap');


	/// Loop through pages, creating columns
	Object.keys(PrimaryPages).forEach(function(name, index) {
		var primary = PrimaryPages[name];
		primary.page = name;

		if(!primary.page || !primary.label) return;

		var isCurrentSection = (primary.page.replace(/-\[\d-\d\]/, '') === document.documentElement.dataset.section.replace(/-\[\d-\d\]/, ''));

		var $primary = h('div.column');
		$primaryNav.appendChild($primary);
		primary.$element  = $primary;

		$primary.classList.add(primary.page.replace(/([a-z])([A-Z])/g, '$1-$2').toLowerCase()); // kebab-case the name as a class

		if(primary.class)
		{
			var classes;
			if(Array.isArray(primary.class)) classes = primary.class;
			else if(typeof primary.class === 'string') classes = primary.class.split(' ');
			classes.forEach(function(d) { $primary.classList.add(d) });
		}

		if(primary.label)
		{
			if(typeof primary.label === 'string')
			{
				$primary.appendChild(
					h('span.primary', { innerHTML: primary.label })
				);
			}
			else
			{
				$primary.appendChild(
					h('span.primary', primary.label)
				);
			}
			if(isCurrentSection) $primary.classList.add('is-active');
		}

		if(primary.children)
		{
			if(Array.isArray(primary.children)) primary.children.forEach(function(child) { $primary.appendChild(child) });
			else if(primary.children instanceof HTMLElement) $primary.appendChild(primary.children);
		}

		if(primary.dropdown)
		{
			$primary.classList.add('dropdown');
			var $dropdown = h('nav.dropdown');
			$primary.appendChild($dropdown);

			Object.keys(primary.dropdown).map(function(name) {
				var secondary = primary.dropdown[name];
				secondary.name = name;
				var $secondary = h('div.row');
				$dropdown.appendChild($secondary);

				var isCurrentPage = (secondary.name.replace(/-\[\d-\d\]/, '') === document.documentElement.dataset.page.replace(/-\[\d-\d\]/, ''))
				if(isCurrentPage) $secondary.classList.add('is-active');

				$secondary.dataset.page = secondary.name;

				if(secondary.label)
				{
					$secondary.appendChild(
						h('span.label', { innerHTML: secondary.label })
					);

					if(isCurrentPage) $secondary.classList.add('is-active');
					$secondary.dataset.page = secondary.name;
				}

				$secondary.addEventListener(TAP_EVENT, function() {
					var $active = $dropdown.querySelector('.is-active');
					if($active) $active.classList.remove('is-active');
					this.classList.add('is-active');

					var page = this.dataset.page;
					if(/\[\d-\d\]/.test(page))
					{
						var matches = page.match(/^(.*)?\[(\d)-(\d)\](.*)?$/);
						var prefix = matches[1] || ''
						var suffix = matches[4] || '';
						var from = matches[2];
						var to = matches[3];
						page = prefix + from + suffix; // Go to first page for a paginated keymessage
					}

					go(page);
				});
			});

			document.addEventListener(TAP_EVENT, function(event) {
				if(!($primary.classList.contains('is-open') || event.target === $primary || event.target.parentNode === $primary)) return;

				var $active = $primaryNav.querySelector('.column.is-active');
				var $open = $primaryNav.querySelector('.column.is-open');
				// if($active && $active !== $primary) $active.classList.remove('is-active');
				if($open && $open !== $primary) $open.classList.remove('is-open');

				// $primary.classList.add('is-active');
				$primary.classList.toggle('is-open');
			});
		}

		else
		{
			if(typeof primary.onTap !== 'undefined')
			{
				if(primary.onTap === null); // No Op
				else if(typeof primary.onTap === 'string') $primary.dataset.page = primary.onTap;
			}

			else if(primary.secondary)
			{
				$primary.dataset.page = Object.keys(primary.secondary)[0];
				$primary.classList.add('has-secondary');
			}

			else
			{
				$primary.dataset.page = primary.page;
			}

			var isCurrentPage = (primary.page.replace(/-\[\d-\d\]/, '') === document.documentElement.dataset.page.replace(/-\[\d-\d\]/, ''));
			if(isCurrentPage) $primary.classList.add('is-active');

			$primary.addEventListener(TAP_EVENT, function(event) {
// 				if(!event.target.matches('.column, span.primary')) return;
				var $active = $primaryNav.querySelector('.column.is-active');
				var $open = $primaryNav.querySelector('.column.is-open');
				if($active && $active !== this) $active.classList.remove('is-active');
				if($open && $open !== this) $open.classList.remove('is-open');

				this.classList.add('is-active');

				var page = this.dataset.page;
				if(/\[\d-\d\]/.test(page))
				{
					var matches = page.match(/^(.*)?\[(\d)-(\d)\](.*)?$/);
					var prefix = matches[1] || ''
					var suffix = matches[4] || '';
					var from = matches[2];
					var to = matches[3];
					page = prefix + from + suffix; // Go to first page for a paginated keymessage
				}
//				if(page == 'ChangeEvidence'){
//					page = 'MicroMacroVascularRisk';
//				}
				go(page);
			});
		}


		if(isCurrentSection && primary.secondary)
		{
			var $secondaryNav = document.querySelector('nav.secondary');
			// if(!$secondaryNav) return;

			Object.keys(primary.secondary)
			.forEach(function(name, index) {
				var secondary = primary.secondary[name];
				var isCurrentPage;

				if(/\[\d-\d\]/.test(name))
				{
					isCurrentPage = (function() {
						var matches = name.match(/^(.*)?\[(\d)-(\d)\](.*)?$/);
						var prefix = matches[1] || '';
						var suffix = matches[4] || '';
						var from = matches[2];
						var to = matches[3];
						for(var iter = from; iter <= to; ++iter)
							if(document.documentElement.dataset.page ===  prefix + iter + suffix) return true;
						return false;
					})();
				}

				else isCurrentPage = (name === document.documentElement.dataset.page.replace(/-[\d]/, ''));


				var $secondary = h('div.column');
				secondary.$element = $secondary;

				if(isCurrentPage) $secondary.classList.add('is-active');


				if(typeof secondary.label === 'string')
				{
					$secondary.appendChild(h('span.secondary', { innerHTML: secondary.label }));
				}

				else if(secondary.label instanceof HTMLElement)
				{
					$secondary.appendChild(h('span.secondary', secondary.label));
				}


				$secondary.dataset.page = name;

				$secondary.addEventListener(TAP_EVENT, function(event) {
					if(this.parentNode.querySelector('.is-active')) this.parentNode.querySelector('.is-active').classList.remove('is-active');
					this.classList.add('is-active');

					var page = this.dataset.page;
					if(/\[\d-\d\]/.test(page))
					{
						var matches = page.match(/^(.*)?\[(\d)-(\d)\](.*)?$/);
						var prefix = matches[1] || ''
						var suffix = matches[4] || '';
						var from = matches[2];
						var to = matches[3];
						page = prefix + from + suffix; // Go to first page for a paginated keymessage
					}

					go(page);
				});

				$secondaryNav.appendChild($secondary);
			});
		}
	});



	window.deferredSitemapRender = function deferredSitemapRender() {
		window.deferredSitemapRender = null;
		var pages;

		var currentPrimary = PrimaryPages[document.documentElement.dataset.section];
		if(currentPrimary && currentPrimary.overrideSitemap)
		{
			var name = document.documentElement.dataset.section
			var primary = PrimaryPages[name];
			primary.page = name;

			if(!primary.page || !primary.label) return;

			var $primary = primary.$element;

			if(primary.sitemap)
			{
				primary.sitemap.forEach(function(node, i) {
					var secondary = primary.secondary[node.page];
					var $secondary = secondary.$element;
					var bbox;
					if(window.innerWidth == 1024) bbox = $secondary.getBoundingClientRect();
					else bbox = {
						left: $secondary.offsetLeft,
						width: $secondary.offsetWidth
					};


					var $row = h('div.row');
					$sitemap.appendChild($row);
					$row.style.left = bbox.left + 'px';
					$row.style.width = bbox.width + 'px';
					$row.style.top = (10 + (i * 60)) + 'px';
					$row.style.height = '55px';

					if(typeof node.label === 'string')
					{
						$row.appendChild(h('span.label', { innerHTML: node.label }));
					}

					else if(node.label instanceof HTMLElement)
					{
						$row.appendChild(h('span.label', node.label));
					}

					if(node.page) $row.dataset.page = node.page;
					if(node.pagination) $row.dataset.pagination = node.pagination;
					if(node.popup) $row.dataset.popup = node.popup;
					if(node.popup && !node.page) $row.dataset.page = primary.page;

					$row.addEventListener(TAP_EVENT, function(event) {
						this.classList.add('is-active');

						if(this.dataset.popup)
						{
							sessionStorage.setItem('POPUP', this.dataset.popup);
						}

						if(this.dataset.pagination)
						{
							sessionStorage.setItem('PAGINATION', this.dataset.pagination);
						}

						if(this.dataset.page)
						{
							var page = this.dataset.page;
							if(/\[\d-\d\]/.test(page))
							{
								var matches = page.match(/^(.*)?\[(\d)-(\d)\](.*)?$/);
								var prefix = matches[1] || ''
								var suffix = matches[4] || '';
								var from = matches[2];
								var to = matches[3];
								page = prefix + from + suffix; // Go to first page for a paginated keymessage
							}

							go(page);
						}
					});
				});
			}
		}

		else
		{
			pages = Object.keys(PrimaryPages).filter(function(name) { return !PrimaryPages[name].overrideSitemap });

			pages.forEach(function(name, index) {
				var primary = PrimaryPages[name];
				primary.page = name;

				if(!primary.page || !primary.label) return;

				var $primary = primary.$element;

				if(primary.sitemap)
				{
					var bbox;
					if(window.innerWidth == 1024) bbox = $primary.getBoundingClientRect();
					else bbox = {
						left: $primary.offsetLeft,
						width: $primary.offsetWidth
					};

					primary.sitemap.forEach(function(node, i) {
						var $row = h(index%2? 'div.row.odd' : 'div.row.even');
						$sitemap.appendChild($row);
						$row.style.left = bbox.left + 'px';
						$row.style.width = bbox.width + 'px';
						$row.style.top = (10 + (i * 60)) + 'px';
						$row.style.height = '55px';

						if(typeof node.label === 'string')
						{
							$row.appendChild(h('span.label', { innerHTML: node.label }));
						}

						else if(node.label instanceof HTMLElement)
						{
							$row.appendChild(h('span.label', node.label));
						}

						if(node.page) $row.dataset.page = node.page;
						if(node.pagination) $row.dataset.pagination = node.pagination;
						if(node.popup) $row.dataset.popup = node.popup;
						if(node.popup && !node.page) $row.dataset.page = primary.page;

						$row.addEventListener(TAP_EVENT, function(event) {
							this.classList.add('is-active');

							if(this.dataset.popup)
							{
								sessionStorage.setItem('POPUP', this.dataset.popup);
							}

							if(this.dataset.page)
							{
								var page = this.dataset.page;
								if(/\[\d-\d\]/.test(page))
								{
									var matches = page.match(/^(.*)?\[(\d)-(\d)\](.*)?$/);
									var prefix = matches[1] || ''
									var suffix = matches[4] || '';
									var from = matches[2];
									var to = matches[3];
									page = prefix + from + suffix; // Go to first page for a paginated keymessage
								}

								go(page);
							}
						});
					});
				}
			});
		}
	}
})();



(function globalNavigation() {
	/// Global navigation elements
	var $globalNav = document.querySelector('nav.global');
	if(!$globalNav) return;

	function onAttach(event) {
		event.preventDefault();

	}

	function onEmail(event) {
		event.preventDefault();

	}

	function onData(event) {
		event.preventDefault();

		closeDetails();
		if(document.querySelector('aside.popup.objection.is-open')) closePopup();
		while(document.querySelector('aside.data.is-open')) closePopup();
		closeSitemap();
		closeObjection();
		if(document.querySelector('aside.data-library.is-open')) closePopup();
		else
		{
			if(window.deferredLibraryRender) deferredLibraryRender();
			openPopup('data-library');
		}
	}

	document.addEventListener('open', function(event) {
		if(!event.target.matches('aside.popup.data-library')) return;
		document.documentElement.classList.add('has-data-library');
	});

	document.addEventListener('close', function(event) {
		if(!event.target.matches('aside.popup.data-library')) return;
		document.documentElement.classList.remove('has-data-library');
	});


	function onObjection(event) {
		event.preventDefault();

		if(window.deferredObjectionRender) deferredObjectionRender();

		closeDetails();
		while(document.querySelector('aside.data-library.is-open')) closePopup();
		closeSitemap();
		document.querySelector('button.global.objection').classList.toggle('is-active');
		document.querySelector('div.mask.objection').classList.toggle('is-visible');
		document.querySelector('nav.primary').classList.toggle('has-objection');
		document.querySelector('nav.objection').classList.toggle('is-open');
	}

	function closeObjection() {
		if(document.querySelector('aside.popup.objection')) closePopup();

		if(!document.querySelector('nav.objection').classList.contains('is-open')) return;
		document.querySelector('button.global.objection').classList.remove('is-active');
		document.querySelector('div.mask.objection').classList.remove('is-visible');
		document.querySelector('nav.primary').classList.remove('has-objection');
		document.querySelector('nav.objection').classList.remove('is-open');
	}

	document.addEventListener('open', function(event) {
		if(!event.target.matches('aside.popup.objection')) return;
		document.documentElement.classList.add('has-an-objection');
	});

	document.addEventListener('close', function(event) {
		if(!event.target.matches('aside.popup.objection')) return;
		document.documentElement.classList.remove('has-an-objection');
	});

	function closeDetails() {
		Array.from(document.querySelectorAll('aside.details.is-open')).forEach(function(aside) {
			var mask;

			if(aside.classList.contains('studies')) mask = document.querySelector('div.mask.studies'); else
			if(aside.classList.contains('footnotes')) mask = document.querySelector('div.mask.footnotes'); else
			if(aside.classList.contains('references')) mask = document.querySelector('div.mask.references');

			aside.classList.remove('is-open');
			aside.style.transform = '';
			aside.style.transition = '';
			aside.classList.remove('has-overlap');
			if(mask) mask.classList.remove('is-visible');
		});
	}

	function onPI(event) {
		event.preventDefault();

		var $pi = this;
		$pi.classList.add('is-active');
		setTimeout(function() {
			$pi.classList.remove('is-active');
		}, 200)

		// document.querySelector('aside.modal.pi').parentNode.classList.add('is-visible');
		go('PI.pdf');
	}

	function onQtern(event) {
		event.preventDefault();

		if(document.documentElement.dataset.section !== 'Qtern')
		{
			sessionStorage.setItem('backFromQtern', document.documentElement.dataset.page);
			go('QternPreSummary.html');
		}

		else
		{
			var backFromQtern = sessionStorage.getItem('backFromQtern');
			sessionStorage.removeItem('backFromQtern');
			go(backFromQtern);
		}
	}

	function onOnglyza(event) {
		event.preventDefault();

		go('Onglyza.pdf');
	}

	function onSitemap(event) {
		event.preventDefault();

		if(window.deferredSitemapRender) deferredSitemapRender();

		closeObjection();
		document.querySelector('button.global.sitemap').classList.toggle('is-active');
		document.querySelector('div.mask.sitemap').classList.toggle('is-visible');
		document.querySelector('nav.primary').classList.toggle('has-sitemap');
		document.querySelector('nav.sitemap').classList.toggle('is-open');
	}

	function closeSitemap() {
		if(!document.querySelector('nav.sitemap').classList.contains('is-open')) return;
		document.querySelector('button.global.sitemap').classList.remove('is-active');
		document.querySelector('div.mask.sitemap').classList.remove('is-visible');
		document.querySelector('nav.primary').classList.remove('has-sitemap');
		document.querySelector('nav.sitemap').classList.remove('is-open');
	}



	(function initEmailFunctionality(){
		var isVeeva = "BUILD_FOR_IREP" in window;

		var vaultUrl = "https://astrazeneca-promomats.veevavault.com"; // "https://vv-agency-hive.veevavault.com"
		var frgmentArray = [];
		var templateDocNumber = 193430; // 4
		var templateDocId;
		var loop = 0;
		var fragvalues = [];
		var DocIDArr = [];

		var $page = document.querySelector("html").getAttribute("data-page");
		var $attach = $globalNav.querySelector('button.global.attach');
		var $email = $globalNav.querySelector('button.global.email');

		var pagesWithEmailFunctionality = [
			{ page: 'TolerabilityPatient', fragment: ['193532','193539'] }, // ['5']
			{ page: 'Summary', fragment: '193545' } // '6'
		]

		function GetFragmentID(result){
			templateDocId = result.Approved_Document_vod__c.ID;
			fragDetail(loop);
		}

		function fragDetail(m){
			if( m < fragvalues.length){
				com.veeva.clm.getApprovedDocument(vaultUrl, fragvalues[m], GetFragmentID1);
			}

			else
			{
				com.veeva.clm.launchApprovedEmail(templateDocId, frgmentArray, finalCall); // launchs the email with attached fragments
				frgmentArray = [];
				loop = 0;
				setTimeout(function() {
					$email.classList.remove("disabled");
				}, 2000);
			}
		}

		function GetFragmentID1(result){
			frgmentArray.push(result.Approved_Document_vod__c.ID);
			loop++;
			fragDetail(loop);
		}

		function finalCall(result) {
			alert("Attempted to launch Approved Email: " + JSON.stringify(result));
		}

		function onAttachEmailFragment(e)
		{
			// if(!isVeeva) return console.log("attach email fragment");

			var $this = e.target;

			var prevDocID = sessionStorage.getItem("fragments") || null;

			if(prevDocID){
				DocIDArr= JSON.parse(prevDocID);
			}

			var docID = pagesWithEmailFunctionality[$this.getAttribute("data-docid")].fragment;

			if(!( $this.classList.contains("activeButton") )){ // checks whether the fragment is already added or not.
				if(docID.constructor === Array){
					for(var i=0,ilen=docID.length;i<ilen;i++){
						if(!(DocIDArr.length == 4)){ //for adding max 4 fragment
							DocIDArr.push( docID[i] );
						}else{
							alert("Addition more than 4 fragments are not allowed");
						}
					}
				}else{
					if(!(DocIDArr.length == 4)){ //for adding max 4 fragment
						DocIDArr.push( docID );
					}else{
						alert("Addition more than 4 fragments are not allowed");
					}
				}

				sessionStorage.setItem("fragments", JSON.stringify(DocIDArr));
				$this.classList.add('activeButton');
			}else{
				if(docID.constructor === Array){
					for(var i=0,ilen=docID.length;i<ilen;i++){
						var index = DocIDArr.indexOf( docID[i] );
						if (index > -1) {
							DocIDArr.splice(index, 1);
						}
					}
				}else{
					var index = DocIDArr.indexOf( docID );
					if (index > -1) {
						DocIDArr.splice(index, 1);
					}
				}

				//DocIDArr.pop($(this).attr('docId'));
				sessionStorage.setItem("fragments", JSON.stringify(DocIDArr));
				$this.classList.remove('activeButton');
			}

			resetLaunchButton();
		}

		function onLaunchEmail()
		{
			if($email.classList.contains("disabled")) return console.log("there are no fragments attached");

			$email.classList.add('is-active');
			setTimeout(function() {
				$email.classList.remove('is-active');
			}, 300);

			setTimeout(function() {
				$email.classList.add("disabled");

				if(!isVeeva) return console.log("launch email");
				try{
					var fragvalue = sessionStorage.getItem("fragments") || null;
					fragvalues = JSON.parse(fragvalue);
					com.veeva.clm.getApprovedDocument(vaultUrl, templateDocNumber, GetFragmentID); // email Template Doc iD
				}catch(err) {
					alert(err);
				}
			}, 150);
		}

		function addListeners(pageIndexInArray)
		{
			$attach.setAttribute("data-docid", pageIndexInArray);


			$attach.addEventListener(TAP_EVENT, onAttachEmailFragment);
			$email.addEventListener(TAP_EVENT, onLaunchEmail);
		}

		function checkStorageForDocId(pageIndex)
		{
			var docID =  JSON.parse(sessionStorage.getItem("fragments") || null);
			var currID =  pagesWithEmailFunctionality[pageIndex].fragment;
			// var currID = $attach.getAttribute("data-docid");
			//
			if(!(docID == null || docID == undefined)){
				if(currID.constructor === Array){
					var allAreAdded = currID.reduce(function(acc, cv){
						return acc ? docID.indexOf(cv) > -1 : acc;
					}, true)
					if(allAreAdded) $attach.classList.add('activeButton');
				}else{
					if(docID.indexOf(currID)> -1){
						$attach.classList.add('activeButton');
					}
				}
			}

		}

		function pageInPagesArray(currentPage)
		{
			for(var i = 0, ilen = pagesWithEmailFunctionality.length; i<ilen; i++){
				if(pagesWithEmailFunctionality[i].page === currentPage) return i;
			}
			return -1;
		}
		function remvoveTheButtons()
		{
			$attach.remove();
			$email.remove();
		}

		function resetLaunchButton()
		{
			var fragments = sessionStorage.getItem("fragments") || null;
			if(!fragments || JSON.parse(fragments).length === 0){
				$email.classList.add("disabled")
			}else{
				if($email.classList.contains("disabled"))
					$email.classList.remove("disabled")
			}
		}

		var pageIndexInArray = pageInPagesArray($page);
		if(pageIndexInArray > -1){
			checkStorageForDocId(pageIndexInArray);
			addListeners(pageIndexInArray);
			resetLaunchButton();
		}else{
			remvoveTheButtons();
		}


	})()

	var $objection = $globalNav.querySelector('button.global.objection');
	var $data = $globalNav.querySelector('button.global.data');
	var $pi = $globalNav.querySelector('button.global.pi');
	var $qtern = $globalNav.querySelector('button.global.qtern');
	var $onglyza = $globalNav.querySelector('button.global.onglyza');
	var $sitemap = $globalNav.querySelector('button.global.sitemap');


	$data.addEventListener('touchend', onData);
	$data.addEventListener('mousedown', onData);
	$objection.addEventListener('touchend', onObjection);
	$objection.addEventListener('mousedown', onObjection);
	$pi.addEventListener('touchend', onPI);
	$pi.addEventListener('mousedown', onPI);
	$qtern.addEventListener('touchend', onQtern);
	$qtern.addEventListener('mousedown', onQtern);
	$onglyza.addEventListener('touchend', onOnglyza);
	$onglyza.addEventListener('mousedown', onOnglyza);
	$sitemap.addEventListener('touchend', onSitemap);
	$sitemap.addEventListener('mousedown', onSitemap);

// 	if(document.documentElement.classList.contains('default')) …


	document.addEventListener(TAP_EVENT, function(event) {
		if(event.target.matches('div.mask.sitemap'))
		{
			closeSitemap();
		}
		else if(event.target.matches('div.mask.objection'))
		{
			closeObjection();
		}
	});
})();






(function closeModals() {
	document.addEventListener(TAP_EVENT, function(event) {
		var button = event.target.closest('div.mask button.close');
		if(!button) return;

		var modal = event.target.closest('aside.modal');
		var mask = event.target.closest('div.mask');

		mask.classList.remove('is-visible');

		if(modal.matches('.pi')) document.querySelector('button.global.pi').classList.remove('is-active');
		else if(modal.matches('.references')) document.querySelector('button.global.ref').classList.remove('is-active');
	})
})();





(function sideOverlays() {
	/// Side Overlays  (References, Footnotes, Study Details)
	var mask;
	var aside = null, isOpen = false;
	var _swipeStart = null;
	var _swipeTime = null;
	document.addEventListener(iOS? 'touchstart' : 'mousedown', function(e) {
		if(!e.target.closest('aside.details button.open')) { _swipeStart = null; return; }
		if (_swipeStart) return;
		_swipeTime = Date.now();
		_swipeStart = {
			x: (e.touches ? e.touches[0] : e).pageX,
			y: (e.touches ? e.touches[0] : e).pageY,
		};


		aside = event.target.closest('aside.details');
		isOpen = aside.classList.contains('is-open');
		aside.classList.add('is-open');
		aside.classList.add('has-overlap');
		aside.style.transition = 'none';
		aside.style.transform = `translateZ(10px) translateX(${isOpen? 0 : 100}%) translate(0px)`;

		if(aside.classList.contains('studies'))
		{
			if(window.deferredStudiesRender) deferredStudiesRender();
			mask = document.querySelector('div.mask.studies');
		}
		else if(aside.classList.contains('footnotes'))
		{
			if(aside.classList.contains('table'))
			{
				if(window.deferredTableFootnotesRender) deferredTableFootnotesRender();
			}

			else if(window.deferredFootnotesRender) deferredFootnotesRender();

			mask = document.querySelector('div.mask.footnotes');
		}
		else if(aside.classList.contains('references'))
		{
			if(window.deferredReferencesRender) deferredReferencesRender();
			mask = document.querySelector('div.mask.references');
		}

		mask.classList.add('is-visible');
	}, true);

	document.addEventListener(iOS? 'touchmove' : 'mousemove', function(e) {
		if(!_swipeStart && !e.target.closest('aside.details button.open')) { _swipeStart = null; return; }
		if (!_swipeStart) return;
		var move = {
			x: (e.touches ? e.changedTouches[0] : e).pageX,
			y: (e.touches ? e.changedTouches[0] : e).pageY,
		};
		var moveTime = Date.now();

		var diffX = Math.max(Math.min(move.x - _swipeStart.x, 945), -945);
		var diffT = moveTime - _swipeTime;
		var absX = Math.abs(diffX);

		if(!isOpen && diffX > 0) diffX = 0;
		else if(isOpen && diffX < 0) diffX = 0;
		aside.style.transform = `translateZ(10px) translateX(${isOpen? 0 : 100}%) translate(${diffX}px)`;
	});

	document.addEventListener(iOS? 'touchend' : 'mouseup', function(e) {
		if(!_swipeStart && !e.target.closest('aside.details button.open')) { _swipeStart = null; return; }
		if(!_swipeStart) return;
		var end = {
			x: (e.touches ? e.changedTouches[0] : e).pageX,
			y: (e.touches ? e.changedTouches[0] : e).pageY,
		};
		var endTime = Date.now();

		var diffX = end.x - _swipeStart.x;
		var diffT = endTime - _swipeTime;
		var absX = Math.abs(diffX);

		_swipeStart = null;

		if(diffT <= 150 || absX > 200)
		{
			aside.style.transform = '';
			aside.style.transition = '';

			if(isOpen)
			{
				aside.classList.remove('is-open');
				mask.classList.remove('is-visible');
				loadDetails();
			}

			else
			{
				aside.classList.add('is-open');
				mask.classList.add('is-visible');
				loadDetails();
			}

			if(diffT <= 150) absX = 945;

			aside.style.transition = `transform ${absX * .4}ms ease-out`;

			setTimeout(function() {
				aside.style.transform = '';
			}, 30);
			setTimeout(function() {
				aside.style.transition = '';
				if(isOpen) aside.classList.remove('has-overlap');
			}, absX*.4 + 60);
		}

		else
		{
			if(!isOpen)
			{
				aside.classList.remove('is-open');
				mask.classList.remove('is-visible');
				loadDetails();
			}

			aside.style.transition = `transform ${absX * .4}ms ease-out`;
			setTimeout(function() {
				aside.style.transform = '';
			}, 30);

			setTimeout(function() {
				aside.style.transition = '';
				if(!isOpen) aside.classList.remove('has-overlap');
			}, absX*.4 + 60);
		}
	});

	document.addEventListener(TAP_EVENT, function(event) {
		var button = event.target.closest('aside.details button.close');
		if(!(button || event.target.matches('div.mask'))) return;
		if(button)
		{
			aside = button.closest('aside.details');

			if(aside)
			{
				if(aside.classList.contains('studies')) mask = document.querySelector('div.mask.studies'); else
				if(aside.classList.contains('footnotes')) mask = document.querySelector('div.mask.footnotes'); else
				if(aside.classList.contains('references')) mask = document.querySelector('div.mask.references');
			}
		}

		else if(event.target.matches('div.mask'))
		{
			mask = event.target;
			if(mask.classList.contains('studies')) aside = document.querySelector('aside.studies'); else
			if(mask.classList.contains('footnotes')) aside = document.querySelector('aside.footnotes'); else
			if(mask.classList.contains('references')) aside = document.querySelector('aside.references');
		}


		if(aside && aside.classList.contains('is-open'))
		{
			aside.classList.remove('is-open');
			loadDetails();

			var absX = 945;
			aside.style.transition = `transform ${absX * .4}ms ease-out`;
			setTimeout(function() {
				aside.style.transform = '';
			}, 30);

			setTimeout(function() {
				aside.style.transition = '';
				aside.classList.remove('has-overlap');
			}, absX*.4 + 60);

			mask.classList.remove('is-visible');
		}
	});
}());






(function hotspotLocation() {
	document.addEventListener(TAP_EVENT, function(event) {
		var hotspot = event.target.closest('[data-location]');
		if(!hotspot) return;
		hotspot.classList.add('is-active');
		window.location = hotspot.dataset.location;
	});
})();



(function hotspotGo() {
	document.addEventListener(TAP_EVENT, function(event) {
		var hotspot = event.target.closest('[data-go]');
		if(!hotspot) return;

		if(hotspot.dataset.popup)
		{
			sessionStorage.setItem('POPUP', hotspot.dataset.popup);
		}

		if(hotspot.dataset.accordion)
		{
			sessionStorage.setItem('ACCORDION', hotspot.dataset.accordion);
		}

		if(hotspot.dataset.pagination)
		{
			sessionStorage.setItem('PAGINATION', hotspot.dataset.pagination);
		}


		hotspot.classList.add('is-active');
		go(hotspot.dataset.go);
	});
})();



(function hotspotTabs() {
	document.addEventListener(TAP_EVENT, function(event) {
		var hotspot = event.target.closest('[data-tab]');
		if(!hotspot || hotspot === document.documentElement) return;

		/// Query the dom
		var container = hotspot.closest('div.tabbed, div.page-content, aside.overlay');
		var menu = hotspot.closest('nav.tabs, div.tabbed, div.page-content, aside.overlay');
		var tabs = Array.from(menu.children).filter(function(d) { return d.matches('[data-tab]') });
		var panes = Array.from(container.children).filter(function(d) { return d.matches('[data-pane]') });

		/// Remove previous state
		tabs.forEach(function(d) { d.classList.remove('is-selected') });
		panes.forEach(function(d) { d.classList.remove('is-visible') });

		/// Get newer tab(s)/pane(s) and set new state
		var tab = tabs.filter(function(d) { return d.dataset.tab === hotspot.dataset.tab });
		var pane = panes.filter(function(d) { return d.dataset.pane === hotspot.dataset.tab });
		tab.forEach(function(d) { d.classList.add('is-selected') });
		pane.forEach(function(d) { d.classList.add('is-visible') });

		/*
		/// Update global state
		var node = pane.pop();
		var hierarchy = [node.dataset.pane];
		while((node = node.parentNode.closest('[data-pane]')))
		{
			hierarchy.unshift(node.dataset.pane);
		}

		document.documentElement.dataset.tab = hierarchy.join('.');

		/// Notify anyone else for the update
		if(!hotspot.closest('aside.overlay'))
		{
			load_footer();
		}*/
	});


	/// Build up initial hierarchy
	/*var hierarchy = [];
	var node = document.querySelector('div.page-content');
	while(node = Array.from(node.children).filter(function(d) { return d.matches('[data-pane].is-visible') }).pop())
	{
		hierarchy.push(node.dataset.pane);
	}

	document.documentElement.dataset.tab = hierarchy.join('.');*/
})();





(function Popups() {
	var $mask = document.querySelector('div.mask.popup');

	window.openPopup = function openPopup(name) {
		var $popup;
		if(typeof name === 'string') $popup = document.querySelector(`aside.popup[data-popup="${name}"]`);
		else if(name instanceof HTMLElement && name.matches('aside.popup'))
		{
			$popup = name;
			name = $popup.dataset.popup;
		}

		if(!$popup) return;

		$mask.parentNode.insertBefore($mask, $popup);
		$popup.classList.add('is-open');
		setTimeout(function() {
			$mask.classList.add('is-visible');
		}, 30);
		$popup.dispatchEvent(new CustomEvent('open', { bubbles: true }));



		loadDetails();
	};

	window.closePopup = function closePopup(name) {
		var $popup;
		if(!name) $popup = Array.from(document.querySelectorAll('aside.popup.is-open')).pop();
		else if(typeof name === 'string') $popup = document.querySelector(`aside.popup[data-popup="${name}"].is-open`);
		else if(name instanceof HTMLElement && name.matches('aside.popup'))
		{
			$popup = name;
			name = $popup.dataset.popup;
		}

		if(!$popup) return;

		$popup.classList.remove('is-open');
		if($popup.querySelector('video')) $popup.querySelector('video').pause();
		$popup.dispatchEvent(new CustomEvent('close', { bubbles: true }));

		// Re-open last popup
		var $openPopups = document.querySelectorAll('aside.popup.is-open');
		if($openPopups.length) openPopup($openPopups[$openPopups.length - 1]);

		else
		{
			setTimeout(function() {
				$mask.classList.remove('is-visible');
			}, 100);
			loadDetails();
		}
	};

	if(sessionStorage.getItem('POPUP'))
	{
		openPopup(sessionStorage.getItem('POPUP'));
		sessionStorage.removeItem('POPUP');
	}
})();



(function hotspotPopups() {
	document.addEventListener(TAP_EVENT, function(event) {
		var hotspot = event.target.closest('[data-popup]:not(aside)');
		if(!hotspot) return;

		hotspot.classList.add('is-active');
		setTimeout(function() { hotspot.classList.remove('is-active'); }, 250);
		setTimeout(function() { openPopup(hotspot.dataset.popup); }, 100);
	});
})();

(function popupClose() {
	document.addEventListener(TAP_EVENT, function(event) {
		var hotspot = event.target.closest('aside.popup.is-open button.close');
		if(!hotspot) return;
		closePopup(hotspot.closest('aside.popup'));
	});
})();






(function paginatedPageSwiping() {
	/// Offers swiping between HTML pages
	/// But also offers inner pagination
	/// When reaching end of pagination, swipes to neighbouring page

	// These query selectors will prevent swiping
	var interactables = [
		'.no-swipe',
		'nav',
		'aside',
		'div.mask',
		'.hotspot',
		'button',
		'.toggle',
		'.dropdown',
		'video',
		'.scrollable',
	].join(', ');



	var $page = document.querySelector('article.page');
	if(!$page) return; // No page to swipe?



	// I think these were for something safari specific
	window.ondragstart = function() { return false; };
	window.onmousedown = function() { return false; };



	/// Logic for loading next/previous pages
	var currentPage = document.documentElement.dataset.page;
	var currentPageIndex = -1;
	var queue;
	var iter = SwipingQueues.length;
	while(iter-->0 && currentPageIndex === -1)
	{
		queue = SwipingQueues[iter];
		currentPageIndex = queue.findIndex(function(page) {
			if(Array.isArray(page)) return page.some(function(page) { return page === currentPage });
			return page === currentPage;
		});
	}

	function openNextPage() {
		var next = queue[currentPageIndex + 1];
		if(Array.isArray(next)) next = next[0];
		if(next)
		{
			sessionStorage.setItem('previousPageIndex', currentPageIndex);
			sessionStorage.setItem('previousPageDirection', 1);
			go(next);
		}
	}

	function openPreviousPage() {
		var prev = queue[currentPageIndex - 1];
		if(Array.isArray(prev)) prev = prev[0];
		if(prev)
		{
			sessionStorage.setItem('previousPageIndex', currentPageIndex);
			sessionStorage.setItem('previousPageDirection', -1);
			go(prev);
		}
	}

	function hasNextPage() { return currentPageIndex + 1 < queue.length }
	function hasPreviousPage() { return currentPageIndex - 1 >= 0 }

	function hitAnyInteractable(event) {
		var hasHit = !!event.target.closest(interactables);
		return hasHit;
	}

	function getPointer(event) {
		var node = (event.changedTouches && event.changedTouches[0]) || (event.touches && event.touches[0]) || event;
		return {
			identifier: node.identifier || 'mouse',
			at: +new Date,
			x: node.pageX,
			y: node.pageY
		}
	}



	/// Page & Paginated Swiping
	function hasNextPaginated() { return Swiper.paginated.length > 1 && Swiper.currentPaginatedIndex + 1 < Swiper.paginated.length }
	function hasPreviousPaginated() { return Swiper.paginated.length > 1 && Swiper.currentPaginatedIndex - 1 >= 0 }

	var Swiper = {
		pageWidth: null,
		paginated: null,
		currentPaginatedIndex: 0,

		meta() {
			this.pageWidth = $page.clientWidth;
			this.paginated = $page.querySelectorAll('div.page-content');
			$page.style.setProperty(`--swiper-paginated-length`, this.paginated.length);
		},

		handleEvent(event) {
			if(event.type === 'touchstart' || event.type === 'mousedown') this.handleStart(event);
			else if(event.type === 'touchmove' || event.type === 'mousemove') this.handleMove(event);
			else if(event.type === 'touchend' || event.type === 'mouseup') this.handleEnd(event);
		},

		handleStart(event) {
			if(hitAnyInteractable(event)) return;
			var pointerStart = getPointer(event);
			if(this.pointer && this.pointer.identifier !== pointerStart.identifier) return; // Already had a pointer & isn't the same? Might be another finger, ignore
			this.pointer = pointerStart; /// Remember first pointer always

			/// Bind events
			document.addEventListener(event.type === 'touchstart'? 'touchmove' : 'mousemove', this);
			document.addEventListener(event.type === 'touchstart'? 'touchend' : 'mouseup', this);

			/// Page metadata
			this.meta();

			if(this.animator)
			{
				this.animator.stop();
				this.animator = null;
			}

			/// Kick render into gear
// 			if(!frame) frame = requestAnimationFrame(render);
		},

		handleMove(event) {
			var pointerMove = getPointer(event);
			if(!this.pointer || this.pointer.identifier !== pointerMove.identifier) return; // Make we have pointers and this is the same we started with

			var offset = pointerMove.x - this.pointer.x;
			if(!this.pointer.velocity) this.pointer.velocity = offset;
			else this.pointer.velocity = this.pointer.velocity * 0.3 + offset * 0.7;


			/// Check for pagination neighbour
			if(offset < 0? hasNextPaginated() : hasPreviousPaginated()); // …


			/// Check for page neighbour
			else if(offset < 0? hasNextPage() : hasPreviousPage()); // …


			// Reached boundary
			else offset = offset / (10 + Math.abs(offset) / 40);

			var t = -offset / this.pageWidth;
			this.index = this.currentPaginatedIndex + t;
			this.absolute = this.index * this.pageWidth;
			this.render();
		},

		handleEnd(event) {
			var pointerEnd = getPointer(event);
			if(!this.pointer || this.pointer.identifier !== pointerEnd.identifier) return; // Make we have pointers and this is the same we started with
			this.pointer.since = pointerEnd.at - this.pointer.at;

			var offset = pointerEnd.x - this.pointer.x;
			var direction = offset < 0? 1 : -1;
			var targetPaginatedIndex = Math.min(Math.max(Math.round(this.currentPaginatedIndex), 0), this.paginated.length - 1);
			this.currentPaginatedIndex = targetPaginatedIndex; // for has*Paginated checks


			/// Check for pagination neighbour
			if(offset < 0? hasNextPaginated() : hasPreviousPaginated())
			{
				if(Math.abs(offset) > 250 || Math.abs(this.pointer.velocity) > 150)
				{
					targetPaginatedIndex += direction;
				}
			}


			/// Check for page neighbour
			else if(offset < 0? hasNextPage() : hasPreviousPage())
			{
				if(Math.abs(offset) > 250 || Math.abs(this.pointer.velocity) > 150)
				{
					targetPaginatedIndex += direction; // Simulates going outside the paginated visually

					/// Open page on a delay, to work in concert with any animation
					setTimeout(function() {
						if(direction > 0) openNextPage(); else openPreviousPage();
					}, 300);
				}
			}


			// Reached boundary
			else offset = offset / (10 + Math.abs(offset) / 40);



			var t = -offset / this.pageWidth;
			this.index = this.currentPaginatedIndex + t;
			this.absolute = this.index * this.pageWidth;
			this.render();


			this.animator = popmotion.spring({
				mass: 4,
				stiffness: 1200,
				damping: 280,
				velocity: this.pointer.velocity * direction * 2,
				from: this.index,
				to: targetPaginatedIndex,
				onUpdate: function(v) {
					Swiper.index = v;
					Swiper.absolute = v * Swiper.pageWidth;
					Swiper.render();
					Swiper.currentPaginatedIndex = v;
				},
				onComplete: function() {
					Swiper.currentPaginatedIndex = targetPaginatedIndex;

					$page.dataset.index = Swiper.currentPaginatedIndex;
					$page.dispatchEvent(new Event('change'));
					loadDetails();
				}
			}).start();


			/// Cleanup
			this.pointer = null;
			document.removeEventListener(event.type === 'touchstart'? 'touchmove' : 'mousemove', this);
			document.removeEventListener(event.type === 'touchstart'? 'touchend' : 'mouseup', this);
		},

		render() {
			var absolute = this.absolute;
			var index = this.index;
			var paginatedIndex;
			var pageIndex;
			if(this.index < 0) { paginatedIndex = 0; pageIndex = index }
			else if(index > this.paginated.length - 1) { paginatedIndex = this.paginated.length - 1; pageIndex = index - (this.paginated.length - 1) }
			else { paginatedIndex = index; pageIndex = 0 }

			$page.style.setProperty(`--swiper-absolute`, absolute);
			$page.style.setProperty(`--swiper-index`, index);
			$page.style.setProperty(`--swiper-paginated-index`, paginatedIndex);
			$page.style.setProperty(`--swiper-page-index`, pageIndex);
			if(iOS && cmpVersions(iOS, '10') < 0) Array.from($page.querySelectorAll('div.page-content, .swiper-vars')).forEach(function($content) {
				$content.style.setProperty(`--swiper-absolute`, this.absolute);
				$content.style.setProperty(`--swiper-index`, index);
				$content.style.setProperty(`--swiper-paginated-index`, paginatedIndex);
				$content.style.setProperty(`--swiper-page-index`, pageIndex);
			});
			$page.dispatchEvent(new Event('input'));
		}
	};

	document.addEventListener('touchstart', Swiper);
	document.addEventListener('mousedown', Swiper);

	window.Swiper = Swiper;


	Swiper.meta();

	$page.dataset.index = Swiper.currentPaginatedIndex;

	document.documentElement.classList.remove('prepare-paginated-swipe');

	if(hasDefaultPagination)
	{
		Swiper.currentPaginatedIndex = defaultPagination;
		Swiper.index = defaultPagination;
		Swiper.absolute = defaultPagination * Swiper.pageWidth;
		Swiper.render();
		$page.dispatchEvent(new Event('change'));
	}

	else if(animateSwiperEntry)
	{
		var direction = currentPageIndex - previousPageIndex;
		var targetPaginatedIndex = direction > 0? 0 : Swiper.paginated.length - 1;
		Swiper.currentPaginatedIndex = direction > 0? -1 : Swiper.paginated.length;

		Swiper.animator = popmotion.spring({
			mass: 4,
			stiffness: 600,
			damping: 280,
			from: Swiper.currentPaginatedIndex,
			to: targetPaginatedIndex,
			onUpdate: function(v) {
				Swiper.index = v;
				Swiper.absolute = v * Swiper.pageWidth;
				Swiper.render();
				Swiper.currentPaginatedIndex = v;
			},
			onComplete: function() {
				Swiper.currentPaginatedIndex = targetPaginatedIndex;

				$page.dataset.index = Swiper.currentPaginatedIndex;
				$page.dispatchEvent(new Event('change'));
				loadDetails();
			}
		}).start();
	}

	else
	{
		Swiper.currentPaginatedIndex = 0;
		Swiper.index = 0;
		Swiper.absolute = 0;
		Swiper.render();
		$page.dispatchEvent(new Event('change'));
	}
})();





(function paginatedSwiping() {
	/// Offers paginated swiping as a reusable component
	/// Different from paginatedPageSwiping in many respects; It's stripped down to core

	// These query selectors will prevent swiping
	var interactables = [
		'.no-swipe',
		'nav',
		'div.mask',
		'.hotspot',
		'button',
		'.toggle',
		'.dropdown',
		'video',
		'.scrollable',
	].join(', ');



	function hitAnyInteractable(event) {
		var hasHit = !!event.target.closest(interactables);
		return hasHit;
	}

	function getPointer(event) {
		var node = (event.changedTouches && event.changedTouches[0]) || (event.touches && event.touches[0]) || event;
		return {
			identifier: node.identifier || 'mouse',
			at: +new Date,
			x: node.pageX,
			y: node.pageY
		}
	}



	/// Paginated Swiping

	var Swiper = {
		container: null,
		containerWidth: null,
		paginated: null,
		currentPaginatedIndex: 0,

		meta(component) {
			this.container = component;
			this.currentPaginatedIndex = +component.dataset.currentPaginatedIndex || 0;
			this.index = +component.dataset.index || 0;
			this.absolute = +component.dataset.absolute || 0;

			this.containerWidth = component.clientWidth;
			this.paginated = component.querySelectorAll('div.page');
			component.style.setProperty(`--paginated-length`, this.paginated.length);
		},

		hasNextPaginated() { return Swiper.paginated.length > 1 && Swiper.currentPaginatedIndex + 1 < Swiper.paginated.length },
		hasPreviousPaginated() { return Swiper.paginated.length > 1 && Swiper.currentPaginatedIndex - 1 >= 0 },

		handleEvent(event) {
			if(event.type === 'touchstart' || event.type === 'mousedown') this.handleStart(event);
			else if(event.type === 'touchmove' || event.type === 'mousemove') this.handleMove(event);
			else if(event.type === 'touchend' || event.type === 'mouseup') this.handleEnd(event);
		},

		handleStart(event) {
			if(hitAnyInteractable(event)) return;
			var paginated = event.target.closest('div.paginated');
			if(!paginated) return;

			var pointerStart = getPointer(event);
			if(this.pointer && this.pointer.identifier !== pointerStart.identifier) return; // Already had a pointer & isn't the same? Might be another finger, ignore
			this.pointer = pointerStart; /// Remember first pointer always

			/// Bind events
			document.addEventListener(event.type === 'touchstart'? 'touchmove' : 'mousemove', this);
			document.addEventListener(event.type === 'touchstart'? 'touchend' : 'mouseup', this);

			/// Page metadata
			this.meta(paginated);

			if(this.animator)
			{
				this.animator.stop();
				this.animator = null;
			}

			/// Kick render into gear
// 			if(!frame) frame = requestAnimationFrame(render);
		},

		handleMove(event) {
			var pointerMove = getPointer(event);
			if(!this.pointer || this.pointer.identifier !== pointerMove.identifier) return; // Make we have pointers and this is the same we started with

			var offset = pointerMove.x - this.pointer.x;
			if(!this.pointer.velocity) this.pointer.velocity = offset;
			else this.pointer.velocity = this.pointer.velocity * 0.3 + offset * 0.7;


			/// Check for pagination neighbour
			if(offset < 0? this.hasNextPaginated() : this.hasPreviousPaginated()); // …


			// Reached boundary
			else offset = offset / (10 + Math.abs(offset) / 40);

			var t = -offset / this.containerWidth;
			this.index = this.currentPaginatedIndex + t;
			this.absolute = this.index * this.containerWidth;
			this.render();
		},

		handleEnd(event) {
			var pointerEnd = getPointer(event);
			if(!this.pointer || this.pointer.identifier !== pointerEnd.identifier) return; // Make we have pointers and this is the same we started with
			this.pointer.since = pointerEnd.at - this.pointer.at;

			var offset = pointerEnd.x - this.pointer.x;
			var direction = offset < 0? 1 : -1;
			var targetPaginatedIndex = Math.min(Math.max(Math.round(this.currentPaginatedIndex), 0), this.paginated.length - 1);
			this.currentPaginatedIndex = targetPaginatedIndex; // for has*Paginated checks


			/// Check for pagination neighbour
			if(offset < 0? this.hasNextPaginated() : this.hasPreviousPaginated())
			{
				if(Math.abs(offset) > 250 || Math.abs(this.pointer.velocity) > 150)
				{
					targetPaginatedIndex += direction;
				}
			}


			// Reached boundary
			else offset = offset / (10 + Math.abs(offset) / 40);



			var t = -offset / this.containerWidth;
			this.index = this.currentPaginatedIndex + t;
			this.absolute = this.index * this.containerWidth;
			this.render();

			var self = this;
			this.animator = popmotion.spring({
				mass: 4,
				stiffness: 1200,
				damping: 280,
				velocity: this.pointer.velocity * direction * 2,
				from: this.index,
				to: targetPaginatedIndex,
				onUpdate: function(v) {
					self.index = v;
					self.absolute = v * self.containerWidth;
					self.render();
					self.currentPaginatedIndex = v;
				},
				onStop: function() {
					console.log('ON STOP', self.index);
					self.container.dataset.currentPaginatedIndex = self.index;
					self.container.dataset.index = self.index;
					self.container.dataset.absolute = self.absolute;
				},
				onComplete: function() {
					console.log('ON COMPLETE');
					self.currentPaginatedIndex = self.index = targetPaginatedIndex;

					self.container.dataset.currentPaginatedIndex = self.currentPaginatedIndex;
					self.container.dataset.index = self.index;
					self.container.dataset.absolute = self.absolute;

					self.container.dispatchEvent(new Event('change'));
				}
			}).start();


			/// Cleanup
			this.pointer = null;
			document.removeEventListener(event.type === 'touchstart'? 'touchmove' : 'mousemove', this);
			document.removeEventListener(event.type === 'touchstart'? 'touchend' : 'mouseup', this);
		},

		render() {
			var paginatedIndex;
			var pageIndex;
			if(this.index < 0) { paginatedIndex = 0; pageIndex = this.index }
			else if(this.index > this.paginated.length - 1) { paginatedIndex = this.paginated.length - 1; pageIndex = this.index - (this.paginated.length - 1) }
			else { paginatedIndex = this.index; pageIndex = 0 }

			this.container.style.setProperty(`--paginated-absolute`, this.absolute);
			this.container.style.setProperty(`--paginated-index`, paginatedIndex);
			this.container.style.setProperty(`--paginated-page-index`, pageIndex);
			this.container.dispatchEvent(new Event('input'));
		}
	};

	document.addEventListener('touchstart', Swiper);
	document.addEventListener('mousedown', Swiper);
})();









(function choreographedVideo() {
	var overlay = document.querySelector(".choreographed-player");
	if(overlay)
	{
		var actions = overlay.querySelectorAll("a[data-overlaytab]");
		var video = overlay.querySelector("video");
		var chapters = JSON.parse(video.dataset.chapters);
		// var chapters = video.dataset.chapters? video.dataset.chapters.split(',').map(function(d) { return parseFloat(d) }) : [];
		var images = Array.prototype.map.call(actions, function(action) {
			var img = new Image();
			var tab = action.dataset.overlaytab;
			var path = overlay.style.backgroundImage
				.replace(/url\("?([^)]*?)"?\)/, '$1')
				.replace(/(\d+)\.png/, tab + '.png');
			img.src = path;
			img.width = 1024;
			img.className = 'overlay';
			return img;
		});

		overlay.style.backgroundImage = '';
		overlay.insertBefore(images[0], overlay.firstChild);

		for(var i = 0; i < actions.length; i++)
		{
			actions[i].addEventListener(TAP_EVENT, _selectOverlayTab, true);
		}

		function _selectOverlayTab()
		{
			var tab = this.dataset.overlaytab;
			// if(images[tab] !== overlay.firstChild)
			// 	overlay.replaceChild(images[tab], overlay.firstChild);

			video.currentTime = chapters[tab][1] + (5/30);
			if(video.paused) video.play();
		}

		function _update(e)
		{
			var chapter = 0;
			for(var i = 0; i < chapters.length; i++)
			{
				if(video.currentTime >= chapters[i][1])
				{
					chapter = chapters[i][0];// i + 1;
				}
			}

			var button = actions[chapter];
			var tab = button.dataset.overlaytab;

			if(images[tab] !== overlay.firstChild)
				overlay.replaceChild(images[tab], overlay.firstChild);
		}

		video.addEventListener("timeupdate", _update);


		var overlayBtn = document.querySelector('aside.overlay button.close');
		overlayBtn && overlayBtn.addEventListener(TAP_EVENT, function() {
			overlay.replaceChild(images[0], overlay.firstChild);
		});
	}
})();



(function videoPlayers() {
	function VideoPlayer(element) {
		this.video = element;
		this.video.controls = false;
		this.textTrack = element.textTracks[0];
		if(this.textTrack) this.textTrack.mode = 'hidden';
		this.wrap();
		this.update();
	}

	VideoPlayer.prototype.wrap = function WrapVideo() {
		this.video.addEventListener('touchend', this.videoInteraction.bind(this));
		this.video.addEventListener('mouseup', this.videoInteraction.bind(this));
		this.video.addEventListener('timeupdate', this.videoTimeUpdate.bind(this));
		this.video.addEventListener('play', this.videoPlay.bind(this));
		this.video.addEventListener('pause', this.videoPause.bind(this));
		this.video.addEventListener('loadeddata', this.videoData.bind(this));
		this.video.addEventListener('loadedmetadata', this.videoMetaData.bind(this));
		this.video.addEventListener('progress', this.videoBuffering.bind(this));
		if(this.textTrack) this.textTrack.addEventListener('cuechange', this.videoCueChange.bind(this));

		var container = this.video.parentNode, nextElementSibling = this.video.nextElementSibling;
		this.root = h('div.video-player',
			this.video,
			this.poster = h('img.poster', { src: this.video.poster }),
			this.bigPlay = h('button.play-big'),
			this.subtitles = h('div.subtitles'),
			this.panel = h('nav.controls',
				this.play = h('button.play', {
					ontouchend: this.videoInteraction.bind(this),
					onmouseup: this.videoInteraction.bind(this),
				}),
				this.time = h('time.now'),
				this.progress = h('div.progress', {
						ontouchstart: this.progressStart.bind(this),
						onmousedown: this.progressStart.bind(this),
						ontouchmove: this.progressMove.bind(this),
						onmousemove: this.progressMove.bind(this),
						ontouchend: this.progressEnd.bind(this),
						onmouseup: this.progressEnd.bind(this),
					},
					this.progressTrack = h('div.track',
						this.progressBuffered = h('div.buffer'),
						this.progressPlayed = h('div.fill')
					),
					this.progressSeek = h('button.seek')
				),
				this.fullscreen = h('button.fullscreen', {
					ontouchend: this.goFullScreen.bind(this),
					onmouseup: this.goFullScreen.bind(this),
				}),
				this.cc = h('button.cc', {
					ontouchend: this.toggleCC.bind(this),
					onmouseup: this.toggleCC.bind(this),
				})
			)
		);

		if(!this.textTrack)
		{
			this.subtitles.remove();
			this.cc.remove();
		}

		container.insertBefore(this.root, nextElementSibling);
	};

	/// All the media events available:
	// loadstart, progress, suspend, abort, error, emptied, stalled, loadedmetadata, loadeddata, canplay, canplaythrough,
	// playing, waiting, seeking, seeked ,ended, durationchange, timeupdate, play, pause, ratechange, resize, volumechange

	VideoPlayer.prototype.videoBuffering = function(event) {
		if(!this.progressBox || this.progressBox.width < 100)
		{
			this.progressBox = this.progress.getBoundingClientRect();
		}

		if(isNaN(this.video.duration))
		{
			this.progressBuffered.style.transform = 'scaleX(0)';
			return;
		}

		var bufferedEnd = this.video.buffered.length > 0? this.video.buffered.end(this.video.buffered.length - 1) : 0;
		var percent = bufferedEnd / this.video.duration;
		this.progressBuffered.style.transform = `scaleX(${percent})`;
	};

	VideoPlayer.prototype.videoData = function(event) {
		if(this.textTrack) this.textTrack.mode = 'hidden';
	};

	VideoPlayer.prototype.videoMetaData = function(event) {
		this.updateTime();
		if(this.textTrack) this.textTrack.mode = 'hidden';
	};

	VideoPlayer.prototype.videoTimeUpdate = function(event) {
		this.updateTime();
		this.updateProgress();
	};

	VideoPlayer.prototype.videoPlay = function(event) {
		this.root.classList.add('is-playing');
		this.root.classList.add('has-played');
	};

	VideoPlayer.prototype.videoPause = function(event) {
		this.root.classList.remove('is-playing');
	};

	VideoPlayer.prototype.videoInteraction = function(event) {
		event.preventDefault();

		if(this.video.paused) this.video.play();
		else this.video.pause();
	};

	VideoPlayer.prototype.videoCueChange = function() {
		var cue = this.textTrack.activeCues[0]; // assuming there is only one active cue

		while(this.subtitles.firstChild) this.subtitles.firstChild.remove();

		if(cue)
		{
			this.subtitles.innerHTML = cue.text;
// 			this.subtitles.appendChild(cue.getCueAsHTML());
		}
	};

	VideoPlayer.prototype.toggleCC = function() {
		this.cc.classList.toggle('is-active');
		this.subtitles.classList.toggle('is-visible');
	};

	VideoPlayer.prototype.goFullScreen = function(event) {
		if(window.inVideo || (window.tryingVideo? window.tryingVideo+4000 < +new Date : false)) return;
		window.tryingVideo = +new Date;

		// this.video.classList.add('modal');
		// this.video.controls = true;

		// document.body.appendChild(this.video);

		// var close = h('button.close.close-video',
		// 	h('img.icon', {
		// 		height: 36,
		// 		src: 'common/img/button-close.png'
		// 	})
		// );
		// document.body.appendChild(close);

		var onFullscreen = function handleOnFullscreen(event) {
			event.stopImmediatePropagation();

			window.inVideo = true;
			window.tryingVideo = 0;
		}.bind(this);

		var offFullScreen = function handleOffFullScreen(event) {
			event.stopImmediatePropagation();

			window.inVideo = false;
			window.tryingVideo = 0;

			this.video.removeEventListener('webkitbeginfullscreen', onFullscreen);
			this.video.removeEventListener('webkitendfullscreen', offFullScreen);
			this.video.removeEventListener('ended', onEnded);

			// this.video.pause();
			// this.video.controls = false;
			// this.video.classList.remove('modal');
			// this.root.insertBefore(this.video, this.root.firstElementChild);
			document.body.removeChild(close);
		}.bind(this);

		var onEnded = function handleOnEnded(event) {
			event.stopImmediatePropagation();

			setTimeout(function() {
				if(this.video.webkitExitFullscreen) this.video.webkitExitFullscreen();
				else if(this.video.webkitExitFullScreen) this.video.webkitExitFullScreen();
				else if(this.video.exitFullscreen) this.video.exitFullscreen();
				else if(this.video.exitFullScreen) this.video.exitFullScreen();
			}, 2500);
		}.bind(this);

		this.video.addEventListener('webkitbeginfullscreen', onFullscreen);
		this.video.addEventListener('webkitendfullscreen', offFullScreen);
		this.video.addEventListener('ended', onEnded);

		if(this.video.requestFullScreen) this.video.requestFullScreen();
		if(this.video.requestFullscreen) this.video.requestFullscreen();
		else if(this.video.webkitRequestFullScreen) this.video.webkitRequestFullScreen();
		else if(this.video.webkitRequestFullscreen) this.video.webkitRequestFullscreen();
		else if(this.video.webkitEnterFullScreen) this.video.webkitEnterFullScreen();
		else if(this.video.webkitEnterFullscreen) this.video.webkitEnterFullscreen();

		// close.addEventListener(TAP_EVENT, offFullScreen);
	};

	VideoPlayer.prototype.progressStart = function(event) {
		this.progressDragging = true;
		this.progressBox = this.progress.getBoundingClientRect();

		if(!this.video.paused)
		{
			this.wasPlaying = true;
			this.video.pause();
		}

		var x = (event.changedTouches ? event.changedTouches[0] : event).pageX;
		this.progressTo(x);
	};

	VideoPlayer.prototype.progressMove = function(event) {
		if(!this.progressDragging) return;
		if(isNaN(this.video.duration)) return;

		var x = (event.changedTouches ? event.changedTouches[0] : event).pageX;
		this.progressTo(x);

	};

	VideoPlayer.prototype.progressEnd = function(event) {
		if(!this.progressDragging) return;
		this.progressDragging = false;
		if(isNaN(this.video.duration)) return;

		var x = (event.changedTouches ? event.changedTouches[0] : event).pageX;
		this.progressTo(x);

		if(this.wasPlaying)
		{
			this.wasPlaying = null;
			this.video.play();
		}
	};

	VideoPlayer.prototype.progressTo = function(x) {
		var position = Math.max(x - (this.progressBox.left + 10), 0);
		var percent = Math.min(position / (this.progressBox.width - 20), 1);

		this.video.currentTime = percent * this.video.duration;

		this.updateTime();
		this.updateProgress();
	}


	VideoPlayer.prototype.update = function() {
		// this.root, this.video, this.panel, this.play, this.time, this.progress, this.progressTrack, this.progressSeek

		this.updateTime();
		this.updateProgress();

	};

	VideoPlayer.prototype.updateTime = function() {
		if(isNaN(this.video.duration))
		{
			this.time.innerText = '- / -';
		}

		else
		{
			this.time.innerText = this.stampToText(this.video.currentTime) + ' / ' + this.stampToText(this.video.duration);
		}
	};

	VideoPlayer.prototype.stampToText = function(stamp) {
		var minutes = stamp / 60;
		var seconds = (minutes - Math.floor(minutes)) * 60;
		minutes = Math.floor(minutes);
		seconds = Math.round(seconds);
		if(seconds < 10) seconds = '0' + seconds;
		return minutes + ':' + seconds;
	};

	VideoPlayer.prototype.updateProgress = function() {
		if(!this.progressBox || this.progressBox.width < 100)
		{
			this.progressBox = this.progress.getBoundingClientRect();
		}

		if(isNaN(this.video.duration))
		{
			this.progressPlayed.style.transform = 'scaleX(0)';
			this.progressSeek.style.transform = 'translateX(0px)';
			return;
		}

		var percent = this.video.currentTime / this.video.duration;
		var absolute = (this.progressBox.width - 20) * percent;

		this.progressPlayed.style.transform = `scaleX(${percent})`;
		this.progressSeek.style.transform = `translateX(${absolute}px)`;
	};


	var videos = document.querySelectorAll("video");
	var iter = videos.length;
	while(iter-->0) new VideoPlayer(videos[iter]);
}());



(function accordions() {
	var accordions = document.querySelectorAll('div.accordion');
	if(!accordions.length) return;

	var paneWidth;
	var tabWidth = 55;

	window.renderAccordion = function renderAccordion(accordion) {
		var accordionWidth = accordion.clientWidth;
		var panes = Array.from(accordion.children);
		var paneWidth = accordionWidth - tabWidth * panes.length;
		if(localStorage.toggle=="true"){
           var index = 1;
        }
        else if(localStorage.toggleDos=="true"){
            var index = 2;
        }
        else{
        	 var index = parseInt(accordion.dataset.selectedIndex) || 0;
        }
		//var index = parseInt(accordion.dataset.selectedIndex) || 0;

		var pane = panes[index];
		document.documentElement.dataset.accordion = (accordion.dataset.name? accordion.dataset.name + '.' : '') + (pane.dataset.name || index);


		for(var iter = 0, total = panes.length; iter < total; ++iter)
		{
			var position = tabWidth * iter;

			if(iter > index) position = paneWidth + position;

			pane = panes[iter];
			pane.style.transform = `translateX(${position}px) translateZ(0)`;
			pane.classList[iter === index? 'add' : 'remove']('is-active');
		}

		accordion.dispatchEvent(new Event('change', { bubbles: true }));
	}



	var accordion, pane, index;

	if(hasDefaultAccordion)
	{
		var key;
		if(Array.isArray(defaultAccordion) && defaultAccordion.length > 1)
		{
			key = defaultAccordion.shift();

			if(+key == key) accordion = accordions[key];
			else accordion = accordions.find(function(d) { return d.dataset.name === key });
		}

		else accordion = accordions[0];


		key = defaultAccordion.shift();
		var panes = Array.from(accordion.children).filter(function(d) { return d.matches('div.pane') });

		if(+key == key)
		{
			index = key;
			pane = panes[index];
		}

		else
		{
			pane = panes.find(function(d) { return d.dataset.name === key });
			index = panes.indexOf(pane);
		}
	}


	else
	{
		accordion = accordions[0];
		var panes = Array.from(accordion.children).filter(function(d) { return d.matches('div.pane') });
		index = 0;
		pane = panes[index];
	}if(localStorage.weight=="true")
    	{	

    		index=1;
    		
    		localStorage.removeItem("weight");
           // localStorage.removeItem("toggle");
    	}
        if(localStorage.dosing=="true")
        {   

            index=2;
            
            localStorage.removeItem("dosing");
           // localStorage.removeItem("toggle");
        }

	accordion.dataset.selectedIndex = index;
	renderAccordion(accordion);


	Array.from(accordions).reverse().forEach(function(accordion) {
		renderAccordion(accordion);
		requestAnimationFrame(function() {
			accordion.classList.add('with-motion');
		});
	});

	function onAccordionTab(event) {
		var button = event.target.closest('div.accordion button.tab');
		if(!button) return;

		event.preventDefault();

		var pane = button.parentNode;
		var accordion = pane.parentNode;
		var panes = Array.from(accordion.children);
		var index = panes.indexOf(pane);

		accordion.dataset.selectedIndex = index;
		renderAccordion(accordion);
		accordion.dispatchEvent(new Event('change'));

		loadDetails();
	}

	document.addEventListener('mousedown', onAccordionTab);
	document.addEventListener('touchend', onAccordionTab);
}());







(function toggles() {
	function onToggle(event) {
		var toggle = event.target.closest('div.toggle');
		if(!toggle) return;

		event.preventDefault();

		toggle.dataset.checked = toggle.classList.toggle('is-active');
		toggle.dispatchEvent(new Event('change'));
	}

	document.addEventListener('mousedown', onToggle);
	document.addEventListener('touchend', onToggle);
}());






(function() {
	window.loadDetails = function loadDetails(path, override) {
		if(!path)
		{
			var dataPath;
			var path;
			var section = document.documentElement.dataset.section;
			var page = document.documentElement.dataset.page;
			var accordion = document.documentElement.dataset.accordion;



			
			var $footnotes = document.querySelector('aside.details.footnotes.is-open');
			var $studies = document.querySelector('aside.details.studies.is-open');
			var $openPopups = document.querySelectorAll('aside.popup.is-open');


			path = [
				section,
				page,
				Swiper.paginated.length > 1? 'paginated.' + Swiper.currentPaginatedIndex : null,
				accordion? 'accordion.' + accordion : null
			].filter(function(d) { return d }).join('.');
			



			if($footnotes && $footnotes.dataset.footnotes)
			{
				path = `footnotes.${$footnotes.dataset.footnotes}`;
				override = 'footnotes';
			}

			else if($studies && $studies.dataset.studies)
			{
				path = `studies.${$studies.dataset.studies}`;
				override = 'studies';
			}

			else if($openPopups.length)
			{
				var $currentPopup =  $openPopups[$openPopups.length - 1];
				var popup = $currentPopup.dataset.popup;

				if(popup === 'data-library') dataPath = path;
				if(/^(footnotes|studies|references|data|objection)\./.test(popup)) path = popup;

				else
				{
					if(section !== page) path = section + '.' + page;
					else path = section;
					if(!popup) popup = $popup.dataset.popup;
					path += '.' + popup;
				}
			}
		}


		var node = findNode(path) || {};
		console.log(path, node);

		if(Array.isArray(node))
		{
			node = node.reduce(function(composite, current) {
				if(current.footnotes)
				{
					if(!composite.footnotes) composite.footnotes = [];
					composite.footnotes = composite.footnotes.concat(current.footnotes);
				}

				if(current.tableFootnotes)
				{
					if(!composite.tableFootnotes) composite.tableFootnotes = [];
					composite.tableFootnotes = composite.tableFootnotes.concat(current.tableFootnotes);
				}

				if(current.studies)
				{
					if(!composite.studies) composite.studies = [];
					composite.studies = composite.studies.concat(current.studies);
				}

				if(current.references)
				{
					if(!composite.references) composite.references = [];
					composite.references = composite.references.concat(current.references);
				}

				if(current.data)
				{
					if(!composite.data) composite.data = [];
					composite.data = composite.data.concat(current.data);
				}

				return composite;
			}, {});
		}


		if(override)
		{
			if(override === 'footnotes')
			{
				loadStudies(node.studies);
			}
			else if(override === 'studies')
			{
				loadFootnotes(node.footnotes);
				loadTableFootnotes(node.tableFootnotes);
			}
		}

		else
		{
			loadFootnotes(node.footnotes);
			loadTableFootnotes(node.tableFootnotes);
			loadStudies(node.studies);
		}

		loadReferences(node.references);
		loadLibrary(dataPath? (findNode(dataPath) || {}).data : node.data);
	}

	function hasSecondaryPage(secondary, page)  {
		var match = Object.keys(secondary).find(function(key) {

			if(/\[\d-\d\]/.test(key))
			{
				var matches = key.match(/^(.*)?\[(\d)-(\d)\](.*)?$/);
				var prefix = matches[1] || ''
				var suffix = matches[4] || '';
				var from = matches[2];
				var to = matches[3];
				var iter;
				for(iter = from; iter <= to; ++iter)
				{
					var k = prefix + iter + suffix;
					if(k === page) return true;
				}
			}

			else return key === page;
		});

		if(match) return secondary[match];
		else return null;
	}

	function findNode(path) {
		path = path.split('.');
		var root = PrimaryPages;

		if(path[0] === 'footnotes') { root = Footnotes; path.shift() }
		else if(path[0] === 'studies') { root = Studies; path.shift() }
		else if(path[0] === 'references') { root = References; path.shift() }
		else if(path[0] === 'data') { root = DataLibraryReferences; path.shift() }
		else if(path[0] === 'objection') { root = Objections; path.shift() }

		var node = traverseNode(path, root);
		return node;
	}

	function traverseNode(path, node, root) {
		if(!node) return node;
		if(!root) root = node;

		var key = path.shift();
		if(!key) return node;

		var temp;

		if(/,/.test(key))
		{
			return nodes = key.split(',').map(function(k) {
				var p = path.slice();
				p.unshift(k);
				return traverseNode(p, node, root);
			});
		}

		else if(root === PrimaryPages && node.secondary && (temp = hasSecondaryPage(node.secondary, key))) node = temp;

		else if(node.sitemap && (temp = node.sitemap.find(function(d) { return d.popup === key || d.page === key }))) node = temp;

		else if(node.popups && node.popups[key]) node = node.popups[key];

		else node = node[key];

		return traverseNode(path.slice(), node, root);
	}


	function loadFootnotes(footnotes) {
		var $details = document.querySelector('aside.details.footnotes');
		if(!$details) return;
		var $content = $details.querySelector('div.content');
		if(!footnotes || !footnotes.length)
		{
			window.deferredFootnotesRender = null;
			$details.classList.add('is-hidden');
			return;
		}

		$details.classList.remove('is-hidden');

		window.deferredFootnotesRender = function deferredFootnotesRender() {
			window.deferredFootnotesRender = null;

			while($content.firstChild) $content.removeChild($content.firstChild);
			$content.scrollTop = 0;
			$content.dispatchEvent(new Event('scroll'));

			$details.dataset.footnotes = footnotes.join(',');

			var refs = [];

			footnotes.map(function(key) {
				var name;
				if(/:/.test(key))
				{
					key = key.split(':');
					return {
						prefix: key[1],
						node: Footnotes[key[0]]
					};
				}

				else
				{
					return {
						node: Footnotes[key]
					};
				}
			})
			.forEach(function(d) {
				var footnote = d.node;
				var $footnote = h('div.footnote', { innerHTML: footnote.content });

				if(d.prefix)
				{
					var $prefix = $footnote.querySelector('span.pre');
					var prefix = d.prefix;
					if(/^(†|‡)$/.test(prefix)) prefix = `<sup>${prefix}</sup>`;
					$prefix.innerHTML = prefix;
				}

				if(footnote.references)
				{
					/// Add to shared list
					var mapping = footnote.references.map(function(ref) {
						var index = refs.indexOf(ref);
						if(refs.indexOf(ref) === -1)
						{
							index = refs.length;
							refs.push(ref);
							return index;
						}

						else
						{
							return index;
						}
					});

					/// Renumber all sup.ref's
					var $refs = $footnote.querySelectorAll('sup.ref');
					Array.from($refs).forEach(function($ref) {
						var index = parseInt($ref.innerText); // Handle multiple references (comma), reference ranges, etc
						var number = mapping[index - 1] + 1;
						$ref.innerText = number;
					});

					$details.classList.add('has-references');
				}

				$content.appendChild($footnote);
			});
		};
	}


	function loadTableFootnotes(footnotes) {
		var $details = document.querySelector('aside.details.footnotes.table');
		if(!$details) return;
		var $content = $details.querySelector('div.content');
		if(!footnotes || !footnotes.length)
		{
			window.deferredTableFootnotesRender = null;
			$details.classList.add('is-hidden');
			return
		}

		$details.classList.remove('is-hidden');

		window.deferredTableFootnotesRender = function deferredTableFootnotesRender() {
			window.deferredTableFootnotesRender = null;

			while($content.firstChild) $content.removeChild($content.firstChild);
			$content.scrollTop = 0;
			$content.dispatchEvent(new Event('scroll'));

			$details.dataset.footnotes = footnotes.join(',');

			footnotes.map(function(key) { return Footnotes[key] })
			.forEach(function(footnote) {
				if(footnote.references) $details.classList.add('has-references');
				$content.appendChild(
					h('div.footnote', { innerHTML: footnote.content })
				);
			});
		};
	}

	function loadStudies(studies) {
		var $details = document.querySelector('aside.details.studies');
		if(!$details) return;
		var $content = $details.querySelector('div.content');
		if(!studies || !studies.length)
		{
			window.deferredStudiesRender = null;
			$details.classList.add('is-hidden');
			return;
		}

		$details.classList.remove('has-references');
		$details.classList.remove('is-hidden');

		window.deferredStudiesRender = function deferredStudiesRender() {
			window.deferredStudiesRender = null;
			while($content.firstChild) $content.removeChild($content.firstChild);
			$content.scrollTop = 0;
			$content.dispatchEvent(new Event('scroll'));

			$details.dataset.studies = studies.join(',');

			var refs = [];

			studies.map(function(key) { return Studies[key] })
			.forEach(function(study) {
				var $study = h('div.study', { innerHTML: study.content });

				if(study.references)
				{
					/// Add to shared list
					var mapping = study.references.map(function(ref) {
						var index = refs.indexOf(ref);
						if(refs.indexOf(ref) === -1)
						{
							index = refs.length;
							refs.push(ref);
							return index;
						}

						else
						{
							return index;
						}
					});

					/// Renumber all sup.ref's
					var $refs = $study.querySelectorAll('sup.ref');
					Array.from($refs).forEach(function($ref) {
						var index = parseInt($ref.innerText); // Handle multiple references (comma), reference ranges, etc
						var number = mapping[index - 1] + 1;
						$ref.innerText = number;
					});

					$details.classList.add('has-references');
				}

				$content.appendChild($study);
			});
		};
	}

	function loadReferences(references) {
		var $details = document.querySelector('aside.details.references');
		if(!$details) return;
		var $content = $details.querySelector('div.content');
		if(!references || !references.length)
		{
			window.deferredReferencesRender = null;
			$details.classList.add('is-hidden');
			return;
		}

		$details.classList.remove('is-hidden');

		window.deferredReferencesRender = function deferredReferencesRender() {
			window.deferredReferencesRender = null;

			while($content.firstChild) $content.removeChild($content.firstChild);
			$content.scrollTop = 0;
			$content.dispatchEvent(new Event('scroll'));

			var $references = h('ul.references',
				references.map(function(key) { return References[key] })
				.map(function(reference) { return h('li', { innerHTML: reference }) })
			);
			$content.appendChild($references);
		}
	}

	function loadLibrary(recommended) {
		var $library = document.querySelector('aside.data-library');
		if(!$library) return;
		if(!recommended) recommended = [];
		var hasRecommended = recommended.length !== 0;

		if(hasRecommended) $library.classList.remove('no-recommendations');
		else $library.classList.add('no-recommendations');

		window.deferredLibraryRender = function deferredLibraryRender() {
			window.deferredLibraryRender = null;

			var $recommended = $library.querySelector('ul.data.recommended');
			var $hba1c = $library.querySelector('ul.data.hba1c');
			var $weight = $library.querySelector('ul.data.weight');
			var $other = $library.querySelector('ul.data.other');

			while($recommended.firstChild) $recommended.removeChild($recommended.firstChild);
			while($hba1c.firstChild) $hba1c.removeChild($hba1c.firstChild);
			while($weight.firstChild) $weight.removeChild($weight.firstChild);
			while($other.firstChild) $other.removeChild($other.firstChild);


			LibraryData.forEach(function(d) {
				var isRecommended = recommended.some(function(r) { return d.type === r.type && d.name === r.name });

				if(isRecommended)
				{
					var $item = h(`li.open-data`, h(`span.icon-shape.${d.type}`, { innerHTML: d.content }));
					$item.dataset.type = d.type;
					$item.dataset.name = d.name;
					$recommended.appendChild($item);
				}

				else
				{
					var list;
					if(d.type === 'hba1c') list = $hba1c; else
					if(d.type === 'weight') list = $weight; else
					if(d.type === 'other') list = $other;

					var $item = h('li.open-data', { innerHTML: d.content });
					$item.dataset.type = d.type;
					$item.dataset.name = d.name;
					list.appendChild($item);
				}
			});
		};
	}

	function onLibrary(event) {
		var $item = event.target.closest('.open-data');
		if(!$item) return;
		event.preventDefault();

		var type = $item.dataset.type;
		var name = $item.dataset.name;
		var popup = `data.${type}-${name}`;
		var $popup = document.querySelector(`aside.popup[data-popup="${popup}"]`);
		if(!$popup)
		{
			$popup = h('aside.popup.data', {
				innerHTML: `
					${LibraryData.find(function(d) { return d.type === type && d.name === name }).popup}
					<button class="close"></button>
				`
			});
			$popup.dataset.popup = popup;
			document.body.insertBefore($popup, document.querySelector('aside.data-library').nextElementSibling);
		}

		$item.classList.add('is-active');
		setTimeout(function() {
			$item.classList.remove('is-active');
		}, 800);

		setTimeout(function() {
			openPopup(popup);
		}, 200);
	}

	document.addEventListener('mouseup', onLibrary);
	document.addEventListener('touchend', onLibrary);



	loadDetails();
})();


(function() {
	window.deferredObjectionRender = function deferredObjectionRender() {
		window.deferredObjectionRender = null;

		function onObjection(event) {
			var $item = event.target.closest('[data-objection]');
			if(!$item) return;
			event.preventDefault();

			var name = $item.dataset.objection;
			var popup = `objection.${name}`;
			var $popup = document.querySelector(`aside.popup[data-popup="${popup}"]`);
			if(!$popup)
			{
				$popup = h('aside.popup.objection', {
					innerHTML: `
						${Objections[name].popup}
						<button class="close"></button>
					`
				});
				$popup.dataset.popup = popup;
				document.body.insertBefore($popup, document.querySelector('div.mask.studies'));
			}

			closePopup();


			document.querySelector('div.mask.objection').classList.toggle('is-visible');
			document.querySelector('nav.primary').classList.toggle('has-objection');
			document.querySelector('nav.objection').classList.toggle('is-open');

			$item.classList.add('is-active');
			setTimeout(function() {
				$item.classList.remove('is-active');
			}, 800);

			setTimeout(function() {
				document.querySelector('button.global.objection').classList.toggle('is-active');
				openPopup(popup);
			}, 200);
		}

		var $nav = document.querySelector('nav.objection');
		$nav.innerHTML = `
			<div class="row header" style="left: 20px;width: 130px;top: 0px;height: 45px;">
				<span class="label">COMMON<br>OBJECTIONS</span>
			</div>
			<div class="row" data-objection="egfr" style="left: 20px;width: 130px;top: 56px;height: 55px;">
				<span class="label">eGFR</span>
			</div>
		`;

		$nav.addEventListener('mouseup', onObjection);
		$nav.addEventListener('touchend', onObjection);
	}
})();


(function() {
	document.addEventListener('gesturechange', function() {}); // iOS: Makes sure scroll events are all live
// 	document.addEventListener('touchstart', function(event) {
// 		if(!event.target.matches('.scrollable')) return;
// 		event.target.style.outlineOffset = '-20px';
// 		event.target.style.outline = '10px dashed red';
// 		TrackScrollInertia.isTouching = true;
// 	}, true);
// 	document.addEventListener('touchend', function(event) {
// 		if(!event.target.matches('.scrollable')) return;
// 		event.target.style.outlineOffset = '-20px';
// 		event.target.style.outline = '10px dashed green';
// 		TrackScrollInertia.isTouching = false;
// 	}, true);

	document.addEventListener('scroll', function(event) {
		if(!event.target.matches('.scrollable')) return;
		var scrollable = event.target;
// 		if(TrackScrollInertia.isTouching && !TrackScrollInertia.isScrolling)
// 		{
// 			TrackScrollInertia.init(scrollable);
// 		}

		var min = 80;
		var max = scrollable.scrollHeight - scrollable.clientHeight;
		var pos = scrollable.scrollTop;

		var distToMin = Math.max(-(min - pos), 0);
		var distToBottom = Math.abs(max - pos);

		var top = rescale.clamped(0, 40, -5, 0, distToMin);
		var bottom = rescale.clamped(0, 40, -5, 0, distToBottom);

		scrollable.style.backgroundPosition = `center top ${top}%, center bottom ${bottom}%`;
	}, true);



// 	var TrackScrollInertia = {
// 		lastScrollAt: 0,
// 		isScrolling: false,
// 		isTouching: false,
// 		scrollable: null,

// 		init(scrollable) {
// 			this.isScrolling = true; // Yup, first scroll
// 			this.scrollable = scrollable;
// 			this.scrollable.addEventListener('scroll', this);
// 			this.scrollable.style.outlineOffset = '-20px';
// 			this.scrollable.style.outline = '2px solid blue';
// 		},

// 		handleEvent(event) {
// 			if(event.type === 'touchstart') this.handleTouchStart(event);
// 			if(event.type === 'touchend') this.handleTouchEnd(event);
// 			else if(event.type === 'scroll') this.handleScroll(event);
// 		},

// 		handleTouchStart(event) {
// 			this.isTouching = true;
// 		},

// 		handleTouchEnd(event) {
// 			var now = +new Date;
// 			this.isTouching = false;
// 			if(now + 4 > this.lastScrollAt) this.handleScrollEnd();
// 		},

// 		handleScroll(event) {
// 			if(!this.isTouching)
// 			{
// 				this.handleScrollEnd();
// 			}

// 			this.scrollable.style.outlineOffset = '-20px';
// 			this.scrollable.style.outline = '2px solid green';
// 			this.lastScrollAt = +new Date;
// 		},

// 		handleScrollEnd() {
// 			this.scrollable.style.outlineOffset = '-20px';
// 			this.scrollable.style.outline = '2px solid red';
// 			this.scrollable = null;
// 			this.isScrolling = false;
// 		}
// 	};


})();
