$(document).ready(function () {
	
	"use strict";

		setTimeout(function(){ 
		$("#wrapperImg").css("visibility","hidden");
		}, 150);
		setTimeout(function(){ 
		$(".wrapper").css("visibility","visible");
		}, 150);

	$('.logolink,#topnav2,#topnav3,#topnav4,#topnav5,#topnav6,#topnav7').on('tap', function () {
		window.location.href = $(this).attr('goto');
	});


	// EOS POPUP
	$("#eos").on("tap", function () {
		$(this).addClass("navactive");
		$("#study").removeClass("navactive2");
		$("#target").removeClass("navactive");
		$("#ref").removeClass("navactive");
		$('#popup_bg_1').show();
		$('#popup_bg_2').hide();
		$("#popup_bg_ref").css("visibility", "hidden");
		$("#refcontent_popup").removeClass("active").css("visibility", "hidden");
		$("#ref").removeClass("navactive2");
	});
	$("#popup_close").on("tap", function () {
		$('#popup_bg_1').hide();
		$("#eos").removeClass("navactive");
	});

	// Target POPUP
	$("#target").on("tap",function () {
		$(this).addClass("navactive");
		$("#study").removeClass("navactive2");
		$("#eos,#ref").removeClass("navactive");
		$('#popup_bg_2').show();
		$('#popup_bg_1').hide();	
		$("#popup_bg_ref").css("visibility", "hidden");
		$("#refcontent_popup").removeClass("active").css("visibility", "hidden");
		$("#ref").removeClass("navactive2");	
	});
	//inside popup
	// $("#res_analysis").on("tap", function () {
	// 	$('#responder_Popup, .overlay2').show();
	// });
	// $("#popup_close7").on("tap", function () {
	// 	$('#responder_Popup, .overlay2').hide();
	// });

	$("#popup_close2").on("tap",function () {
		$('#popup_bg_2').hide();
		$("#target").removeClass("navactive");
	});

	//inside popup2
	$("#karin").on("tap", function () {
		$('#karinPopup, .overlay2').show();
		$('#pop_Head2, #karin,#pink,#pop2_txt').hide();
		$('#foot_Txt').hide();
	});
	$("#popup_close5").on("tap", function () {
		$('#karinPopup, .overlay2').hide();
		$('#pop_Head2, #karin,#pink,#pop2_txt').show();
		$('#foot_Txt').show();
	});
	$("#marcus").on("tap", function () {
		$('#marcusPopup, .overlay2').show();
		$('#pop_Head2, #karin,#pink,#pop2_txt').hide();
		$('#foot_Txt').hide();
	});
	$("#popup_close6").on("tap", function () {
		$('#marcusPopup, .overlay2').hide();
		$('#pop_Head2, #karin,#pink,#pop2_txt').show();
		$('#foot_Txt').show();
	});
	

	
	// Study design popup
	$("#study").on("tap", function () {
		mySwiper._slideTo(0, 0);
		$(this).addClass("navactive2");
		$("#refcontent_popup").addClass("active").css("visibility", "visible");
		$('#popup_bg_1,#popup_bg_2').hide();
		$("#popup_bg_ref").css("visibility", "hidden");
		$("#eos,#target,#ref").removeClass("navactive");   
		$("#ref").removeClass("navactive2");
	});
	$("#popup_close3").on("tap", function () {
		$("#refcontent_popup").removeClass("active").css("visibility", "hidden");
		$("#study").removeClass("navactive2");
	});


	//REF
	$("#ref").on("tap", function () {
		$(this).addClass("navactive2");
		/*$('#popup_bg_ref').show();	*/
		$("#popup_bg_ref").css("visibility", "visible"); 
		$('#popup_bg_1,#popup_bg_2,#popup_bg_4').hide();
		$("#refcontent_popup").removeClass("active").css("visibility", "hidden");
		
		$("#study").removeClass("navactive2");
		$("#target,#eos").removeClass("navactive");
		
	});
	$("#Refpopup_close").on("tap", function () {
		/*$('#popup_bg_ref').hide();*/	
		$("#popup_bg_ref").css("visibility", "hidden");	
		$("#ref").removeClass("navactive2");
	});

	var video = document.getElementById('Moavideo');
	$("#view_Moa").bind("tap", function () {
		$('#popup_bg_4').show();
		$("#sideNav").hide();
		video.play();
		video.currentTime = 0;
		video.muted = false;
	});	
	$("#popup_close4").bind("tap", function () {
		$('#popup_bg_4').hide();
		$("#sideNav").show();
		$("#Moavideo")[0].pause();
	});
	//smpc
	$("#smpc").on("tap", function () {
		$('#popup_bg_smpc').show();
		//parent
		$('#sideNav,#popup_bg_1,#popup_bg_2').hide();
		$("#popup_bg_ref").css("visibility", "hidden");
		$("#refcontent_popup").removeClass("active").css("visibility", "hidden");	

	});
	//close
	$("#popup_close04").on("tap", function () {
		$('#popup_bg_smpc').hide();
		$('#sideNav').show();	
		$("#study,#ref").removeClass("navactive2");
		$("#target,#eos").removeClass("navactive");	
	});
	
	/*Patient Popup*/

	$("#patients_Early").on("tap", function () {
		$('#benefitPopup_second').css({
			"visibility": "visible"
		});
		$('#footer_second,#patients_Early_second,#main-head_second').hide();
		$('#foot_Txt').hide();
	});

	$("#benefitPopupClose_second").on("tap", function () {
		$('#benefitPopup_second').css({
			"visibility": "hidden"
		});
		$('#footer_2,#patients_Early_second,#main-head_second').show();
		$('#foot_Txt').show();
	});
});