// JavaScript Document

/*---image functionality---*/
var clickHandler = "click";
$(document).ready(function(e) {
		"use strict";
	
		var images= [
        '../images/bg.jpg',
		'../images/ref.jpg'
    ];

    var $list = $('#imagesList');

    $.each(images, function(i, src) {
        var $li = $('<li class="loading">').appendTo($list);
        $('<img>').appendTo($li).one('load', function() {
            $li.removeClass('loading');
       }).attr('src', src);
    });	

	setTimeout(function () {
		$("#wrapperImg").css("visibility", "hidden");
	}, 300);
	
	
	
	$('.clickattr').bind('tap', function(){
		window.location.href=$(this).attr('goto');
	});

	$('img, a').on('dragstart', function(event){event.preventDefault();});	
	
	
	
	$("#text").delay(200).animate({'opacity' : '1'},1,function(){
	 	$("#text").attr({'class':'animated zoomIn'});
	 });
	
	// $("#circle1_color").delay(400).animate({'opacity' : '1'},1,function(){
	//  	$("#circle1_color").attr({'class':'animated flipInY'});
	//  });
	
	
	$("#menu").bind('tap', function(){
		$("#menu_slide").slideDown("slow");
	});
	
	$("#menu_close").bind('tap', function(){
		$("#menu_slide").slideUp("slow");
	});
	
	$("#circle1,#circle2,#circle3").flip({
		axis: "y",
		reverse: false,
		trigger: "click"
	});
	$("#circle1").css({ "pointer-events" : "none" });
	$("#circle2").css({ "pointer-events" : "none" });
	$("#circle3").css({ "pointer-events" : "none" });
	
	setTimeout(function () {
		$("#circle1").click();
		$("#circle1").css({ "pointer-events" : "none" });

		// setInterval(function () {
//			$("#right-rotate").addClass("right-rotate");
//			$("#right-rotate").removeClass("right-rotate-after");
////			$("#right-rotate").addClass("right-rotate-after");
//			setTimeout(function () {
//				$("#right-rotate").removeClass("right-rotate");
////				$("#right-rotate").removeClass("right-rotate-after");
//				$("#right-rotate").addClass("right-rotate-after");
//			},1000);

		// $("#right-rotate").css({'opacity' : '1',"left" : "126px"});
		// 	$("#right-rotate").delay(1000).animate({'opacity' : '0',"left" : "70px"},1000);
		// },2000);

		function firstleft(){
	    	$("#right-rotate").animate({"left": "105px",opacity:1 }, 500, "swing", firstright);
		}
		function firstright(){
			$("#right-rotate").animate({'opacity' : '0',"left" : "70px"},500, "swing",function(){
				$("#right-rotate").animate({'opacity' : '0',"left" : "126px"});
				firstleft();
			});
			// $("#right-rotate").animate({'opacity' : '0',"left" : "126px"},function(){
			// 	$("#right-rotate").animate({'opacity' : '1'});
			// });
			// $("#right-rotate").animate({'opacity' : '1',"left" : "126px"}, 1500, "swing", firstleft);
		}
		firstleft();

		$("#rotate").animate({
			opacity: 1
		},
		1000);

		$("#circle1_data").animate({
			top: "230px"
		},
		1000,
		function(){
			$('#rotate').addClass("rotate");
			setTimeout(function () {
				$('#rotate').removeClass("rotate");
			},1000);
		});

	},1000);

	setTimeout(function () {
		var mySound = new Audio("./audio/MCS.wav");
		mySound.play();
	},1300);	

	setTimeout(function () {
		$("#circle2").click();
		$("#circle2").css({ "pointer-events" : "none" });

		$("#red_blink_ntxt").delay(600).animate({'opacity' : '1'},1,function(){
		 	$("#red_blink_ntxt").attr({'class':'animated fadeInDown'});
			setTimeout(function(){ $("#red_blink_ntxt").attr({'class':'animated flash infinite'}); }, 1900);
		});

		setInterval(function () {
			$("#white_blink").css({'opacity' : '1',"width" : "20px","left": "45px", "top": "0px"});
			$("#white_blink").delay(1000).animate({'opacity' : '0',"width" : "60px","left": "30px", "top": "-15px"},1000);
		},1000);

		$("#circle2_data").animate({
			top: "145px"
		},
		1000,
		function(){

		});

	},2000);

	setTimeout(function () {
		$("#circle3").click();
		$("#circle3").css({ "pointer-events" : "none" });

		setInterval(function () {
			$("#white_waves1").css({'opacity' : '1',"left" : "130px"});
			$("#white_waves1").animate({'opacity' : '0',"left" : "60px"},1000);
			$("#white_waves2").css({'opacity' : '1',"left" : "130px"});
			$("#white_waves2").animate({'opacity' : '0',"left" : "60px"},1000);
		},2000);

		setInterval(function () {
			$("#wave_red").css({'opacity' : '1',"left" : "55px"});
			$("#wave_red").animate({'opacity' : '0',"left" : "135px"},1000);
		},2000);


		// $("#wave_red").delay(1000).animate({'opacity' : '1'},1,function(){
		// 	$("#wave_red").attr({'class':'animated fadeOutRight'});
		// 	setTimeout(function(){ $("#wave_red").attr({'class':'animated fadeOutRight infinite'}); }, 2000);
		// });

		$("#circle3_data").animate({
			top: "155px"
		},
		1000,
		function(){

		});

	},3000);



});
