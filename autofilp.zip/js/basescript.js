$(document).ready(function() {

	"use strict";

    $("body").bind('touchmove', function(event) {
        event.preventDefault();
    });   

    $("#wrapper").swipe({

        swipe: function(event, direction, distance, duration, fingerCount) {

            if (!$(event.target).hasClass('noSwipe')) {
                console.log(direction);
               if (direction == 'left') {                  
                    document.location="veeva:nextSlide()";                                              

                } else if (direction == 'right') {
                    document.location="veeva:prevSlide()";    
                } 
            }
            event.stopImmediatePropagation();
            event.preventDefault();
        },
        threshold: 200
    });
});