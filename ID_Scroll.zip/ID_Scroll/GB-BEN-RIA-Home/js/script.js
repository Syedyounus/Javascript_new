$(document).ready(function () {
	
	"use strict";

		setTimeout(function(){ 
		$("#wrapperImg").css("visibility","hidden");
		}, 50);
		setTimeout(function(){ 
		$(".wrapper").css("visibility","visible");
		}, 50);
	$('.wrapper').on('tap', function () {
		window.location.href = $(this).attr('goto');
	});
	
	$("#smpc").on("tap", function () {
//		document.location="pdf/smpc.pdf";
		$("#popup_bg_smpc1").show();
		$('#smpc').hide();
	});
	
	$('img').on("dragstart", function(){
		return false;
	});
	
	$("#popup_close10").on("tap", function () {
		$("#popup_bg_smpc1").hide();
		$('#smpc').show();
//		$('#smpc').removeClass('smpc_active');

	});

	
	//smpc
//	$("#smpc").on("tap", function () {
//		$('#popup_bg_smpc').show();
////		//parent
////		$('#sideNav,#popup_bg_ref,#popup_bg_1,#popup_bg_2').hide();
////		$("#refcontent_popup").removeClass("active").css("visibility", "hidden");	
//
//	});
	

	
	//close
//	$("#popup_close04").on("tap", function () {
//		$('#popup_bg_smpc').hide();
////		$('#sideNav').show();	
////		$("#study,#ref").removeClass("navactive2");
////		$("#target,#eos").removeClass("navactive");	
//	});
});