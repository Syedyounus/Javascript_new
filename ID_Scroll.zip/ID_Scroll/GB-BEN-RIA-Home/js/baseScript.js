$(document).ready(function () {

	"use strict";

	$("body").bind('touchmove', function (event) {
		event.preventDefault();
	});

	$(".wrapper").swipe({
		swipe: function (event, direction, distance, duration, fingerCount) {
			//This only fires when the user swipes left
			console.log(direction);
			if (!$(event.target).hasClass('dragable_icon') && !$(event.target).hasClass('ui-draggable') && !$(event.target).hasClass('noSwipe')) {
				if (direction == 'left') {
					
					setTimeout(function () {
						$("*").css("transform", "none");
						document.location = "veeva:gotoSlide(GB-BEN-RIA-MoA-Eosinophils.zip, GB-BEN)";
					}, 100);
				} else if (direction == 'right') {
						//					document.location="veeva:gotoSlide(GB-BEN-RIA-MoA-Eosinophils.zip, GB-BEN)";
				
				}
			}

		}
	});
});
