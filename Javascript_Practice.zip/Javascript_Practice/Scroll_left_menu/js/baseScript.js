var currentSlide = 0;
$(document).ready(function () {
	"use strict";


	$("body").bind("touchmove", function (e) {
		e.preventDefault();
	});



	$(".wrapper").swipe({
		swipe: function (event, direction, distance, duration, fingerCount) {
			console.log(direction);
			if (!$(event.target).hasClass('dragable_icon') && !$(event.target).hasClass('ui-draggable') && !$(event.target).hasClass('noSwipe')) {
				if (direction == 'left') {
					 document.location="veeva:nextSlide()";  
				} else if (direction == 'right') {
					 document.location="veeva:prevSlide()";    
				}
			}

		}
	});


});
