/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

$(document).ready(function () {
	"use strict";
	$('#sliderb_container0,#sliderb_container,#sliderb_container2,.closeBtn,.closeBtn1,.closeBtn0,#graph_img2,#sliderb_container_pop,.closeBtn_pop').hide();
	setTimeout(function () {
		$("#wrapperImg").css("visibility", "hidden");
	}, 200);
	setTimeout(function () {
		$(".wrapper").css("visibility", "visible");
	}, 200);


	$('.clickattr').bind('tap', function () {
		window.location.href = $(this).attr('goto');
	});
	
//	$('#pop_btn').bind('tap', function () {
//		
//		$('#popup,.overlay,#pop_close').css("visibility", "visible");
//	});
	
	var pop_btn = document.getElementById('pop_btn');
	var popup = document.getElementById('popup');
	var pop_close = document.getElementById('pop_close');
	var overlay = document.querySelector('.overlay');
	
	pop_btn.onclick = function(){
		popup.style.visibility = 'visible';
		pop_close.style.visibility = 'visible';
		overlay.style.visibility = 'visible';
	};

	pop_close.onclick =function(){
		popup.style.visibility = 'hidden';
		overlay.style.visibility = 'hidden';
		pop_close.style.visibility = 'hidden';
	};
	
	$('#pop_close').bind('tap', function () {
		
		$('#popup,.overlay,#pop_close').css("visibility", "hidden");
	});

	$('#SPC').bind('tap', function(){
		document.location="pdf/smpc.pdf";
	});


});
