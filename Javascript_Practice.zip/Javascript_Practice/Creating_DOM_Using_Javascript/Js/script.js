
var create_div = document.createElement("div");/*--creating div--*/

create_div.id = "wrapper";/*--adding id to div--*/

document.body.appendChild(create_div);/*--adding div to body--*/
create_div.classList.add('wrapper');

var create_img = document.createElement("img");/*--creating image element--*/
create_img.setAttribute ("src", 'Images/bg.jpg');
create_img.classList.add('wrapper');
create_img.setAttribute("alt", "bg");
create_div.appendChild(create_img);


var ref_icon = document.createElement("div");/*--creating ref_icon div with id--*/
ref_icon.id="ref_icon";
create_div.appendChild(ref_icon);
ref_icon.classList.add('ref_icon');

var ref_popup =  document.createElement("div");/*--creating ref_popup div with id--*/
ref_popup.id="ref_popup";
create_div.appendChild(ref_popup);
ref_popup.classList.add('ref_popup');

var ref_src = document.createElement("img");/*--creating image --*/
ref_src.setAttribute ("src", 'Images/image.jpg');
ref_src.classList.add('ref_src');
ref_src.setAttribute("alt", "bg");
ref_popup.appendChild(ref_src);

var close_btn = document.createElement("div");/*--creating close_btn div with id--*/
close_btn.id= "close_btn";
ref_popup.appendChild(close_btn);
close_btn.classList.add('close_btn');
close_btn.innerHTML ="x";

ref_icon.onclick = function(){
	ref_popup.style.display = "block";
	ref_src.setAttribute ("src", 'Images/image.jpg');
};

close_btn.onclick = function(){
	ref_popup.style.display = "none";
};
			


