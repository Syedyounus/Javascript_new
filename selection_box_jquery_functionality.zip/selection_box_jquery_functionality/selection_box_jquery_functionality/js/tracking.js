var track_data={track_element_1:{track_element_name:'menu button'},track_element_2:{track_element_name:'indication pop up'},track_element_3:{track_element_name:'contraindications pop up'},track_element_4:{track_element_name:'PI pop up'}};

function storeToCRM(elem) {
  
    var clickStream = {};
  clickStream.Track_Element_Description_vod__c = track_data[elem].track_element_name

  //  clickStream.Track_Element_Description_vod__c = "" + elem;
    //alert(JSON.stringify(clickStream))
    com.veeva.clm.createRecord("Call_Clickstream_vod__c", clickStream, pushDataToCRMDone);
	
}

function pushDataToCRMDone() {
    //alert(JSON.stringify(result));
    
}