// JavaScript Document
var clickHandler = "click";
$(document).ready(function(e) {
		"use strict";
	

	var images= [
        '../images/wrapper0.jpg',
        '../images/wrapper1.jpg',
        '../images/wrapper2.jpg',
        '../images/wrapper1_image1.png',
        '../images/wrapper1_image1_txt.png',
        '../images/images/wrapper1_image2.png',
        '../images/images/wrapper1_image2_txt.png',
        
    ];

    var $list = $('#imagesList');

    $.each(images, function(i, src) {
        var $li = $('<li class="loading">').appendTo($list);
        $('<img>').appendTo($li).one('load', function() {
            $li.removeClass('loading');
       }).attr('src', src);
    });		
	  
		setTimeout(function () {
			$("#wrapperImg").css("visibility", "visible");
		}, 150);

		setTimeout(function () {
			$("#wrapper").css("visibility", "visible");
		}, 150);


		$('.clickattr').bind('tap', function(){
			window.location.href = $(this).attr('goto');
		});
		
	    wrapper1();
		
	

	
	
	
		$('.tab1,#Erlotinib').bind('tap', function(){
			$("#drop_down").val("Afatinib");
			$('#wrapper0').hide();
			$('#wrapper1').css("visibility", "visible");
			$('#wrapper2').hide();
			wrapper1();
			wrapper0_reset();
			wrapper2_reset();
		});

		$('.tab2').bind('tap', function(){
			$("#drop_down").val("Erlotinib");
			$('#wrapper0').hide();
			$('#wrapper1').css("visibility", "hidden");
			$('#wrapper2').show();
			wrapper2();
			wrapper1_reset();
			wrapper0_reset();
		});

		$('.tab3').bind('tap', function(){
			$("#drop_down").val("Gefitinib");
			$('#wrapper0').show();
			$('#wrapper1').css("visibility", "hidden");
			$('#wrapper2').hide();
			wrapper1_reset();
			wrapper2_reset();
			wrapper0();
		});		
	
		$("#drop_down").change(function() {
			if($(this).val()=="Afatinib") {
				$('.tab1').tap();
			} else if($(this).val()=="Erlotinib") {
				$('.tab2').tap();
			} else if($(this).val()=="Gefitinib") {
				$('.tab3').tap();
			}
		});	

		$('#ref').bind('tap', function(){
			$('#reference_popup').show();
			$('.overlay').show()
		});
	
		$('#ref_cloes').bind('tap', function(){
			$('#reference_popup,.overlay').hide();
		});
	
		$('#iecrcm').bind('tap', function(){
			$('#iecrcm_popup').show();
			$('.overlay').show();
		});
	
		$('#iecrcm_cloes').bind('tap', function(){
			$('#iecrcm_popup,.overlay').hide();
		});
		
/*--wrapper0 function--*/	
	
	function wrapper0(){
		$('#image1').delay(600).animate({'opacity':'1'},1, function(){
			$('#image1').attr({'class':'animated fadeIn'});
		})
	
		$('#image1_txt').delay(600).animate({'opacity' : '1'},1, function(){
			$('#image1_txt').attr({'class': 'animated fadeIn'});
		});
	
		$('#image2').delay(1400).animate({'opacity':'1'},1, function(){
			$('#image2').attr({'class':'animated fadeIn'});
		})
	
		$('#image2_txt').delay(1400).animate({'opacity' : '1'},1, function(){
			$('#image2_txt').attr({'class': 'animated fadeIn'});
		});
	
		$('#graph_line1').delay(1800).animate({'opacity' : '1'},1, function(){
			$('#graph_line1').attr({'class': 'animated fadeIn'});
		});
	
//		$('#graph_line1_1').delay(2600).animate({'opacity' : '1'},1, function(){
//			$('#graph_line1_1').attr({'class': 'animated fadeIn'});
//		});
//		
//		$('#graph_line1_2').delay(3200).animate({'opacity' : '1'},1, function(){
//			$('#graph_line1_2').attr({'class': 'animated fadeIn'});
//		});
		
		$('#graph_line2').delay(1800).animate({'opacity' : '1'},1, function(){
			$('#graph_line2').attr({'class': 'animated fadeIn'});
		});
		
//		$('#graph_line2_1').delay(2600).animate({'opacity' : '1'},1, function(){
//			$('#graph_line2_1').attr({'class': 'animated fadeIn'});
//		});
//	
//		$('#graph_line2_2').delay(3200).animate({'opacity' : '1'},1, function(){
//			$('#graph_line2_2').attr({'class': 'animated fadeIn'});
//		});
		
	}
		
		$('#site_ref').bind('tap', function(){
			$('#site_popup').show();
		});	
	
		$('.site_close').bind('tap', function(){
			setTimeout(function(){$('#site_popup').hide();},100);
		});
	
		$('#logo_ref').bind('tap', function(){
			$('#logo_popup').show();
			animate_txt();
		});	
	
	
	
		function wrapper0_reset(){
			$('#image1').removeClass("animated fadeIn");
			$('#image1').finish().css({opacity:'0'});
			
			$('#image1_txt').removeClass("animated fadeIn");
			$('#image1_txt').finish().css({opacity:'0'});
			
			$('#image2').removeClass("animated fadeIn");
			$('#image2').finish().css({opacity:'0'});
			
			$('#image2_txt').removeClass("animated fadeIn");
			$('#image2_txt').finish().css({opacity:'0'});
			
			$('#graph_line1').removeClass("animated fadeIn");
			$('#graph_line1').finish().css({opacity:'0'});
			
			$('#graph_line1_1').removeClass("animated fadeIn");
			$('#graph_line1_1').finish().css({opacity:'0'});
			
			$('#graph_line1_2').removeClass("animated fadeIn");
			$('#graph_line1_2').finish().css({opacity:'0'});
			
			$('#graph_line2').removeClass("animated fadeIn");
			$('#graph_line2').finish().css({opacity:'0'});
			
			$('#graph_line2_1').removeClass("animated fadeIn");
			$('#graph_line2_1').finish().css({opacity:'0'});
			
			$('#graph_line2_2').removeClass("animated fadeIn");
			$('#graph_line2_2').finish().css({opacity:'0'});
			
		}
	
		function animate_txt(){						
			$('#site').delay(800).animate({'opacity' : '1'},1, function(){
				$('#site').attr({'class': 'animated fadeIn'});
			});
			$('#site_txt').delay(1200).animate({'opacity' : '1'},1, function(){
				$('#site_txt').attr({'class': 'animated fadeIn'});
			});
		}
	
		function reset_animate_txt(){
			$('#site').removeClass("animated fadeIn");
			$('#site').finish().css({opacity:'0'});
			$('#site_txt').removeClass("animated fadeIn");
			$('#site_txt').finish().css({opacity:'0'});
		}
		
		
	
		$('.logo_close').bind('tap', function(){
			setTimeout(function(){$('#logo_popup').hide();},100);
			reset_animate_txt();
		});
	
	/*--end of wrapper0 function--*/

	
/*--wrapper1 function--*/
	
	function wrapper1(){
		$('#wrapper1_image1').delay(600).animate({'opacity':'1'},1, function(){
			$('#wrapper1_image1').attr({'class':'animated fadeIn'});
		})
	
		$('#wrapper1_image1_txt').delay(600).animate({'opacity' : '1'},1, function(){
			$('#wrapper1_image1_txt').attr({'class': 'animated fadeIn'});
		});
	
		$('#wrapper1_image2').delay(1400).animate({'opacity':'1'},1, function(){
			$('#wrapper1_image2').attr({'class':'animated fadeIn'});
		})
	
		$('#wrapper1_image2_txt').delay(1400).animate({'opacity' : '1'},1, function(){
			$('#wrapper1_image2_txt').attr({'class': 'animated fadeIn'});
		});
	
		$('#wrapper1_graph_line1').delay(1800).animate({'opacity' : '1'},1, function(){
			$('#wrapper1_graph_line1').attr({'class': 'animated fadeIn'});
		});

		$('#wrapper1_graph_line2').delay(1800).animate({'opacity' : '1'},1, function(){
			$('#wrapper1_graph_line2').attr({'class': 'animated fadeIn'});
		});
		

		
	}
	
	
		$('#wrapper1_site_ref').bind('tap', function(){
			$('#wrapper1_site_popup').show();
		});	
	
		$('.wrapper1_site_close').bind('tap', function(){
			setTimeout(function(){$('#wrapper1_site_popup').hide();},100);
		});
	
		
		
		
	
	
	function wrapper1_reset(){
			$('#wrapper1_image1').removeClass("animated fadeIn");
			$('#wrapper1_image1').finish().css({opacity:'0'});
			
			$('#wrapper1_image1_txt').removeClass("animated fadeIn");
			$('#wrapper1_image1_txt').finish().css({opacity:'0'});
			
			$('#wrapper1_image2').removeClass("animated fadeIn");
			$('#wrapper1_image2').finish().css({opacity:'0'});
			
			$('#wrapper1_image2_txt').removeClass("animated fadeIn");
			$('#wrapper1_image2_txt').finish().css({opacity:'0'});
			
			$('#wrapper1_graph_line1').removeClass("animated fadeIn");
			$('#wrapper1_graph_line1').finish().css({opacity:'0'});
			
			$('#wrapper1_graph_line2').removeClass("animated fadeIn");
			$('#wrapper1_graph_line2').finish().css({opacity:'0'});

		}
	
		function wrapper1_animate_txt(){						
			$('#wrapper1_site').delay(800).animate({'opacity' : '1'},1, function(){
				$('#wrapper1_site').attr({'class': 'animated fadeIn'});
			});
			$('#wrapper1_site_txt').delay(1200).animate({'opacity' : '1'},1, function(){
				$('#wrapper1_site_txt').attr({'class': 'animated fadeIn'});
			});
		}
	
		function wrapper1_reset_animate_txt(){
			$('#wrapper1_site').removeClass("animated fadeIn");
			$('#wrapper1_site').finish().css({opacity:'0'});
			$('#wrapper1_site_txt').removeClass("animated fadeIn");
			$('#wrapper1_site_txt').finish().css({opacity:'0'});
		}
		
	
	    $('#wrapper1_logo_ref').bind('tap', function(){
			$('#wrapper1_logo_popup').show();
			wrapper1_animate_txt();
		});	
	
		$('.wrapper1_logo_close').bind('tap', function(){
			setTimeout(function(){$('#wrapper1_logo_popup').hide();},100);
			 wrapper1_reset_animate_txt();
		});
	
	
/*--end of wrapper1 function--*/
	
	
	
/*--wrapper2 function--*/
	
	function wrapper2(){
		$('#wrapper2_image1').delay(600).animate({'opacity':'1'},1, function(){
			$('#wrapper2_image1').attr({'class':'animated fadeIn'});
		})
	
		$('#wrapper2_image1_txt').delay(600).animate({'opacity' : '1'},1, function(){
			$('#wrapper2_image1_txt').attr({'class': 'animated fadeIn'});
		});
	
		$('#wrapper2_image2').delay(1400).animate({'opacity':'1'},1, function(){
			$('#wrapper2_image2').attr({'class':'animated fadeIn'});
		})
	
		$('#wrapper2_image2_txt').delay(1400).animate({'opacity' : '1'},1, function(){
			$('#wrapper2_image2_txt').attr({'class': 'animated fadeIn'});
		});
	
		$('#wrapper2_graph_line1').delay(1800).animate({'opacity' : '1'},1, function(){
			$('#wrapper2_graph_line1').attr({'class': 'animated fadeIn'});
		});

		$('#wrapper2_graph_line2').delay(1800).animate({'opacity' : '1'},1, function(){
			$('#wrapper2_graph_line2').attr({'class': 'animated fadeIn'});
		});
		

		
	}
	
	
		$('#wrapper2_site_ref').bind('tap', function(){
			$('#wrapper2_site_popup').show();
		});	
	
		$('.wrapper2_site_close').bind('tap', function(){
			setTimeout(function(){$('#wrapper2_site_popup').hide();},100);
		});
	
		$('#wrapper2_logo_ref').bind('tap', function(){
			$('#wrapper2_logo_popup').show();
			wrapper2_animate_txt()
		});	
		
		$('.wrapper2_logo_close').bind('tap', function(){
			setTimeout(function(){$('#wrapper2_logo_popup').hide();},100);
			wrapper2_reset_animate_txt();
		});
	
	
	
	function wrapper2_reset(){
			$('#wrapper2_image1').removeClass("animated fadeIn");
			$('#wrapper2_image1').finish().css({opacity:'0'});
			
			$('#wrapper2_image1_txt').removeClass("animated fadeIn");
			$('#wrapper2_image1_txt').finish().css({opacity:'0'});
			
			$('#wrapper2_image2').removeClass("animated fadeIn");
			$('#wrapper2_image2').finish().css({opacity:'0'});
			
			$('#wrapper2_image2_txt').removeClass("animated fadeIn");
			$('#wrapper2_image2_txt').finish().css({opacity:'0'});
			
			$('#wrapper2_graph_line1').removeClass("animated fadeIn");
			$('#wrapper2_graph_line1').finish().css({opacity:'0'});
			
			$('#wrapper2_graph_line2').removeClass("animated fadeIn");
			$('#wrapper2_graph_line2').finish().css({opacity:'0'});

		}
	
		function wrapper2_animate_txt(){						
			$('#wrapper2_site').delay(800).animate({'opacity' : '1'},1, function(){
				$('#wrapper2_site').attr({'class': 'animated fadeIn'});
			});
			$('#wrapper2_site_txt').delay(1200).animate({'opacity' : '1'},1, function(){
				$('#wrapper2_site_txt').attr({'class': 'animated fadeIn'});
			});
		}
	
		function wrapper2_reset_animate_txt(){
			$('#wrapper2_site').removeClass("animated fadeIn");
			$('#wrapper2_site').finish().css({opacity:'0'});
			$('#wrapper2_site_txt').removeClass("animated fadeIn");
			$('#wrapper2_site_txt').finish().css({opacity:'0'});
		}
		
		

	
	
/*--end of wrapper1 function--*/
	
	
		$("#menu1").bind("tap click",function(){
		document.location="veeva:gotoSlide(Leakage_Funnel_Incidencia_Cancro_do_Pulmao_PT_V2.zip, PT_TAG_Simulador_Leakage_Funnel_V2)";
		});
	
		$("#menu2").bind("tap click",function(){
			document.location="veeva:gotoSlide(Tagrisso_Simulador_Leakage_Funnel_Sequenciacao_terapeutica_Afatinib_PT_V2.zip, PT_TAG_Simulador_Leakage_Funnel_V2)";
		});
	
		$("#menu3").bind("tap click",function(){
			document.location="veeva:gotoSlide(Tagrisso_Simulador_Leakage_Funnel_PPOs_PT_V2.zip, PT_TAG_Simulador_Leakage_Funnel_V2)";
		});


		$('img, a').on('dragstart', function(event){event.preventDefault();});
	
});
