$(document).ready(function() {

	"use strict";

    $("body").bind('touchmove', function(event) {
        event.preventDefault();
    });  
	

	
	$("#wrapper1").swipe({
		swipe: function (event, direction) {
			if(direction === 'left'){
				document.location="veeva:nextSlide()";     
//				alert();
			}
			else if(direction === 'right'){
				document.location = 'veeva:prevSlide()'
//				alert();
			}
		}
    });
	
	


	
});

